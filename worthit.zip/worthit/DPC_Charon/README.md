# DPC CHARON

## Description

> "Charon is your guide to help you cross the ~~Stix~~ river between regular data and big data. Small streams make big rivers."

Charon work on two fronts :

* First it connects to SQL servers through a JDBC connection and extracts table to a parquet format (using [EEL-SDK](https://github.com/51zero/eel-sdk) under the hood).
* Then it uploads them to the lake using the [Data-Ingestion API](https://sgithub.fr.world.socgen/BSC-DataEng/IGD_Data_Ingestion), before cleaning after itself.


## Laying the ground work

> "For it to work, you will need to pay Charon its abode. *Two coins*." 

* Client ID and Secret created [through SG Connect](https://developer.sgmarkets.com/workspace/apis/clients) and subbed to [Data-Ingestion API](https://developer.sgmarkets.com/explore/api/mybigdata) (with scopes : *manage* & *pushfiles*).
* Associate your client ID to your trigram following [Data-Ingestion's documentation](https://sgithub.fr.world.socgen/BSC-DataEng/IGD_Data_Ingestion/blob/develop_V2/docs/common/associateclientid/ticketjira.md).

Executing environment needs to have *JAVA* installed.
How you choose to execute the rest of the workflow is entirely up to you (*Cron*, *Jenkins*, *Spring Batch*...).

Alternatively, You can run charon through a [Kubernetes CronJob](https://kubernetes.io/docs/concepts/workloads/controllers/cron-jobs/). It is especially useful if you need to push SRV tables to the lake on a recurring schedule (daily, weekly, ...).
A template is provided in the [ForkMe repository of Charon](https://sgithub.fr.world.socgen/BSC-DataEng/DPC_Charon_ForkMe).

## How to configure

### Template properties

```properties
# ============ DPC Charon Properties configuration =============

# Source configuration
dbUrl=jdbc:<sqlType>://<url_with_database_specified>
dbType=<sqlType>
dbUser=<user_that_will_run_queries>
dbPass=<user_password>

# Workflow configuration
queriesLoadFolder=./path/to/queries
parquetSaveFolder=./temporary/parquet/save/path

# Source related parameters
trigram=<trigram>
irt=<irt>

# Environment dependant
env=<DEV|HML|PRD>
clientIdUser=<sg_clientid_api>
clientIdPass=<sg_client_secret>

# =============== DO NOT MODIFY BEYOND THIS LINE ===============
# Unless asked by a member of the DPC/ROL or DATA-Ingestion team

# Datalake related parameters
rawArea=/<env>/raw/<trigram>_<irt>/<label>
targetDb=<env>_srv_<trigram>_<irt>_<label>
targetPath=/<env>/srv/<trigram>_<irt>/<label>
#hivePartion=dt -> Default value, can be omitted
#writeMode=overwrite -> Default value, can be omitted

# Control-M integration
ctrlMDatacenter=COMMXX_X-XX

# User for the IngAAS API
livyProxyUser=XXX-XXXXXXXXXXXX-x_xxxxXXX
livyQueue=ENV_CORE_XXX_XXXX_GLOBAL_P
```

### How to choose datalake related parameters ? (DPC/ROL)

If you are unsure if your application is linked to DPC or ROL, ask your contact in the datalake team.

| **DPC** | ctrlMDatacenter |         livyProxyUser         |            livyQueue           |
|:-------:|:---------------:|:-----------------------------:|:------------------------------:|
|   HOM   |   _COMM07_F-H1_ | _7db-3969b9e0eaf5-f_dpca8420_ | _FHML_CORE_DPC_A8420_GLOBAL_P_ |
|   PRD   |   _COMM07_P-P1_ | _480-8c826b1fdef3-p_dpca8420_ |  _PRD_CORE_DPC_A8420_GLOBAL_P_ |

| **ROL** | ctrlMDatacenter |         livyProxyUser         |            livyQueue           |
|:-------:|:---------------:|:-----------------------------:|:------------------------------:|
|   HOM   |   _COMM07_F-H1_ | _2c0-467b33c43a69-f_rola8518_ | _FHML_CORE_ROL_A8518_GLOBAL_P_ |
|   PRD   |   _COMM07_P-P1_ | _041-925ee8cdbdb8-p_rola8518_ |  _PRD_CORE_ROL_A8518_GLOBAL_P_ |

## Usage

Feel free to explore the various Charon-related repositories by searching "charon" in your sgithub organization.


0. Ensure the *JAVA_HOME* is defined and working in your environment.

1. Get the latest Charon jar on the [SOFA Nexus](https://sofa.dns20.socgen/nexus/#browse/search=keyword%3Dcharon).

2. Properly set up your properties files according to the above section.

3. Populate your *queries* folder with a .sql file per SRV table you want to export (each query will be run against your database).

One all that is done, all you have to do is execute the jar :

```sh
java -jar charon-1.0.0.jar path/to/file.properties
```

