package com.socgen.bsc.dpc.charon.engines

import java.io.IOException
import java.nio.file.{Files, Paths}

import com.socgen.bsc.dpc.charon.api.{Requests, UrlBanks}
import com.socgen.bsc.dpc.charon.common.ErrorCollection.Stage
import com.socgen.bsc.dpc.charon.common.{DPCProperties, ErrorCollection, Helpers}
import com.github.nscala_time.time.Imports._
import com.typesafe.scalalogging.LazyLogging
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.Path


// Using the static constructor given in the companion object instead of this one is STRONGLY recommended.
class IngestionUploader(
    // Source related parameters
    val trigram: String, val irt: String,
    // Environment dependant
    val urlBank: UrlBanks.UrlBank, val clientIdCredentials: (String, String),
    // Datalake related parameters
    val rawArea: String, val targetDb: String, val targetPath: String, val ctrlMDatacenter: String,
    // TODO this goes on a per-table basis
    val hivePartition: Option[String],
    val overwrite: Boolean,
    // Which user will the API run on
    val livyProxyUser: String, val livyQueue: String)
    extends LazyLogging
{
    //region Workflow related attributes

    var token: String = "Call _regenerateToken(), or let it be called by _verifyToken()."
    var tokenRegenerationDate = DateTime.now
    val errors: ErrorCollection = new ErrorCollection

    //endregion

    //region Public Functions

    def sendParquets(pathsToParquets: Seq[Path]): Iterable[Path] =
    {
        // srv name -> path on system
        val srvPaths: Map[String, Path] = pathsToParquets.map(p => Helpers.inferSrvName(p) -> p).toMap

        val ingestionIds: Map[String, Int] =
            srvPaths.keys
            .map(srv => srv -> _createPipelineForSrv(srv, slowed = true))
            // filtering out none values
            .filter(_._2.isDefined).toMap
            .mapValues(_.get)

        // srv name -> presigned url
        val presignedUrls: Map[String, String] =
            ingestionIds
            .map(srvAndId => srvAndId._1 -> _getPresignedUrlOfSrv(srvAndId, slowed = true))
            // filtering out none values
            .filter(_._2.isDefined)
            .mapValues(_.get)

        // We have everything we need, now uploading
        logger.info("Starting upload procedure. This may take a while.")

        presignedUrls
        .map(srvAndUrl => _sendDataToS3(srvPaths(srvAndUrl._1), srvAndUrl._2, slowed = true))
        .filter(_.isDefined)
        .map(_.get)
    }

    //endregion

    //region Workflow sub-functions

    // Can perhaps be made public
    private def _regenerateToken(): String =
    {
        val postTokenReq = new Requests.PostToken(urlBank.accessTokenUrl, clientIdCredentials)
        if (!postTokenReq.response.is2xx)
            throw new RuntimeException(s"Could generate token !\nAPI : ${postTokenReq.response}")

        // Parsing token validity
        val tokenValidityPeriod: Int = postTokenReq.asJson \\ "expires_in" match
        {
            case List(bodyExpiresIn, _*) =>
                bodyExpiresIn.asNumber.flatMap(_.toInt).get
            case _                       =>
                throw new RuntimeException(
                    s"Could not parse token expiration !\nAPI answered : ${postTokenReq.response}")
        }

        // We will regenerate the token in "tokenValidityPeriod" seconds, bar a arbitrary safety threshold (1min).
        tokenRegenerationDate = DateTime.now + tokenValidityPeriod.seconds - IngestionUploader.TokenValidityThreshold

        // Parsing said token
        postTokenReq.asJson \\ "access_token" match
        {
            case List(bodyToken, _*) =>
                logger.info(
                    s"Successfully generated client token. Next one will be regenerated past $tokenRegenerationDate.")
                bodyToken.asString.get
            case _                   =>
                throw new RuntimeException(s"Could not parse access token !\nAPI answered : ${postTokenReq.response}")
        }
    }

    private def _verifyToken(): Unit =
    {
        if (DateTime.now > tokenRegenerationDate)
            token = _regenerateToken()
    }

    private def _createPipelineForSrv(name: String, slowed: Boolean = false): Option[Int] =
    {
        _verifyToken()

        val postPipelineReq = new Requests.PostPipeline(urlBank.dataIngestionUrl, token, trigram, irt,
                                                        rawArea, targetDb, targetPath, name,
                                                        livyProxyUser, livyQueue, ctrlMDatacenter,
                                                        overwrite, hivePartition)

        if (!postPipelineReq.response.is2xx)
            return errors.addError(Stage.PIPELINE_CREATION, name,
                                   s"Error reaching API; ${postPipelineReq.response.toString}")(logger)

        if (slowed)
            Thread.sleep(IngestionUploader.TimeBetweenRequests)

        postPipelineReq.asJson \\ "ingestionId" match
        {
            case List(ingestionId, _*) =>
                logger.info(s"Pipeline fetched/created for ${name.toUpperCase}")
                Some(ingestionId.asNumber.flatMap(_.toInt).get)
            case _                     =>
                errors.addError(Stage.PIPELINE_CREATION, name,
                                s"Could not parse ingestion id; ${postPipelineReq.response}")(logger)
        }
    }

    private def _getPresignedUrlOfSrv(nameAndId: (String, Int),
                                      slowed: Boolean = false): Option[String] = nameAndId match
    {

        case (name, ingestionId) =>
            _verifyToken()
            val getUrlReq = new Requests.PostPresignedURL(urlBank.dataIngestionUrl, token, name, ingestionId)
            if (!getUrlReq.response.is2xx)
                return errors.addError(
                    Stage.GET_PRESIGNED_URL, name, s"Error reaching API;\nReceived : ${getUrlReq.response}")(logger)

            if (slowed)
                Thread.sleep(IngestionUploader.TimeBetweenRequests)

            getUrlReq.asJson \\ "presignedUrl" match
            {
                case List(presignedUrl) =>
                    logger.info(s"Retrieved presigned url for ${nameAndId._1.toUpperCase}.")
                    Some(presignedUrl.asString.get)
                case _                  =>
                    errors.addError(Stage.PIPELINE_CREATION, name,
                                    s"Could not parse presigned url; ${getUrlReq.response}")(logger)
            }
    }


    private def _sendDataToS3(pathToParquet: Path, presignedUrl: String, slowed: Boolean = false): Option[Path] =
    {
        val name = Helpers.inferSrvName(pathToParquet)

        try
        {
            val data = Files.readAllBytes(Paths.get(pathToParquet.toString))

            _verifyToken()
            val putTableReq = new Requests.PutTableData(presignedUrl, data)
            if (!putTableReq.response.is2xx)
                return errors.addError(Stage.UPLOAD, name, s"Error reaching API; ${putTableReq.response}")(logger)

            if (slowed)
                Thread.sleep(IngestionUploader.TimeBetweenUploads)

            logger.info(s"Successfully uploaded ${name.toUpperCase} !")
            Some(pathToParquet)
        }
        catch
        {
            case e: IOException =>
                errors.addError(Stage.UPLOAD, name, s"Couldn't read parquet : ${e.getMessage}")(logger)
        }
    }

    //endregion
}

object IngestionUploader
{

    // Keys to extract from properties object
    private object Keys
    {
        val Trigram = "trigram"
        val Irt = "irt"
        val UrlBank = "env"
        val ClientIdUser = "clientIdUser"
        val ClientIdPass = "clientIdPass"
        val RawArea = "rawArea"
        val TargetDb = "targetDb"
        val TargetPath = "targetPath"
        val LivyProxyUser = "livyProxyUser"
        val LivyQueue = "livyQueue"
        val HivePartition = "hivePartition"
        val WriteMode = "writeMode"
        val ControlMDatacenter = "ctrlMDatacenter"
    }

    // Technical config values
    val TimeBetweenRequests: Int = 100
    val TimeBetweenUploads: Int = 10 * 1000
    val TokenValidityThreshold = 1.minutes

    // Preferred constructor
    def apply(dpcProps: DPCProperties)(implicit hadoopConf: Configuration): IngestionUploader =
    {
        // Simply fetching stored values
        val trigram = dpcProps.get(Keys.Trigram)
        val irt = dpcProps.get(Keys.Irt)
        val clientIdCredentials = (dpcProps.get(Keys.ClientIdUser), dpcProps.get(Keys.ClientIdPass))
        val rawArea = dpcProps.get(Keys.RawArea)
        val targetDb = dpcProps.get(Keys.TargetDb)
        val targetPath = dpcProps.get(Keys.TargetPath)
        val livyProxyUser = dpcProps.get(Keys.LivyProxyUser)
        val livyQueue = dpcProps.get(Keys.LivyQueue)
        val hivePartition: Option[String] = dpcProps.getOpt(Keys.HivePartition)
        val ctrlMDatacenter = dpcProps.get(Keys.ControlMDatacenter)

        // Inferring URLs depending on ENV
        val urlBank = dpcProps.get(Keys.UrlBank).toUpperCase match
        {
            case "DEV"                  => UrlBanks.DEV
            case "HML" | "HOM" | "FHML" => UrlBanks.HML
            case "PRD" | "PROD"         => UrlBanks.PRD
        }

        // Inferring write mode ; default to overwrite
        val overwrite = dpcProps.getOpt(Keys.WriteMode).map(_.toUpperCase) match
        {
            case None              => true
            case Some("OVERWRITE") => true
            case Some("APPEND")    => false
            case Some(value)       => throw new IllegalArgumentException(
                s"Value '$value' is not understood. Write mode is either <overwrite|append>.")
        }

        // Creating new instance
        new IngestionUploader(trigram, irt, urlBank, clientIdCredentials,
                              rawArea, targetDb, targetPath, ctrlMDatacenter,
                              hivePartition, overwrite, livyProxyUser, livyQueue)
    }
}