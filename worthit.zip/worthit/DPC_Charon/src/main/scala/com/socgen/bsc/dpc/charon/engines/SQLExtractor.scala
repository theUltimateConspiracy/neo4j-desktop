package com.socgen.bsc.dpc.charon.engines

import java.io.{File, FileNotFoundException}
import java.sql.{Connection, DriverManager}
import java.util.Properties

import com.socgen.bsc.dpc.charon.common.ErrorCollection.Stage
import com.socgen.bsc.dpc.charon.common.{DPCProperties, ErrorCollection, Helpers}
import com.typesafe.scalalogging.LazyLogging
import io.eels.component.jdbc.JdbcSource
import io.eels.component.parquet.ParquetSink
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileAlreadyExistsException, FileSystem, Path}

import scala.io.Source


class SQLExtractor(connectionProps: Properties, url: String, queriesFolder: String, parquetFolder: String)
    extends LazyLogging
{
    val driverGetConn: () => Connection = () => DriverManager.getConnection(url, connectionProps)
    val errors: ErrorCollection = new ErrorCollection

    def executeQuery(query: String, outputPath: String)(implicit hadoopConf: Configuration): Option[Path] =
    {
        // PostGre being PostGre, we need to use reflection to activate the driver
        Class.forName("org.postgresql.Driver")

        implicit val hadoopFileSystem: FileSystem = FileSystem.get(hadoopConf)
        val parquetFilePath = new Path(outputPath)
        val filename = Helpers.inferSrvName(parquetFilePath)

        try
        {
            JdbcSource(driverGetConn, query)
            .withFetchSize(SQLExtractor.fetchSize)
            .toDataStream
            .to(ParquetSink(parquetFilePath))

            logger.info(s"Successfully extracted query to ${parquetFilePath.getName}.")
            Some(parquetFilePath)
        }
        catch
        {
            case e: FileAlreadyExistsException =>
                logger.warn(s"Found previous ${filename.toUpperCase}. Skipping."); Some(parquetFilePath)
            case e: Throwable                  =>
                errors.addError(Stage.EXTRACTION, filename, e.getMessage)(logger)
        }
    }

    def executeSqlFile(pathToSql: String)(implicit hadoopConf: Configuration): Option[Path] =
    {
        if (!pathToSql.endsWith(".sql"))
            throw new IllegalArgumentException(s"File $pathToSql is not a .sql file.")

        try
        {
            val sqlFile = Source.fromFile(pathToSql)
            val query = sqlFile.mkString
            sqlFile.close

            val filename = Helpers.inferSrvName(pathToSql)
            executeQuery(query.trim.stripSuffix(";"), s"$parquetFolder/$filename.parquet")
        }
        catch
        {
            case e: FileNotFoundException =>
                throw new FileNotFoundException(s"Could not find SQL file : $pathToSql")
            case e: Throwable             =>
                throw new RuntimeException(s"Unhandled Exception while reading SQL file : ${e.getMessage}")
        }
    }

    def executeSqlFolder(implicit hadoopConf: Configuration): Seq[Path] =
    {
        val dir = new File(queriesFolder)
        if (!dir.exists)
            throw new FileNotFoundException(s"Could not find SQL Directory : $queriesFolder")
        if (!dir.isDirectory)
            throw new IllegalArgumentException(s"Path $queriesFolder is not a directory.")

        dir.listFiles
        .filter(_.isFile)
        .map(_.getAbsolutePath)
        .filter(_.endsWith(".sql"))
        .map(executeSqlFile)
        .filter(_.isDefined)
        .map(_.get)
    }
}

object SQLExtractor
{

    // Keys to extract from properties object
    private object Keys
    {
        val DatabaseUrl = "dbUrl"
        val DatabaseType = "dbType"
        val DatabaseUser = "dbUser"
        val DatabasePass = "dbPass"
        val QueriesFolder = "queriesLoadFolder"
        val ParquetFolder = "parquetSaveFolder"
    }

    // Technical config values
    val fetchSize = 100

    // Driver class to instantiate
    def DbTypeToDriverClass(dbType: String): String = dbType match
    {
        // TODO : Add more driver classes
        case "sqlserver"   => "com.microsoft.sqlserver.jdbc.SQLServerDriver"
        case "postgresql"  => "org.postgresql.Driver"
        case other: String => throw new UnsupportedOperationException(
            s"Database type $other is either erroneous or currently unsupported.")
    }

    // Preferred constructor
    def apply(dpcProps: DPCProperties)(implicit hadoopConf: Configuration): SQLExtractor =
    {
        // Fetching keys into properties files

        var dbUrl = dpcProps.get(Keys.DatabaseUrl)(hadoopConf)
        val queriesFolder = dpcProps.get(Keys.QueriesFolder)
        val parquetFolder = dpcProps.get(Keys.ParquetFolder)
        val driverClassName = DbTypeToDriverClass(dpcProps.get(Keys.DatabaseType))

        // Populating connection properties object

        val connectionProps = new Properties()
        connectionProps.put("user", dpcProps.get(Keys.DatabaseUser)(hadoopConf))
        connectionProps.put("password", dpcProps.get(Keys.DatabasePass)(hadoopConf))
        connectionProps.put("driver", driverClassName)

        new SQLExtractor(connectionProps, dbUrl, queriesFolder, parquetFolder)
    }
}