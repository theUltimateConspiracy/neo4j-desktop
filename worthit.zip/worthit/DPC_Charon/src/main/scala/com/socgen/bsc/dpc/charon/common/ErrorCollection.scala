package com.socgen.bsc.dpc.charon.common

import com.socgen.bsc.dpc.charon.common.ErrorCollection.Stage
import com.typesafe.scalalogging.Logger

import scala.collection.mutable.{Map => MMap}

class ErrorCollection
{
    val errorCollection: MMap[String, (Stage.Value, String)] = MMap[String, (Stage.Value, String)]()


    def addError[T](stage: Stage.Value, offender: String, message: String)(implicit logger: Logger): Option[T] =
    {
        errorCollection += (offender -> (stage, message))
        logger.error(s"Error for $offender in stage $stage : $message")
        None
    }


    def count: Int =
        this.errorCollection.size

    def recap: String =
        this.errorCollection.map(kv => s"[${kv._2._1}][${kv._1.toUpperCase}] ${kv._2._2}").mkString("\n")
}

object ErrorCollection
{

    object Stage extends Enumeration
    {
        val EXTRACTION: Stage.Value = Value("EXTRACTION")
        val PIPELINE_CREATION: Stage.Value = Value("PIPELINE_CREATION")
        val PIPELINE_DELETION: Stage.Value = Value("PIPELINE_DELETION")
        val GET_PRESIGNED_URL: Stage.Value = Value("GET_PRESIGNED_URL")
        val UPLOAD: Stage.Value = Value("UPLOAD")
    }

}