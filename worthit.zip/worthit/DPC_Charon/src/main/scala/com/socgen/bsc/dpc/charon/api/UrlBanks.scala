package com.socgen.bsc.dpc.charon.api

object UrlBanks
{

    abstract case class UrlBank
    (
        accessTokenUrl: String,
        dataIngestionUrl: String
    )

    object PRD extends UrlBank(
        accessTokenUrl = "https://sso.sgmarkets.com/sgconnect/oauth2/access_token",
        dataIngestionUrl = "https://mybigdata-prd.world.socgen")

    object HML extends UrlBank(
        accessTokenUrl = "https://sgconnect-hom.fr.world.socgen/sgconnect/oauth2/access_token",
        dataIngestionUrl = "https://mybigdata-hom.world.socgen")

    object DEV extends UrlBank(
        accessTokenUrl = "https://sgconnect-hom.fr.world.socgen/sgconnect/oauth2/access_token",
        dataIngestionUrl = "https://mybigdata-dev.world.socgen")

}
