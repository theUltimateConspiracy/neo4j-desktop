package com.socgen.bsc.dpc.charon.common

import org.apache.commons.io.FilenameUtils
import org.apache.hadoop.fs.Path

object Helpers
{
    def inferSrvName(pathToParquet: Path): String =
        FilenameUtils.getBaseName(pathToParquet.getName)

    def inferSrvName(path: String): String =
        FilenameUtils.getBaseName(path)
}
