package com.socgen.bsc.dpc.charon.api

import java.text.SimpleDateFormat
import java.util.Calendar

import io.circe._
import io.circe.parser._
import scalaj.http.{Http, HttpOptions, HttpRequest, HttpResponse}

object Requests
{

    abstract class APIRequest
    {
        val url: String
        val request: HttpRequest
        lazy val response: HttpResponse[String] = request.asString

        lazy val asJson: Json = parse(response.body) match
        {
            case Left(_)     => Json.Null
            case Right(json) => json
        }
    }


    class PostToken(baseUrl: String, clientIdCredentials: (String, String)) extends APIRequest
    {
        private val scopes = Seq("openid",
                                 "api.mybigdata.ingestion.manage",
                                 "api.mybigdata.ingestion.pushfile")

        val url: String = s"$baseUrl?scope=${scopes.mkString("+")}"

        val request: HttpRequest = Http(url)
                                   .auth(clientIdCredentials._1, clientIdCredentials._2)
                                   .postForm(Seq(("grant_type", "client_credentials")))
    }

    class PostPipeline(baseUrl: String, token: String, trigram: String, irt: String,
                       rawArea: String, targetDb: String, targetPath: String, targetSrvName: String,
                       livyProxyUser: String, livyQueue: String, ctrlMDatacenter: String,
                       overwrite: Boolean, hivePartition: Option[String] = None)
        extends APIRequest
    {
        val url: String = s"$baseUrl/api/v2/ingestion/pipelines"

        private val replayMode: String =
            if (overwrite) "OVERWRITE"
            else "APPEND"

        private val partitionConfig: String = if (hivePartition.isDefined)
            s"""  "partitionColumn": "${hivePartition.get}",
               |  "clientHivePartitionColumn": "${hivePartition.get}",
               |  "replayPartition" : "$replayMode"""".stripMargin
        else
            s"""  "partitionColumn": "dt",
               |  "replayPartition" : "$replayMode"""".stripMargin

        val body: String =
            s"""{
               |  "trigram": "$trigram",
               |  "irt": "$irt",
               |  "targetCluster": [
               |    "LUCID"
               |  ],
               |  "engineType": "parquet",
               |  "rawArea": "$rawArea",
               |  "targetDB": "$targetDb",
               |  "livyProxyUser": "$livyProxyUser",
               |  "livyQueue": "$livyQueue",
               |  "targetSrvName": "$targetSrvName",
               |  "targetPath": "$targetPath/$targetSrvName",
               |  "outputFormat": "parquet",
               |  "parquet": {
               |    "modeValidateDataFromSchema": "FAILFAST"
               |  },
               |  "controlM": {
               |    "condition": "A_${trigram.toUpperCase}_RAW_SRV_${targetSrvName.toUpperCase}-OK",
               |    "conditionFailure": "A_${trigram.toUpperCase}_RAW_SRV_${targetSrvName.toUpperCase}-KO",
               |    "dataCenter" : "$ctrlMDatacenter"
               |  },
               |$partitionConfig
               |}
               |""".stripMargin

        val request: HttpRequest = Http(url)
                                   .header("Content-Type", "application/json")
                                   .header("Authorization", s"Bearer $token")
                                   .postData(body)
                                   .options(HttpOptions.allowUnsafeSSL)
    }

    class PostPresignedURL(baseUrl: String, token: String, filename: String, ingestionId: Int) extends APIRequest
    {
        val url: String = s"$baseUrl/api/v2/ingestion/uploads?ingestionId=$ingestionId"

        private val dateFormatted: String =
            new SimpleDateFormat("yyyyMMdd").format(Calendar.getInstance.getTime)

        val body: String =
            s"""{
               |  "partition": "$dateFormatted",
               |  "presignedUrlDuration": 120,
               |  "rawFileName": "$filename.parquet"
               |}
               |""".stripMargin

        val request: HttpRequest = Http(url)
                                   .header("Content-Type", "application/json")
                                   .header("Authorization", s"Bearer $token")
                                   .postData(body)
                                   .options(HttpOptions.allowUnsafeSSL)
    }

    class PutTableData(presignedURL: String, tableData: Array[Byte]) extends APIRequest
    {
        val url: String = presignedURL

        val request: HttpRequest = Http(url)
                                   .put(tableData)
                                   .options(HttpOptions.allowUnsafeSSL)
    }

}
