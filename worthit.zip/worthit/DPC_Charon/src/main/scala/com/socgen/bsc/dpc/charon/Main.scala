package com.socgen.bsc.dpc.charon

import com.socgen.bsc.dpc.charon.common.DPCProperties
import com.socgen.bsc.dpc.charon.engines.{IngestionUploader, SQLExtractor}
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}


object Main extends App
{
    //region Booting up

    // Argument parsing
    if (args.length != 1)
        throw new IllegalArgumentException("Usage : ./dpc_collect <path/to/config.properties>")

    // Configuration System
    implicit val hadoopConf: Configuration = new Configuration()
    hadoopConf.set("fs.defaultFS", "file:///")
    implicit val hadoopFileSystem: FileSystem = FileSystem.get(hadoopConf)

    // Reading properties
    val dpcProps: DPCProperties = DPCProperties(args.head)

    //endregion

    //region Extraction

    // Configuration connection SQL
    val extractor: SQLExtractor = SQLExtractor(dpcProps)

    // Query extraction
    val savedPaths: Seq[Path] = extractor.executeSqlFolder

    // Recap
    Console.err.println(s"Total extraction error count : ${extractor.errors.count}.")

    //endregion

    //region Upload

    // Configuration of the connection to the API
    val uploader: IngestionUploader = IngestionUploader(dpcProps)

    // Refreshing pipelines ?
    //uploader.deleteKnownPipelines

    // Uploading
    val srvsSent = uploader.sendParquets(savedPaths)

    // Recap
    Console.err.println(s"Total upload error count : ${uploader.errors.count}.")
    Console.err.println(s"Uploaded a total of ${srvsSent.size} SRVs !")

    //endregion

    //region Clean up

    // Removing sent parquets ?
    //srvsSent.map(path => hadoopFileSystem.delete(path, true))

    // Exiting with error code
    sys.exit(extractor.errors.count + uploader.errors.count)

    //endregion
}