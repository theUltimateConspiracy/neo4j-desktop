package com.socgen.bsc.dpc.charon.common

import java.io.FileNotFoundException
import java.util.Properties

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.security.alias.CredentialProviderFactory

import scala.collection.JavaConverters._
import scala.io.Source


class DPCProperties(props: Map[String, String])(implicit hadoopConf: Configuration = new Configuration)
{
    val jceksPath: Option[String] = props.get(DPCProperties.JceksPathKey)

    def get(key: String)(implicit hadoopConf: Configuration): String =
    {
        val value = props.get(key) match
        {
            case Some(_value) => _value
            case None         => throw new NoSuchFieldException(s"Key '$key' not found in properties file.")
        }

        expandIfNeeded(value)
    }

    def getOpt(key: String)(implicit hadoopConf: Configuration): Option[String] =
        props.get(key).map(expandIfNeeded)

    private def expandIfNeeded(value: String)(implicit hadoopConf: Configuration = new Configuration): String =
    {
        // Is it a special value ? (i.e. password stored in jceks)
        if (!value.startsWith(DPCProperties.ExpandPrefix))
            value

        else
        {
            // Action is only legal if a path is given
            if (jceksPath.isEmpty)
                throw new NoSuchFieldException(
                    s"Cannot expand jceks key $value while no '${DPCProperties.JceksPathKey}' has been defined in properties.")

            // Querying hadoop to decrypt it for us
            hadoopConf.set(CredentialProviderFactory.CREDENTIAL_PROVIDER_PATH, jceksPath.get)
            val jceksKey = value.stripPrefix(DPCProperties.ExpandPrefix)
            val expandedValue = hadoopConf.getPassword(jceksKey).mkString

            // Checking f previous operation succeeded
            if (expandedValue == null || expandedValue.isEmpty || expandedValue.equalsIgnoreCase(""))
                throw new NoSuchFieldException(
                    s"Error while expanding key $jceksKey in jceks file. Make sure jceks path is correct and key exists.")

            // All check passed, safe to return
            expandedValue
        }
    }
}

object DPCProperties
{
    val JceksPathKey = "jceksPath"
    val ExpandPrefix = "!"

    def apply(pathToPropFile: String): DPCProperties =
    {
        if (!pathToPropFile.endsWith(".properties"))
            throw new IllegalArgumentException("Argument must be a path to a *.properties file")

        try
        {
            val istream = Source.fromFile(pathToPropFile).bufferedReader
            val javaProps = new Properties
            javaProps.load(istream)
            val props = javaProps.asScala.toMap

            new DPCProperties(props)
        }
        catch
        {
            case e: FileNotFoundException =>
                throw new FileNotFoundException(s"Could not find properties file : $pathToPropFile")
            case e: Throwable             =>
                throw new RuntimeException(s"Unhandled Exception while reading properties file : ${e.getMessage}")
        }
    }
}