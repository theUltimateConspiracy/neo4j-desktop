package com.socgen.bsc.dpc.charon.engines

import com.socgen.bsc.dpc.charon.engines.{IngestionUploader, SQLExtractor}
import com.socgen.bsc.dpc.charon.common.DPCProperties

class StreamerCoordinator(ingestionUploader: IngestionUploader, SQLExtractor: SQLExtractor)
{
}

object StreamerCoordinator
{
    def apply(ingestionUploader: IngestionUploader,
              SQLExtractor: SQLExtractor): StreamerCoordinator = new StreamerCoordinator(ingestionUploader,
                                                                                         SQLExtractor)
}