
# Template general runbook

TODO: AD Group, Jenkins jobs description, Generic Account, namespace, envs.

## About This template

## Overview

### General architecture

In this section should appear the main architecture scheme with basics explanation. If it is already documented in a DMAP, give also a link to this document.

#### Example

BMR application main purpose is to provide to customers quotations of financial assets.

These quotations are retrieved from Bloomberg Web Service by a dedicated Endpoint (GET quotations).

It will retrieve last EndOfDay quotations of financial assets that have been created in the BMR PostGre database.

These quotations are then stored in BMR database.

User can define a financial asset. This asset must define a ticker which corresponds to Bloomberg ticker values to retrive this asset quotations.

User can define Yield Curves which consist in a list of financial assets.

User can retrieve quotations for a date range and a Yield curve identifier.

AIRFlow is used to retrieve Bloomberg quotations every day by invoking the GET quotations endpoint.

![General Architecture Scheme](img/tools_general_runbook_template_general_architecture.png)

More information can be found in the DMAP :

[DAMP Dusiness Market data referential](https://cube.ressources.socgen/teams/ShowRoomISAespaceequipe/DMAP%20qualified/DMAP_%20BuinessMarketdataReferential_A8596_v1-2_FR.pdf)

## Prerequisites

### Access

In this section, you will list all the access someone should have to be able to run, investigate and monitor the application. At least 2 points of contacts must be given in case of individual mail.

| Name | Link | Point of Contact | Comment |
| ---- | ---- | ---------------- | ------- |
| Cube | <https://cube.ressources.socgen/teams/ShowRoomISAespaceequipe/DMAP%20qualified/DMAP_%20BuinessMarketdataReferential_A8596_v1-2_FR.pdf> |
| KAT | <https://kat.safe.socgen/?controleur=gestion_composants&mode=view&id=5662> |
| SGithub | <https://sgithub.fr.world.socgen/RESG-BSC-DAT-LIQ-ALM/garliq-marketdata> | geremy.giuly@socgen.com aditya.kshettri@socgen.com |
| Openshift HML | <https://hogpmaster.dns21.socgen:8443/> | **Application**: geremy.giuly@socgen.com aditya.kshettri@socgen.com **Cluster**: GTS team | Namespace: bsc-bmr-a8596 Application: bsc-bmr-a8596-homol |
| Openshift PRD | <https://pogpmaster.dns20.socgen:8443/> | **Application**: geremy.giuly@socgen.com aditya.kshettri@socgen.com **Cluster**: GTS team |Namespace: bsc-bmr-a8596 Application: Bsc-bmr-a8596-prod |
| Jenkins | <https://sofa.dns20.socgen/jenkins-ogp/job/bsc-bmr-a8596/> | geremy.giuly@socgen.com aditya.kshettri@socgen.com |
| Grafana | <https://grafana-bsc-bmr-a8596.pogp.dns20.socgen> | geremy.giuly@socgen.com virginie.quesnay@socgen.com iannis.passelergue@socgen.com |
| Jump | corresponding Jump group |

### Contacts

Here you can find a table with the main contacts for the applications and their rôle

#### Example

| Name | Role | Mail |
| ---- | ---- | ---- |
| Giuly Geremy | Tech Lead | geremy.giuly@socgen.com |
| Iannis Passelergue | DevOps | iannis.passelergue@socgen.com |

## Build Process

### Local

How to build and run the application locally, for debugging purpose.  

All steps for building and making a package or other distribution mechanisms. If it is a software that you modify in any way (open source project you contribute to or a local project) include instructions for how a new developer gets started. Ideally the end result is a package that can be copied to other machines for installation.

It could be also a link to the README.md of the repository or a detailed explanation step by step.

#### Example

1. Clone the respository: git clone <https://sgithub.fr.world.socgen/RESG-BSC-DAT-LIQ-ALM/garliq-marketdata.git>
2. Ask for local-application.properties fiel to a member of the team
3. If necessary, setup a local postgre database to perform local test. The database information are in the .properties file.
4. Build application: mvn clean install
5. Launch .jar : /javapath/java -jar ./path_to_jar/marketdata-api-1.0.0-SNAPSHOT.jar --spring.config.location=../src/main/resources/local-application.properties
6. Go to <http://localhost:7070/marketdata/api/v1/swagger-ui.html>#!

*Note that you must not change the 7070 port else, you cannot authenticate with SGConnect.*

### Pipeline

Explain all pipeline steps, especially if it’s not standard. The example given below is a very standard deployment.

#### Exemple

Build process is a SOFA BSOFAAST standard one:

![BSOFAAST pipeline](img/tools_general_runbook_template_pipeline_example.png)

Url to Jenkins: <https://sofa.dns20.socgen/jenkins-ogp/job/bsc-bmr-a8596/>

- dev: you can specify the git branch you want to deploy. App will be build then started on Openshift dev pod
- homol: branch must be master branch. No snapshot version (pom.xml) must be present in the project.
- There are 3 options:
  - Build-Deploy: build app and deploy it to the homol environment
  - Build-Deploy-Promote: build app, deploy it to the homol environment and the Prod environment (and DR env if available)
  - Promote: deploy last homol build to the Prod env (and DR env if available)

## Deployment Process

How to deploy the software. How to build a server from scratch: RAM/disk requirements, OS version and configuration, what packages to install, and so on. If this is automated with a configuration management tool like ansible/terraform/bsofaast/… and the configuration settings used (config maps, …)

### Infrastructure

#### Example

BMR deployment infra uses BSofaast to create the BMR Openshift projects.
They are 4 environments:

- dev: development and test
- homol: used to test version that must be delivered in Production
- production: production
- dr: Disaster Recovery in case of production infra unavailability (not functional for the moment)

From Openshift, you can check if the application is running or not.  
You can update/add/remove environment variables.
All parameters which may differ by environment are defined as configuration variables in Openshift.  
Environment dependent parameters in application.properties file reference these configuration variables.

### Deployment

Deployment of the application for an environment must be done by using associated jenkins job.

#### Example

![BSOFAAST 1](img/tools_general_runbook_template_deployment_process1.png)
![BSOFAAST 2](img/tools_general_runbook_template_deployment_process2.png)
![BSOFAAST 3](img/tools_general_runbook_template_deployment_process3.png)
![BSOFAAST 4](img/tools_general_runbook_template_deployment_process4.png)

## Common Tasks

This section lists the common tasks that must be handled (ex: DB migration, cleaning, …)

#### Example

How to create issue/ report bug on JIRA (link)

Gitflow Use (link)

## Runbooks Incidents

This section will list all main incidents that have been encountered by the application team. Each occured incident must be a link to a specialized “incident runbook”.  

#### Example

- Runbook “Pod deployment failure” (lien)
- Runbook “Database access at startup failure”
- Runbook “Cannot reach Bloomberg”

## Alerts

All alerts must be listed here and how to react when encountered.

These alerts can be supervision alerts for example.

#### Example

| Type | Environement | Component name | Threshold | Action to take |
| ---- | ------------ | -------------- | --------- | -------------- |
| Mail with object [Alerting] [MARKET DATA][ENV] Application status has changed | DEV, HOMOL, PRD | MarketRate | On/Off | Go to Openshift and check for logs or events |

## Disaster Recovery Plan

If it exits and is applicable, the DR Plan must be detailed here, or at least a link to a disaster recovery plan document must be given. Explain the procedure to rollout to a former version and escalation strategy and communication plan.

## SLA/OLA

If the Application has SLA/OLA, give a link to KAT.

#### Example

<https://kat.safe.socgen/?controleur=gestion_composants&mode=view&id=5662>