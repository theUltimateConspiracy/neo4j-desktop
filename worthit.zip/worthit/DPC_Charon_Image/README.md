# DPC Charon's centralised Docker Image 

This repository builds the docker image from which the various [ForkMe repositories](https://sgithub.fr.world.socgen/BSC-DataEng/DPC_Charon_ForkMe) are based on.

Looking for the source code of Charon itself ? [Here it is](https://sgithub.fr.world.socgen/BSC-DataEng/DPC_Charon).

Is is meant for the DPC & ROL quarters exclusively.
