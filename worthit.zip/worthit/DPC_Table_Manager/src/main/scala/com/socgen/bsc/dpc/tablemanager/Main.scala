package com.socgen.bsc.dpc.tablemanager

import com.socgen.bsc.dpc.common.Reporting
import com.socgen.bsc.dpc.common.utility.PropertiesUtility
import com.socgen.bsc.dpc.iohandler.config.ConfigHandler
import com.socgen.bsc.dpc.tablemanager.common.Common
import com.socgen.bsc.dpc.tablemanager.json.TableManagerConfigurationParser
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession

object Main {
  /**
   * Main function to call with the arguments for table manager : filename
   *
   * @param args Array of arguments
   */
  def main(args: Array[String]): Unit = {
    val conf = new SparkConf()
      .setAppName("DPC formatter")
      .setIfMissing("master", "local[*]")

    implicit val spark: SparkSession = SparkSession
      .builder
      .config(conf)
      .config("spark.sql.hive.convertMetastoreParquet", "false")
      .config("spark.sql.legacy.allowNonEmptyLocationInCTAS", "true")
      .config("spark.sql.broadcastTimeout", "2000")
      .enableHiveSupport()
      .getOrCreate

    val arguments = Common.parseArguments(list = args.toList)
    val conf_H: Configuration = new Configuration()
    val hdfs = FileSystem.get(conf_H)

    val reporting = new Reporting("DPC formatter")

    val path = new Path(arguments.getOrElse(ConfigHandler.configPathArg, "no_config_path_found"))
    val inputStream = hdfs.open(path)
    val prop = PropertiesUtility.getProperties(inputStream)
    val (updatedJson, _) = ConfigHandler.getFullConf(arguments = arguments,
      prop = prop,
      hdfs = hdfs,
      conf_H = conf_H,
      reporting = reporting)

    TableManagerConfigurationParser.parseCleanConfigs(updatedJson) foreach {
      config => Common.writeOutputs(config, hdfs)
    }

    spark.stop
  }
}
