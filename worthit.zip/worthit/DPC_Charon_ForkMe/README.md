# DPC Charon K8S Pod template, a.k.a "ForkMe"

This repository is meant to be forked and templated by applications on SGCP to use the Charon extractor/uploader to upload their SRVs to the data lake as part of a recurrent workflow.

Looking for the source code of Charon itself ? [Here it is](https://sgithub.fr.world.socgen/BSC-DataEng/DPC_Charon).

## Prerequisites

* You have a *Jenkins* and a *Kubernetes* namespace at your disposal. 
* You have a Client ID and Secret created [through SG Connect](https://developer.sgmarkets.com/workspace/apis/clients) and subbed to the [Data-Ingestion API](https://developer.sgmarkets.com/explore/api/mybigdata) (with scopes : *manage* & *pushfiles*).
* You have made the Jira ticket to [associate your SG Client ID to your trigram](https://sgithub.fr.world.socgen/BSC-DataEng/IGD_Data_Ingestion/blob/develop_V2/docs/common/associateclientid/ticketjira.md).

## Quickstart

* Fork and template the repository..
* Add the CI and CD pipeline to your Jenkins.
* Run them (in this order).
* Done


## Exhaustive modus operandi

0. Contact us ! (Mailing list to be defined).
1. [Fork](https://docs.github.com/en/get-started/quickstart/fork-a-repo) this repository into you usual team repository.
2. Template the **acid** folder using your K8S information (namespace, credentials), and **conf/conf.properties** file with the database information (url, user credentials). Run the command ```grep -r "FIXME"``` to view all template fields.
3. Create your queries fetching the different SRVs in in the **conf/queries/** folder (or just a simple one to test it out)
4. Obfuscate your passwords using the method of your choice (*myVault*, *secret.yml*, or at the very least put your repository in private).
5. Select the **acid/CI/charon.casc.yml** file in your *sGitHub*, click on *Raw* then copy the link of the file to the *Jenkins* field located in *Administrer Jenkins* -> *Configure as Code*. Repeat for the **acid/CD/charon.casc.yml** file.
6. Run the newly created pipelines ***build-charon-image*** in the *datalake/homologation* folder, taking note of the image tag.
7. Run the **deplot-charon-pod** pipeline in the same folder, filling the image 
7. Follow your ingestion in your pod's log and IGD's Kibana.


## F.A.Q.

### How much time to market the solution ?

Heavily depends on your proficiency with *Kubernetes*. With every templated field values on hands, 2 hours is all it takes to go from forking the repository to deploying in homologation.

If the queries needs to be written, and with some fumbling on Git or K8S sides, an afternoon's worth of work is expected.


### Am I obligated to follow this template ?

Absolutely not ! This repository is simply a boilerplate created with the help of the K8S coaches.
Actually, reshaping it in accordance to your team's workflow and patterns is highly encouraged.

### How do I know if I am done templating ?

Running the command below in the project root will tell you any FIXME you might have missed.

```sh
grep -r "FIXME"
```

If it does not return anything, you are done templating !


### Why is there no homol / prod dichotomy in the CI folder ?

It is not an oversight. According to ACID's guidelines, you are not allowed to push a Docker image directly to the production DTR. Instead, you should import a homol image through the [Dev2Prod pipeline](https://acid-wiki.fr.world.socgen/2.3/acid/extras/dev2prod.html#using-jenkins-plugin-parameterized-remote-trigger).

Therefore, the only place where you can build and push an image is the non-prod DTR.

### How do I obfuscate my passwords ?

Copy from your other workflows ! However, please note that the preferred way is through *MyVault* with the *acid/K8S/\<env>/secret.yaml.template* files.
If you are not using *MyVault*, remember to remove the *Vault* stage in the *acid/CD/\<env>/charon.jenkinsfile* files. 

### How do I switch to a production environment ?

1. First and foremost, create a working homol pod and let it run for one or two days, while following its correct execution through its logs and IGD's Kibana.
2. Fetch your charon image url on the non-prod DTR and run the [Dev2Prod](https://acid-wiki.fr.world.socgen/2.3/acid/extras/dev2prod.html) pipeline.
3. You can then run the *deploy-charon-pod* pipeline in the *acid/CD/prod* subfolder.

### I'm stuck / I don't understand anything : Can I have help ?

Of course, just contact one of the most active contributors, they'll gladly help you !

### ...

## Best practices

TODO.