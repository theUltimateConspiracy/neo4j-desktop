#!/bin/bash
# Expanding conf.properties file with K8S env variables.
echo -e "$(eval "echo -e \"`< conf/conf.properties`\"")" > conf_expanded.properties

# TODO: Remove me once everything is working (no passwords in logs!)
echo "Expanded conf file is :" && \
    cat conf_expanded.properties && \
    echo

# TODO: Change java options as needed (recommended : 6GB)
echo "Launching Charon's jar" && \
    java -Xmx3G -jar charon.jar conf_expanded.properties
