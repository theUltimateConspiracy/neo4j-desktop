--- FIXME : Writes your requests, one per table.
--- The SRV in the datalake will take the same name as the SQ (i.e. 'table1').
SELECT * FROM public.table1