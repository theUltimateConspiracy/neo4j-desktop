package com.socgen.bsc.dpc.iohandler.output

import com.socgen.bsc.dpc.iohandler.dataframe.{Action, QueriesOptions}

/**
 * his case class define the attributes of the OutputConfiguration that will be used to write to a destination
 *
 * @param destination     String which will be used to determine the type of the destination
 * @param mode            SaveMode - either append or overwrite
 * @param partitionFields Set of columns used to partition the DataFrame
 * @param coalesce        Coalesce degree to reduce the number of partitions and reduce the number of output files
 * @param options         Map of string which must contain the
 * @param columnActions   Sequence of Action that will be used to transform the DataFrame
 * @param registerDF      Name of the registered table where the DataFrame (source + columnActions) will be saved
 * @param registerQueries Map of registered queries used to define intermediary DataFrame to get the final one
 */
case class OutputConfiguration(
                                destination: String,
                                mode: String,
                                partitionFields: Option[Seq[String]],
                                coalesce: Option[Int],
                                overwrite: Option[Boolean],
                                options: Option[Map[String, String]],
                                columnActions: Option[Seq[Action]],
                                registerDF: Option[String],
                                registerQueries: Option[Map[String, QueriesOptions]]
                              )