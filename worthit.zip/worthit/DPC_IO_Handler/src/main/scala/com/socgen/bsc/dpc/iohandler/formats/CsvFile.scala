package com.socgen.bsc.dpc.iohandler.formats

import com.socgen.bsc.dpc.common.exception.TechnicalException
import com.socgen.bsc.dpc.common.utility.FileUtility
import com.socgen.bsc.dpc.iohandler.common._
import com.socgen.bsc.dpc.iohandler.dataframe.DFHandler
import com.socgen.bsc.dpc.iohandler.input.InputConfiguration
import com.socgen.bsc.dpc.iohandler.output.OutputConfiguration
import org.apache.hadoop.fs.FileSystem
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * This object is used to read a DataFrame from a csv file and to store a DataFrame to a csv file
 */
object CsvFile {

  //region read

  /**
   * This function read a DataFrame from a CSV file according to the configuration given in the InputConfiguration object
   *
   * @param inputConfiguration InputConfiguration which specify the configuration to read the DataFrame from the defined
   *                           csv file
   * @param onS3               Boolean to specify in the resource is on S3 or not. Only concern files.
   * @param hdfs               Hdfs Configuration to read and write on hdfs
   * @param spark              Implicit Spark Session
   */
  def readFromInputConfig(inputConfiguration: InputConfiguration,
                          onS3: Boolean,
                          hdfs: FileSystem)
                         (implicit spark: SparkSession): DataFrame = {
    read(inputPath = inputConfiguration.source,
      options = inputConfiguration.options.getOrElse(Map.empty[String, String]),
      onS3 = onS3,
      hdfs = hdfs)
  }

  /**
   * This function read a DataFrame from a CSV file according to the configuration given in the arguments
   *
   * @param inputPath S3 or HDFS where the csv to read is stored
   * @param options   Map of string which must contain the mandatory options for CSV and potentially the options for the
   *                  S3 connection
   * @param onS3      Boolean to specify in the resource is on S3 or not. Only concern files.
   * @param hdfs      Hdfs Configuration to read and write on hdfs
   * @param spark     Implicit Spark Session
   */
  def read(inputPath: String,
           options: Map[String, String],
           onS3: Boolean,
           hdfs: FileSystem)
          (implicit spark: SparkSession): DataFrame = {
    try {
      val (s3Options, configOptions) = IoCommon.splitMapOption(map = options, regex = IoCommon.s3OptionRegex)
      if (onS3) {
        if (IoCommon.hasMandatoryOptions(options = s3Options, mandatoryOptions = IoCommon.s3MandatoryOptions)) {
          s3Options foreach {
            case (key: String, value: String) => spark.sparkContext.hadoopConfiguration.set(key, value)
          }
        } else
          throw TechnicalException(s"Exception raised while Reading CSV File $inputPath on s3; " +
            s"${IoCommon.displayMapOfStrings(myMap = s3Options)} does not contain the mandatory options : " +
            s"${IoCommon.displayListOfStrings(myList = IoCommon.s3MandatoryOptions)}")
      }
      if (IoCommon.hasMandatoryOptions(options = configOptions, mandatoryOptions = IoCommon.csvMandatoryOptions)) {
        spark.read.options(options).csv(inputPath)
      } else {
        throw TechnicalException(s"Exception raised while Reading CSV File $inputPath; " +
          s"${IoCommon.displayMapOfStrings(myMap = configOptions)} does not contain the mandatory options : " +
          s"${IoCommon.displayListOfStrings(myList = IoCommon.csvMandatoryOptions)}")
      }
    } catch {
      case e: Exception =>
        throw TechnicalException(s"An error occurred while read Csv File: $inputPath ; ERROR: $e")
    }
  }
  //endregion

  //region public_write

  /**
   * This functions save a DataFrame to a CSV file using the configuration defined in the object OutputConfiguration
   *
   * @param df                  DataFrame to write
   * @param outputConfiguration OutputConfiguration which specify the configuration to save the DataFrame in the defined
   *                            CSV file
   * @param coalesce            Coalesce degree to reduce the number of partitions and reduce the number of output files
   * @param mode                SaveMode - either append or overwrite
   * @param onS3                Boolean to specify in the resource is on S3 or not. Only concern files.
   * @param hdfs                Hdfs Configuration to read and write on hdfs
   * @param spark               Implicit Spark Session
   */
  def writeToOutputConfig(df: DataFrame,
                          outputConfiguration: OutputConfiguration,
                          coalesce: Option[Int] = None,
                          mode: Option[String] = None,
                          onS3: Boolean,
                          hdfs: FileSystem)
                         (implicit spark: SparkSession): Unit = {
    write(df = df,
      outputPath = outputConfiguration.destination,
      options = outputConfiguration.options.getOrElse(Map.empty[String, String]),
      coalesce = coalesce,
      mode = mode,
      onS3 = onS3,
      hdfs = hdfs)
  }

  /**
   * This functions save a DataFrame to a CSV file using the configuration defined in map of string
   *
   * @param df         DataFrame to write
   * @param outputPath S3 or Hdfs path where the CSV path will be stored
   * @param options    Map of string which must contain the mandatory options for CSV and S3 if the output is on s3
   * @param coalesce   Coalesce degree to reduce the number of partitions and reduce the number of output files
   * @param mode       SaveMode - either append or overwrite
   * @param onS3       Boolean to specify in the resource is on S3 or not. Only concern files.
   * @param hdfs       Hdfs Configuration to read and write on hdfs
   * @param spark      Implicit Spark Session
   */
  def write(df: DataFrame,
            outputPath: String,
            options: Map[String, String],
            coalesce: Option[Int] = None,
            mode: Option[String] = None,
            onS3: Boolean, hdfs: FileSystem)
           (implicit spark: SparkSession): Unit = {
    try {
      val (s3Options, csvOptions) = IoCommon.splitMapOption(map = options, regex = IoCommon.s3OptionRegex)
      if (onS3) {
        if (IoCommon.hasMandatoryOptions(options = s3Options, mandatoryOptions = IoCommon.s3MandatoryOptions)) {
          s3Options foreach {
            case (key: String, value: String) => spark.sparkContext.hadoopConfiguration.set(key, value)
          }
          if (IoCommon.hasMandatoryOptions(options = csvOptions, mandatoryOptions = IoCommon.csvMandatoryOptions)) {
            val saveMode = IoCommon.getSaveMode(mode.getOrElse(IoCommon.defaultMode))
            df.coalesce(coalesce.getOrElse(1))
              .write.mode(saveMode)
              .options(csvOptions)
              .csv(outputPath.replaceAll(".csv", ""))
          } else {
            throw TechnicalException(s"Exception raised while saving DF to CSV File $outputPath; " +
              s"${IoCommon.displayMapOfStrings(myMap = csvOptions)} does not contain the mandatory options : " +
              s"${IoCommon.displayListOfStrings(myList = IoCommon.csvMandatoryOptions)}")
          }
        } else
          throw TechnicalException(s"Exception raised while Writing Csv File on s3; " +
            s"${IoCommon.displayMapOfStrings(myMap = s3Options)} does not contain the mandatory options : " +
            s"${IoCommon.displayListOfStrings(myList = IoCommon.s3MandatoryOptions)}")
      } else {
        if (IoCommon.hasMandatoryOptions(options = csvOptions, mandatoryOptions = IoCommon.csvMandatoryOptions)) {
          val withHeader = csvOptions(IoCommon.headerOption).toBoolean
          saveToFile(df = df,
            outputPath = outputPath,
            withHeader = withHeader,
            csvSeparator = csvOptions(IoCommon.delimiterOption),
            hdfs = hdfs)

        } else {
          throw TechnicalException(s"Exception raised while saving DF to CSV File $outputPath; " +
            s"${IoCommon.displayMapOfStrings(myMap = csvOptions)} does not contain the mandatory options : " +
            s"${IoCommon.displayListOfStrings(myList = IoCommon.csvMandatoryOptions)}")
        }
      }
    } catch {
      case e: Throwable =>
        throw TechnicalException(s"Exception raised while saving DF to CSV File $outputPath; ERROR $e")
    }
  }
  //endregion


  //region private_write

  /**
   * This function save a DataFrame on HDFS and S3 following the configuration and use the HDFS Api to concatenates files
   *
   * @param df           DataFrame to write
   * @param outputPath   S3 or Hdfs path where the CSV path will be stored
   * @param withHeader   Boolean to specify if the CSV will have a header or not
   * @param csvSeparator String used as the separator for the CSV
   * @param hdfs         Hdfs Configuration to read and write on hdfs
   * @param spark        Implicit Spark Session
   */
  private def saveToFile(df: DataFrame,
                         outputPath: String,
                         withHeader: Boolean,
                         csvSeparator: String,
                         hdfs: FileSystem)
                        (implicit spark: SparkSession): Unit = {
    import spark.implicits._
    val headerColumns = df.columns
    headerColumns.headOption match {
      case Some(head) =>
        val singleColumnDF = if (withHeader) {
          val header = DFHandler.getHeader(headerColumns.tail, Seq(s"$head").toDF(s"$head"))
          header.union(df).filter(row => !(row.mkString("").isEmpty && row.length > 0))
            .map(row => row.mkString(csvSeparator))
            .toDF("line")
        } else {
          df.filter(row => !(row.mkString("").isEmpty && row.length > 0))
            .map(row => row.mkString(csvSeparator))
            .toDF("line")
        }
        FileUtility.exportDFToCSVFile(singleColumnDF, outputPath, hdfs, withHeader)
      case _ =>
        throw TechnicalException(s"Dataframe is empty for ouput : $outputPath")
    }
  }
  //endregion
}