package com.socgen.bsc.dpc.iohandler.dataframe

import com.socgen.bsc.dpc.common.exception.TechnicalException
import com.socgen.sdt.logging.loggers.impl.DataLoggerFactory
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import org.slf4j.Logger
import scala.collection.mutable.ListBuffer
import scala.annotation.tailrec
import scala.collection.mutable.WrappedArray

object ProcessColumnActions {
  // ACTIONS
  private final val addColumnAction = "ADD"
  private final val deleteColumnAction = "DELETE"
  private final val renameColumnAction = "RENAME"
  private final val castColumnAction = "CAST"
  private final val filterColumnAction = "FILTER"
  private final val filterExpressionColumnAction = "FILTER_EXPR"
  private final val trimColumnAction = "TRIM"
  private final val upperColumnAction = "UPPER"
  private final val lowerColumnAction = "LOWER"
  private final val searchHierarchyAction = "HIERARCHY"

  lazy val log: Logger = DataLoggerFactory.getLogger("tablemanager.common.ProcessColumnActions")

  /**
   * This functions will apply recursively a sequence of actions to a DataFrame
   *
   * @param actions Sequence of actions to apply to the DataFrame
   * @param df      Dataframe to change
   * @return
   */
  @tailrec
  def runActionsRec(actions: Seq[Action],
                    df: DataFrame): DataFrame = {
    if (actions.isEmpty)
      df
    else
      runActionsRec(actions.tail,
        df.transform(runAction(actions.head)))
  }

  /**
   * This functions will apply a sequence of actions to a DataFrame using an accumulator
   *
   * @param actions Sequence of actions to apply to the DataFrame
   * @param df      Dataframe to change
   * @return
   */
  def runActionsAcc(actions: Seq[Action],
                    df: DataFrame): DataFrame = {
    if (actions.isEmpty) df
    else
      actions.foldLeft(df) {
        (acc, action) => acc.transform(runAction(action))
      }
  }

  /**
   * This function will identify and apply an action to a DataFrame
   *
   * @param action Action object containing the mandatory information to identify and apply the action
   * @return
   */
  private def runAction(action: Action): DataFrame => DataFrame = {
    df =>
      if (action.actionType == addColumnAction) {
        getDFforAddAction(df = df, newColumn = action.newColumn, newColumnType = action.newColumnType, defaultValue = action.value)
      } else if (action.actionType == deleteColumnAction) {
        getDFForDeleteAction(df = df, column = action.column)
      } else if (action.actionType == renameColumnAction) {
        getDFForRenameAction(df = df, column = action.column, newColumn = action.newColumn)
      } else if (action.actionType == searchHierarchyAction) {
        getHierarchy(df = df, column = action.column)
      } else if (action.actionType == castColumnAction) {
        getDFForCastAction(df = df, column = action.column, newColumnType = action.newColumnType)
      } else if (action.actionType == filterColumnAction) {
        getDFForFilterAction(df = df, column = action.column, filterValue = action.value, comparison = action.comparison)
      } else if (action.actionType == filterExpressionColumnAction) {
        getDFForFilterExpressionAction(df = df, filterExpression = action.filterExpression)
      } else if (action.actionType == trimColumnAction) {
        getDFForTrimAction(df = df, column = action.column)
      } else if (action.actionType == lowerColumnAction) {
        getDFForLowerAction(df = df, column = action.column)
      } else if (action.actionType == upperColumnAction) {
        getDFForUpperAction(df = df, column = action.column)
      } else {
        throw TechnicalException(s"Unsupported action type : ${action.actionType}")
      }
  }

  /**
   * This function will rename a column on the DataFrame
   *
   * @param df        DataFrame on which the rename action will be applied
   * @param column    Column which will be renamed
   * @param newColumn New name of the column
   * @return
   */
  private def getDFForRenameAction(df: DataFrame,
                                   column: Option[String],
                                   newColumn: Option[String]): DataFrame = {
    column match {
      case Some(columnToDelete) if columnToDelete.trim != "" =>
        val columns = df.columns.map(_.toLowerCase)
        if (columns contains columnToDelete.toLowerCase)
          newColumn match {
            case Some(columnToAdd) if columnToAdd.trim != "" && !columnToAdd.contains('.') =>
              df.withColumnRenamed(columnToDelete, columnToAdd)
            case Some(columnToAdd) if columnToAdd.trim == "" || columnToAdd.contains('.') =>
              throw TechnicalException(s"Non valid new column name : $columnToAdd, column can not be renamed")
            case _ =>
              throw TechnicalException(s"Undefined new column name, column can not be renamed")
          }
        else
          throw TechnicalException(s"Columns to delete ($columnToDelete) " +
            s"is not a member of given input columns : [${columns.mkString(";")}]")
      case Some(columnToDelete) if columnToDelete.trim == "" || columnToDelete.contains('.') =>
        throw TechnicalException(s"Non valid column name : $columnToDelete, column can not be renamed")
      case _ =>
        throw TechnicalException(s"Undefined column name, column can not be renamed")
    }
  }

  /**
   * This function will remove the column on the DataFrame
   *
   * @param df     DataFrame on which the delete action will be applied
   * @param column The column which will be deleted
   * @return
   */
  private def getDFForDeleteAction(df: DataFrame,
                                   column: Option[String]): DataFrame = {
    column match {
      case Some(columnToDelete) if columnToDelete.trim != "" && !columnToDelete.contains('.') =>
        val columns = df.columns.map(_.toLowerCase)
        if (columns contains columnToDelete.toLowerCase)
          df.drop(columnToDelete)
        else
          throw TechnicalException(s"Columns to delete ($columnToDelete) " +
            s"is not a member of given input columns : [${columns.mkString(";")}]")
      case Some(columnToDelete) if columnToDelete.trim == "" || columnToDelete.contains('.') =>
        throw TechnicalException(s"Non valid column name : $columnToDelete, column can not be deleted")
      case _ =>
        throw TechnicalException(s"Undefined column name, column can not be deleted")
    }
  }

  /**
   * This function will add a column on the DataFrame with a specified type and a possible default value
   *
   * @param df            DataFrame on which the add action will be applied
   * @param newColumn     Column to be added to the DataFrame
   * @param newColumnType Type of the column that will be added
   * @param defaultValue  Optional - Default value
   * @return
   */
  private def getDFforAddAction(df: DataFrame,
                                newColumn: Option[String],
                                newColumnType: Option[String],
                                defaultValue: Option[String]): DataFrame = {
    newColumn match {
      case Some(columnToAdd) if columnToAdd.trim != "" && !columnToAdd.contains('.') =>
        newColumnType match {
          case Some(columnTypeToAdd) =>
            val dataType = DFHandler.getDataType(columnTypeToAdd)
            df.withColumn(columnToAdd, lit(defaultValue.getOrElse("")).cast(dataType))
          case _ => throw TechnicalException(s"Undefined column type for new column : $columnToAdd, column can not be added")
        }
      case Some(columnToAdd) if columnToAdd.trim == "" || columnToAdd.contains('.') =>
        throw TechnicalException(s"Non valid new column name : $columnToAdd, column can not be added")
      case _ =>
        throw TechnicalException(s"Undefined new column name, column can not be added")

    }
  }

  /**
   * This function will cast a column of the DataFrame
   *
   * @param df            DataFrame on which the cast action will be applied
   * @param column        Column to cast
   * @param newColumnType New type of the column
   * @return
   */
  private def getDFForCastAction(df: DataFrame,
                                 column: Option[String],
                                 newColumnType: Option[String]): DataFrame = {
    column match {
      case Some(columnToCast) if columnToCast.trim != "" && !columnToCast.contains('.') =>
        val columns = df.columns.map(_.toLowerCase)
        if (columns contains columnToCast.toLowerCase)
          newColumnType match {
            case Some(castType) => val dataType = DFHandler.getDataType(castType)
              try {
                df.withColumn(columnToCast, col(columnToCast).cast(dataType))
              } catch {
                case e: Exception => throw TechnicalException(s"Columns ($columnToCast) can't be casted to $dataType; Error $e")
              }
            case _ => throw TechnicalException(s"Columns ($columnToCast) can't be casted because new type is not specified")
          }
        else
          throw TechnicalException(s"Columns to cast ($columnToCast) is not a member of given input columns : [${columns.mkString(";")}]")
      case Some(columnToCast) if columnToCast.trim == "" || columnToCast.contains('.') =>
        throw TechnicalException(s"Non valid column name : $columnToCast, column can not be casted")
      case _ =>
        throw TechnicalException(s"Undefined column name, column can not be casted")
    }
  }

  /**
   * This function will filter on a column of a DataFrame
   *
   * @param df          DataFrame on which the filter action will be applied
   * @param column      The column on which which will be aplied
   * @param filterValue The value used to compare
   * @param comparison  The comparison applied : equal, gt, gte, lt, lte, different, mandatory
   * @return
   */
  private def getDFForFilterAction(df: DataFrame,
                                   column: Option[String],
                                   filterValue: Option[String],
                                   comparison: Option[String]): DataFrame = {
    column match {
      case Some(columnToFilter) if columnToFilter.trim != "" && !columnToFilter.contains('.') =>
        val columns = df.columns.map(_.toLowerCase)
        if (columns contains columnToFilter.toLowerCase)
          filterValue match {
            case Some(filteringValue) =>
              comparison match {
                case Some(operator) => if (operator == "==" || operator == "equal") {
                  try {
                    df.filter(col(columnToFilter) === filteringValue)
                  } catch {
                    case e: Exception =>
                      throw TechnicalException(s"Columns ($columnToFilter) can't be filtered by '$filteringValue'; Error $e")
                  }
                } else if (operator == ">" || operator == "gt") {
                  try {
                    df.filter(col(columnToFilter) > filteringValue)
                  } catch {
                    case e: Exception =>
                      throw TechnicalException(s"Columns ($columnToFilter) can't be filtered by '$filteringValue'; Error $e")
                  }
                } else if (operator == ">=" || operator == "gte") {
                  try {
                    df.filter(col(columnToFilter) >= filteringValue)
                  } catch {
                    case e: Exception =>
                      throw TechnicalException(s"Columns ($columnToFilter) can't be filtered by '$filteringValue'; Error $e")
                  }
                } else if (operator == "<" || operator == "lt") {
                  try {
                    df.filter(col(columnToFilter) < filteringValue)
                  } catch {
                    case e: Exception =>
                      throw TechnicalException(s"Columns ($columnToFilter) can't be filtered by '$filteringValue'; Error $e")
                  }
                } else if (operator == "<=" || operator == "lte") {
                  try {
                    df.filter(col(columnToFilter) <= filteringValue)
                  } catch {
                    case e: Exception =>
                      throw TechnicalException(s"Columns ($columnToFilter) can't be filtered by '$filteringValue'; Error $e")
                  }
                } else if (operator == "!=" || operator == "different") {
                  try {
                    df.filter(col(columnToFilter) =!= filteringValue)
                  } catch {
                    case e: Exception =>
                      throw TechnicalException(s"Columns ($columnToFilter) can't be filtered by '$filteringValue'; Error $e")
                  }
                } else {
                  throw TechnicalException(s"Columns ($columnToFilter) can't be filtered by '$filteringValue'; Unrecognized operator $operator")
                }
                case _ => try {
                  df.filter(col(columnToFilter) === filteringValue)
                } catch {
                  case e: Exception =>
                    throw TechnicalException(s"Columns ($columnToFilter) can't be filtered by '$filteringValue'; Error $e")
                }
              }
            case _ =>
              //noinspection ScalaUnnecessaryParentheses
              comparison match {
                case Some(operator) if (operator == "mandatory") =>
                  df.filter(col(columnToFilter).isNotNull)
                case _ =>
                  throw TechnicalException(s"Columns ($columnToFilter) can't be filtered because value to filter is not specified")
              }
          }
        else
          throw TechnicalException(s"Columns to filter ($columnToFilter) is not a member of given input columns : [${columns.mkString(";")}]")
      case Some(columnToFilter) if columnToFilter.trim == "" || columnToFilter.contains('.') =>
        throw TechnicalException(s"Non valid column name : $columnToFilter, column can not be filtered")
      case _ => throw TechnicalException(s"Undefined column name, column can not be filtered")
    }
  }

  /**
   * This function will apply a filter expression on the Dataframe
   *
   * @param df               DataFrame on which the filter action will be applied
   * @param filterExpression The filter expression to use
   * @return
   */
  private def getDFForFilterExpressionAction(df: DataFrame, filterExpression: Option[String]): DataFrame = {
    filterExpression match {
      case Some(expression) => try {
        df.filter(expression)
      } catch {
        case e: Exception => throw TechnicalException(s"DataFrame can't be filtered by `$expression`; Error $e")
      }
      case _ => throw TechnicalException(s"Undefined filterExpression, dataframe can not be filtered")
    }
  }

  /**
   * This function will lower the values of the specified column of the DataFrame
   *
   * @param df     DataFrame on which the lower action will be applied
   * @param column The column on which the values will be lowered
   * @return
   */
  private def getDFForLowerAction(df: DataFrame, column: Option[String]): DataFrame = {
    column match {
      case Some(columnToLower) if columnToLower.trim != "" && !columnToLower.contains('.') =>
        val columns = df.columns.map(_.toLowerCase)
        if (columns contains columnToLower.toLowerCase)
          changeCaseColumn(df = df, columnName = columnToLower)
        else
          throw TechnicalException(s"Columns to lower ($columnToLower) is not a member of given input columns : [${columns.mkString(";")}]")
      case _ => throw TechnicalException(s"Undefined column name, column can not be lowered")
    }
  }

  /**
   * This function will either lower or upper the values of a column in a DataFrame
   *
   * @param df         DataFrame on which the lower or upper action will be applied
   * @param columnName Column on which the values will be either lowered or uppered case
   * @param toLower    If set to true the values will be lowered else uppered, default value is true
   * @return
   */
  private def changeCaseColumn(df: DataFrame, columnName: String, toLower: Boolean = true): DataFrame = {
    if (toLower)
      df.withColumn(columnName, lower(col(columnName)))
    else
      df.withColumn(columnName, upper(col(columnName)))
  }

  /**
   * This function will upper the values of the specified column of the DataFrame
   *
   * @param df     DataFrame on which the upper action will be applied
   * @param column The column on which the values will be uppered
   * @return
   */
  private def getDFForUpperAction(df: DataFrame, column: Option[String]): DataFrame = {
    column match {
      case Some(columnToUpper) if columnToUpper.trim != "" && !columnToUpper.contains('.') =>
        val columns = df.columns.map(_.toLowerCase)
        if (columns contains columnToUpper.toLowerCase)
          changeCaseColumn(df = df, columnName = columnToUpper, toLower = false)
        else
          throw TechnicalException(s"Columns to upper ($columnToUpper) is not a member of given input columns : [${columns.mkString(";")}]")
      case _ => throw TechnicalException(s"Undefined column name, column can not be uppered")
    }
  }

  /**
   * This function will trim the values of the specified column of the DataFrame
   *
   * @param df     DataFrame on which the trim action will be applied
   * @param column The column on which the values will be trimmed
   * @return
   */
  private def getDFForTrimAction(df: DataFrame, column: Option[String]): DataFrame = {
    column match {
      case Some(columnToTrim) if columnToTrim.trim != "" && !columnToTrim.contains('.') =>
        val columns = df.columns.map(_.toLowerCase)
        if (columns contains columnToTrim.toLowerCase)
          df.withColumn(columnToTrim, trim(col(columnToTrim)))
        else
          throw TechnicalException(s"Columns to trim ($columnToTrim) is not a member of given input columns : [${columns.mkString(";")}]")
      case _ => throw TechnicalException(s"Undefined column name, column can not be trimmed")
    }
  }


  /**
   * This functions will apply recursively a search for list of all child
   *
   * @param data for each node , we will have list of children
   * @param status for each node , we will have boolean value : True if the search is done ( we have the list of all child , else False )
   * @param node this is an input to search for a specific node
   * @param index_dev this is iterative value to stop the algorithm if there is cycle
   * @return
   */

   def processHierarchy(data : Map[String, WrappedArray[String]] ,status  :Map[String, Boolean] , node : String = "DefaultValueNode" , index_dev : Int  = 0) : List[Any]  = {
    if (index_dev > 100)
      throw TechnicalException(s"Infinite looping of children")
    var aux_result = data(node)
    var new_data = data
    var new_status = status
    for (element <- data(node)  if data.contains(element) ) {
      if (new_data(node) == true ){
        aux_result = aux_result ++ new_data(element)
      }
      else {
      val reuslt_list = processHierarchy(new_data,new_status,element , index_dev + 1)
      new_data = reuslt_list(0).asInstanceOf[Map[String, WrappedArray[String]]]
      new_status = reuslt_list(1).asInstanceOf[Map[String, Boolean]]
      aux_result = aux_result ++ new_data(element)
      }
    }
    new_data = new_data + (node -> aux_result.asInstanceOf[WrappedArray[String]].distinct )
    new_status = new_status + (node -> true )
    return List(new_data , new_status)
  }

  /**
   * This functions will apply recursively a search for list of all child
   *
   * @param df  dataframe to apply the proccess
   * @param column  this input will be columnfather;columnson. to split and process
   * @return
   */
  private def getHierarchy(df: DataFrame,
                           column: Option[String] ): DataFrame = {
    column match {
      case Some(columnToProcess) if columnToProcess.trim != "" && !columnToProcess.contains('.') =>
            try {
              val list_col= columnToProcess.split(";")
              val processed = df.select (col (list_col(0)).as ("father"), col (list_col(1)) .as ("son") )
                .withColumn("father",col("father").cast("string"))
                .withColumn("son",col("son").cast("string"))
                .groupBy("father")
                .agg(collect_set("son").as("list_child"))
                .withColumn("processed",lit( 1 > 2))
              var new_data = processed.collect.map( r => (r(0) , r(1) ) ).toMap.asInstanceOf[Map[String, WrappedArray[String]]]
              var new_status = processed.collect.map( r => (r(0) , r(1) ) ).toMap.asInstanceOf[Map[String, Boolean]]
              for (element <- new_status.filterKeys(_ => true).keys) {
                val result_list = processHierarchy(new_data, new_status, element)
                new_data = result_list.head.asInstanceOf[Map[String, WrappedArray[String]]]
                new_status = result_list(1).asInstanceOf[Map[String, Boolean]]
              }
              val convertCase = (str: String) => new_data(str.asInstanceOf[String])
              val convertUDF = udf(convertCase)
              return df.withColumn("children_list", convertUDF(col("father")))

            } catch {
            case e: Exception => throw TechnicalException (s"Columns ($columnToProcess) can't be processed split error; Error $e")
            }
      case Some(columnToProcess) if columnToProcess.trim == "" || columnToProcess.contains('.') =>
        throw TechnicalException(s"Non valid column name : $columnToProcess, column can not be processed")
      case _ =>
        throw TechnicalException(s"Undefined column name, column can not be casted")
    }

  }




}
