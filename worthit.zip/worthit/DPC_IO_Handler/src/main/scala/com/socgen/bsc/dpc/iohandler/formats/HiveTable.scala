package com.socgen.bsc.dpc.iohandler.formats

import com.socgen.bsc.dpc.common.exception.TechnicalException
import com.socgen.bsc.dpc.common.logger.ContentToJson._
import com.socgen.bsc.dpc.common.logger.Count
import com.socgen.bsc.dpc.iohandler.common.IoCommon
import com.socgen.bsc.dpc.iohandler.input.InputConfiguration
import com.socgen.bsc.dpc.iohandler.output.OutputConfiguration
import com.socgen.sdt.logging.loggers.impl.DataLoggerFactory
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

/**
 * This object is used to read a DataFrame from a Hive table and to write a DataFrame to a Hive table
 */
object HiveTable {
  private lazy val log = DataLoggerFactory.getLogger("sources.HiveTable")

  //region read

  /**
   * This function will read a Hive table according to the configuration defined in the InputConfiguration object
   *
   * @param inputConfiguration InputConfiguration which specify the configuration to read the DataFrame from the defined
   * @param spark              Implicit Spark Session
   */
  def readFromInputConfig(inputConfiguration: InputConfiguration)
                         (implicit spark: SparkSession): DataFrame = {
    read(completeTableName = inputConfiguration.source)
  }

  /**
   * This function will read the defined Hive table
   *
   * @param completeTableName Complete table name which follow the pattern database.tableName
   * @param spark             Implicit Spark Session
   */
  def read(completeTableName: String)
          (implicit spark: SparkSession): DataFrame = {
    try {
      spark.sql(s"SELECT * FROM $completeTableName")
    } catch {
      case e: Exception =>
        throw TechnicalException(s"An error occurred while reading Hive Table: $completeTableName ; ERROR: $e")
    }
  }
  //endregion

  /**
   * This function will write the given DataFrame according to the given OutputConfiguration object
   *
   * @param df                  DataFrame to write
   * @param outputConfiguration OutputConfiguration which specify the configuration to save the DataFrame in the defined
   *                            Hive table
   * @param mode                SaveMode with higher priority than the mode defined in the ouputConfiguration object
   * @param overwrite           Boolean to specify if it is an overwrite (Spark puts a lock on the table when it read.
   *                            A Table can't be read and rewrite directly, a temporary intermediary table is needed)
   * @param hdfs                Hdfs Configuration to read and write on hdfs
   * @param spark               Implicit Spark Session
   */
  def writeToOutputConfig(df: DataFrame,
                          outputConfiguration: OutputConfiguration,
                          mode: Option[String],
                          overwrite: Boolean,
                          hdfs: FileSystem)
                         (implicit spark: SparkSession): Unit = {
    write(df = df, outputConfiguration = outputConfiguration, overwrite = overwrite, mode = mode, hdfs = hdfs)
  }

  //region public_write

  /**
   * This function will write the given DataFrame according to the given OutputConfiguration object
   *
   * @param df                  DataFrame to write
   * @param outputConfiguration OutputConfiguration which specify the configuration to save the DataFrame in the defined
   *                            Hive table
   * @param overwrite           Boolean to specify if it is an overwrite (Spark puts a lock on the table when it read.
   *                            A Table can't be read and rewrite directly, a temporary intermediary table is needed)
   * @param mode                SaveMode with higher priority than the mode defined in the ouputConfiguration object
   * @param hdfs                Hdfs Configuration to read and write on hdfs
   * @param spark               Implicit Spark Session
   */
  def write(df: DataFrame,
            outputConfiguration: OutputConfiguration,
            overwrite: Boolean,
            mode: Option[String],
            hdfs: FileSystem)
           (implicit spark: SparkSession): Unit = {
    try {
      val options = outputConfiguration.options.getOrElse(Map.empty[String, String])
      val outputTable = outputConfiguration.destination
      if (!IoCommon.hasMandatoryOptions(options = options, mandatoryOptions = IoCommon.hiveMandatoryOptions)) {
        throw TechnicalException(s"Exception raised while saving DF to Hive Table $outputTable; " +
          s"${IoCommon.displayMapOfStrings(myMap = options)} does not contain the mandatory options :" +
          s"${IoCommon.displayListOfStrings(myList = IoCommon.hiveMandatoryOptions)}")
      }
      val saveMode = mode.getOrElse(outputConfiguration.mode)
      val partitionFields = outputConfiguration.partitionFields.getOrElse(Seq())
      val pathDatabase = options(IoCommon.pathOption)
      write(df = df,
        outputTable = outputTable,
        pathDatabase = pathDatabase,
        partitionFields = partitionFields,
        overwrite = overwrite,
        mode = saveMode,
        coalesce = outputConfiguration.coalesce,
        hdfs = hdfs)
    } catch {
      case e: Throwable =>
        throw TechnicalException(s"Exception raised while saving DF to Hive Table ${outputConfiguration.destination}; " +
          s"ERROR $e")
    }
  }

  /**
   * This function will write the given DataFrame according to the given configuration
   *
   * @param df              DataFrame to write
   * @param outputTable     Hive table where to store the DataFrame
   * @param pathDatabase    Path where to store the parquet files composing the hive table
   * @param partitionFields Set of columns used to partition the DataFrame
   * @param overwrite       Boolean to specify if it is an overwrite (Spark puts a lock on the table when it read.
   *                        A Table can't be read and rewrite directly, a temporary intermediary table is needed)
   * @param mode            SaveMode - either append or overwrite
   * @param coalesce        Coalesce degree to reduce the number of partitions and reduce the number of output files
   * @param hdfs            Hdfs Configuration to read and write on hdfs
   * @param spark           Implicit Spark Session
   */
  def write(df: DataFrame,
            outputTable: String,
            pathDatabase: String = "",
            partitionFields: Seq[String] = Seq(),
            overwrite: Boolean = false,
            mode: String = IoCommon.defaultMode,
            coalesce: Option[Int] = None,
            hdfs: FileSystem)
           (implicit spark: SparkSession): Unit = {
    try {
      if (overwrite) {
        overwriteTable(df = df,
          table = outputTable,
          pathDatabase = pathDatabase,
          partitionFields = partitionFields,
          coalesce = coalesce,
          hdfs = hdfs)
      } else {
        val saveMode = IoCommon.getSaveMode(mode)
        saveTable(df = df,
          outputTable = outputTable,
          pathDatabase = pathDatabase,
          partitionFields = partitionFields,
          coalesce = coalesce,
          mode = saveMode)
      }
    } catch {
      case e: Throwable =>
        throw TechnicalException(s"Exception raised while saving DF to Hive Table $outputTable; ERROR $e")
    }
  }
  //endregion

  //region private_write

  /**
   * This function will write the given DataFrame according to the given
   *
   * @param df                   DataFrame to write
   * @param outputTable          Hive table where to store the DataFrame
   * @param pathDatabase         Path where to store the parquet files composing the hive table
   * @param partitionFields      Set of columns used to partition the DataFrame
   * @param mode                 SaveMode - either append or overwrite
   * @param coalesce             Coalesce degree to reduce the number of partitions and reduce the number of generated
   *                             files
   * @param optionalNumberOfRows Optional - Number of rows contained in the DataFrame, used for checking
   * @param spark                Implicit Spark Session
   */
  private def saveTable(df: DataFrame,
                        outputTable: String,
                        pathDatabase: String,
                        partitionFields: Seq[String],
                        mode: SaveMode,
                        coalesce: Option[Int] = None,
                        optionalNumberOfRows: Option[Long] = None)
                       (implicit spark: SparkSession): Unit = {
    val numberOfRows = optionalNumberOfRows match {
      case Some(number) => number
      case _ => df.count
    }
    if (numberOfRows == 0) {
      throw TechnicalException(s"Dataframe to save is empty")
    } else {
      val options = Map("encoding" -> "UTF-8",
        "path" -> IoCommon.getTablePath(databasePath = pathDatabase,
          table = outputTable))

      if (partitionFields.nonEmpty)
        df.coalesce(coalesce.getOrElse(1))
          .write
          .partitionBy(partitionFields: _*)
          .mode(mode)
          .options(options)
          .saveAsTable(outputTable)
      else
        df.coalesce(coalesce.getOrElse(1))
          .write
          .mode(mode)
          .options(options)
          .saveAsTable(outputTable)
    }
  }

  /**
   * This function allows to overwrite a table locked by Spark while read. It will create a temporary table, remove the
   * old one and rename the temporary table to the output table
   *
   * @param df              DataFrame to write
   * @param table           Hive table where to store the DataFrame
   * @param pathDatabase    Path where to store the parquet files composing the hive table
   * @param partitionFields Set of columns used to partition the DataFrame
   * @param coalesce        Coalesce degree to reduce the number of partitions and reduce the number of output files
   * @param hdfs            Hdfs Configuration to read and write on hdfs
   * @param spark           Implicit Spark Session
   */
  private def overwriteTable(df: DataFrame,
                             table: String,
                             pathDatabase: String,
                             partitionFields: Seq[String],
                             coalesce: Option[Int] = None,
                             hdfs: FileSystem)
                            (implicit spark: SparkSession): Unit = {
    val numberOfRows = df.count
    if (numberOfRows == 0) {
      throw TechnicalException(s"Dataframe to save is empty")
    } else {
      val tempTable = s"${table}_temp"

      spark.sql(s"DROP TABLE IF EXISTS $tempTable")

      saveTable(df = df,
        outputTable = tempTable,
        pathDatabase = pathDatabase,
        partitionFields = partitionFields,
        mode = SaveMode.Overwrite,
        coalesce = coalesce,
        optionalNumberOfRows = Some(numberOfRows))

      val tempDF = spark.sql(s"SELECT * FROM $tempTable")

      val persistedRows = tempDF.count
      if (persistedRows == numberOfRows) {
        saveTable(df = tempDF,
          outputTable = table,
          pathDatabase = pathDatabase,
          partitionFields = partitionFields,
          mode = SaveMode.Overwrite,
          coalesce = coalesce,
          optionalNumberOfRows = Some(persistedRows))

        spark.sql(s"DROP TABLE IF EXISTS $tempTable")
        hdfs.delete(new Path(IoCommon.getTablePath(databasePath = pathDatabase, table = tempTable)))
        log.info(Count(table, numberOfRows.toInt))
      } else {
        throw TechnicalException(s"An exception occurred while persisting table, number of rows in DataFrame $numberOfRows # number of persisted rows $persistedRows")
      }
    }
  }
  //endregion
}