package com.socgen.bsc.dpc.iohandler.dataframe

import com.socgen.bsc.dpc.common.exception.TechnicalException
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.types._

import scala.annotation.tailrec

/**
 *
 */
object DFHandler {
  /**
   * Available DataTypes :
   * StringType
   * DateType
   * TimestampType
   * BooleanType
   * CalendarIntervalType
   * BinaryType
   * ShortType
   * IntegerType
   * LongType
   * FloatType
   * DoubleType
   * ByteType
   * DecimalType
   * Non Available DataTypes :
   * ArrayType
   * MapType
   * StructType
   * NumericType
   * HiveStringType
   * ObjectType
   * NullType
   */
  private final val stringType = "StringType"
  private final val dateType = "DateType"
  private final val timestampType = "TimestampType"
  private final val booleanType = "BooleanType"
  private final val calendarIntervalType = "CalendarIntervalType"
  private final val binaryType = "BinaryType"
  private final val shortType = "ShortType"
  private final val integerType = "IntegerType"
  private final val longType = "LongType"
  private final val floatType = "FloatType"
  private final val doubleType = "DoubleType"
  private final val byteType = "ByteType"
  private final val decimalType = "DecimalType"
  private final val decimalTypePattern = """DecimalType\([ ]*([0-9]+)[ ]*,[ ]*([0-9]+)[ ]*\)""".r

  /**
   * Given a String, this function will return a DataType
   *
   * @param dataType DataType (Spark DataType)
   */
  def getDataType(dataType: String): DataType = {
    if (dataType.trim.toLowerCase == stringType.toLowerCase) StringType
    else if (dataType.trim.toLowerCase == dateType.toLowerCase) DateType
    else if (dataType.trim.toLowerCase == timestampType.toLowerCase) TimestampType
    else if (dataType.trim.toLowerCase == booleanType.toLowerCase) BooleanType
    else if (dataType.trim.toLowerCase == calendarIntervalType.toLowerCase) CalendarIntervalType
    else if (dataType.trim.toLowerCase == binaryType.toLowerCase) BinaryType
    else if (dataType.trim.toLowerCase == shortType.toLowerCase) ShortType
    else if (dataType.trim.toLowerCase == integerType.toLowerCase) IntegerType
    else if (dataType.trim.toLowerCase == longType.toLowerCase) LongType
    else if (dataType.trim.toLowerCase == floatType.toLowerCase) FloatType
    else if (dataType.trim.toLowerCase == doubleType.toLowerCase) DoubleType
    else if (dataType.trim.toLowerCase == byteType.toLowerCase) ByteType
    else if (dataType.trim.toLowerCase.startsWith(decimalType.toLowerCase)) {
      val decimalTypePattern(integerPart, mantissaPart) = dataType
      DecimalType(integerPart.toInt, mantissaPart.toInt)
    } else
      throw TechnicalException(s"Unsupported Data Type : $dataType")
  }

  /**
   * This function will build a Header
   *
   * @param columns Sequence of columns that will be added to a DataFrame and build the header
   * @param df      DataFrame to write
   *
   */
  @tailrec
  def getHeader(columns: Seq[String], df: DataFrame): DataFrame = {
    if (columns.isEmpty) {
      df
    } else {
      getHeader(columns.tail, df.withColumn(columns.head, lit(columns.head)))
    }
  }

  /**
   * This function build a DataFrame using a sequence of columns and a default value
   *
   * @param columns      Sequence of columns that will be used to build a DataFrame
   * @param df           DataFrame to write
   * @param defaultValue Default Value used to build the DataFrame, default is used
   *
   */
  @tailrec
  def buildDF(columns: Seq[String], df: DataFrame, defaultValue: String = null): DataFrame = {
    if (columns.isEmpty) {
      df
    } else {
      buildDF(columns.tail, df.withColumn(s"${columns.head}", lit(defaultValue)))
    }
  }

  /**
   * This functions will lower case all the columns of the given DataFrame
   *
   * @param df DataFrame to write
   */
  def lowerColumns(df: DataFrame): DataFrame = {
    val columns = df.columns
    changeColumns(df = df, columns = columns, toLower = true)
  }

  /**
   * This functions will upper case all the columns of the given DataFrame
   *
   * @param df DataFrame to change
   */
  def upperColumns(df: DataFrame): DataFrame = {
    val columns = df.columns
    changeColumns(df = df, columns = columns)
  }

  /**
   * This functions will apply a sequence of Actions to a DataFrame by using an accumulator
   *
   * @param myDataFrame DataFrame on which the actions will be applied
   * @param actions     Sequence of actions that
   * @return
   */
  def processActions(myDataFrame: DataFrame, actions: Seq[Action]): DataFrame = {
    ProcessColumnActions.runActionsAcc(actions = actions, df = myDataFrame)
  }

  /**
   * This function will lower or upper case in the DataFrame the columns specified in the sequence
   *
   * @param df      DataFrame to change
   * @param columns Sequence of columns that must be lowered or uppered
   * @param toLower If true, the function will lower the columns, else it will upper case them
   */
  @tailrec
  private def changeColumns(df: DataFrame, columns: Seq[String], toLower: Boolean = false): DataFrame = {
    columns.headOption match {
      case Some(head) => if (toLower) changeColumns(df = df.withColumnRenamed(head, head.trim.toLowerCase), columns = columns.tail, toLower = toLower)
      else changeColumns(df = df.withColumnRenamed(head, head.trim.toUpperCase), columns = columns.tail, toLower = toLower)
      case _ => df
    }
  }
}
