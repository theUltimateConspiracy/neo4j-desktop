package com.socgen.bsc.dpc.iohandler.formats

import com.socgen.bsc.dpc.common.exception.TechnicalException
import com.socgen.bsc.dpc.iohandler.common.IoCommon
import com.socgen.bsc.dpc.iohandler.input.InputConfiguration
import com.socgen.bsc.dpc.iohandler.output.OutputConfiguration
import org.apache.spark.sql.{DataFrame, SparkSession}

object ParquetFile {

  //region read

  /**
   * This function will read the DataFrame from a parquet file according to the inputConfiguration
   *
   * @param inputConfiguration InputConfiguration which specify the configuration to read the DataFrame from the defined
   *                           parquet file
   * @param onS3               boolean to specify in the resource is on S3 or not. Only concern files.
   * @param spark              Implicit Spark Session
   */
  def readFromInputConfig(inputConfiguration: InputConfiguration,
                          onS3: Boolean)
                         (implicit spark: SparkSession): DataFrame = {
    read(inputPath = inputConfiguration.source,
      onS3 = onS3,
      options = inputConfiguration.options.getOrElse(Map.empty[String, String]))
  }

  /**
   * This function will read the DataFrame from a parquet file according to the configuration defined in the options
   *
   * @param inputPath Input path where to read the given parquet file
   * @param options   Map of string which must contain the mandatory parquet options and could contains the S3 options
   * @param onS3      Boolean to specify in the resource is on S3 or not. Only concern files.
   * @param spark     Implicit Spark Session
   */
  def read(inputPath: String,
           options: Map[String, String],
           onS3: Boolean)
          (implicit spark: SparkSession): DataFrame = {
    try {
      val (s3Options, _) = IoCommon.splitMapOption(map = options, regex = IoCommon.s3OptionRegex)
      if (onS3) {
        if (IoCommon.hasMandatoryOptions(options = s3Options, mandatoryOptions = IoCommon.s3MandatoryOptions)) {
          s3Options foreach {
            case (key: String, value: String) => spark.sparkContext.hadoopConfiguration.set(key, value)
          }
        } else
          throw TechnicalException(s"Exception raised while Reading Parquet File $inputPath on s3; " +
            s"${IoCommon.displayMapOfStrings(myMap = s3Options)} does not contain the mandatory options : " +
            s"${IoCommon.displayListOfStrings(myList = IoCommon.s3MandatoryOptions)}")
      }
      spark.read.parquet(inputPath)
    } catch {
      case e: Exception =>
        throw TechnicalException(s"An error occurred while reading Parquet File : $inputPath ; ERROR: $e")
    }
  }
  //endregion

  //region write

  /**
   * This function will store the DataFrame to a parquet file according to the configuration defined in the
   * OutputConfiguration object
   *
   * @param df                  DataFrame to write
   * @param outputConfiguration OutputConfiguration which specify the configuration to save the DataFrame in the defined parquet file
   * @param mode                SaveMode - either append or overwrite
   * @param onS3                boolean to specify in the resource is on S3 or not. Only concern files.
   * @param spark               Implicit Spark Session
   */
  def writeToOutputConfig(df: DataFrame,
                          outputConfiguration: OutputConfiguration,
                          mode: Option[String],
                          onS3: Boolean)
                         (implicit spark: SparkSession): Unit = {
    write(df = df,
      outputPath = outputConfiguration.destination,
      partitionFields = outputConfiguration.partitionFields.getOrElse(Seq()),
      mode = mode.getOrElse(outputConfiguration.mode),
      coalesce = outputConfiguration.coalesce,
      options = outputConfiguration.options.getOrElse(Map.empty[String, String]),
      onS3 = onS3)
  }

  /**
   * This function will store the DataFrame to a parquet file according to the configuration defined in the map of strings
   *
   * @param df              DataFrame to write
   * @param outputPath      Output path where to store the parquet file
   * @param partitionFields Set of columns used to partition the DataFrame
   * @param mode            SaveMode - either append or overwrite
   * @param coalesce        Coalesce degree to reduce the number of partitions and reduce the number of output files
   * @param options         Map of string which must contain the mandatory parquet options and could possibly contains
   *                        the S3 options too
   * @param onS3            Boolean to specify in the resource is on S3 or not. Only concern files.
   * @param spark           Implicit Spark Session
   */
  def write(df: DataFrame,
            outputPath: String,
            partitionFields: Seq[String] = Seq(),
            mode: String,
            coalesce: Option[Int] = None,
            options: Map[String, String],
            onS3: Boolean)
           (implicit spark: SparkSession): Unit = {
    try {
      val (s3Options, _) = IoCommon.splitMapOption(map = options, regex = IoCommon.s3OptionRegex)
      if (onS3) {
        if (IoCommon.hasMandatoryOptions(options = s3Options, mandatoryOptions = IoCommon.s3MandatoryOptions))
          s3Options foreach {
            case (key: String, value: String) => spark.sparkContext.hadoopConfiguration.set(key, value)
          }
        else
          throw TechnicalException(s"Exception raised while Writing Parquet File on s3; " +
            s"${IoCommon.displayMapOfStrings(myMap = s3Options)} does not contain the mandatory options : " +
            s"${IoCommon.displayListOfStrings(myList = IoCommon.s3MandatoryOptions)}")
      }
      val saveMode = IoCommon.getSaveMode(mode = mode)
      if (partitionFields.nonEmpty)
        df.coalesce(coalesce.getOrElse(1)).write.mode(saveMode).partitionBy(partitionFields: _*).parquet(outputPath)
      else
        df.coalesce(coalesce.getOrElse(1)).write.mode(saveMode).parquet(outputPath)
    } catch {
      case e: Exception =>
        throw TechnicalException(s"An error occurred while writing Parquet File : $outputPath ; ERROR: $e")
    }
  }
  //endregion
}