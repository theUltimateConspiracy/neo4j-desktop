package com.socgen.bsc.dpc.iohandler.formats

import com.socgen.bsc.dpc.common.exception.TechnicalException
import com.socgen.bsc.dpc.iohandler.common.IoCommon
import com.socgen.bsc.dpc.iohandler.input.InputConfiguration
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * This object is used to read a DataFrame from a Excel Sheet
 */
object ExcelFile {
  /**
   * Excel Driver ClassPath
   */
  private val excelDriverClassPath = "com.crealytics.spark.excel"
  //endregion

  //region read

  /**
   * This function will read a DataFrame from an Excel Sheet according to the configuration defined in the arguments
   *
   * @param inputPath Input path where to read the given file
   * @param options   Map of string which must contain the excel mandatory options
   * @param onS3      Boolean to specify in the resource is on S3 or not. Only concern files.
   * @param spark     Implicit Spark Session
   */
  def read(inputPath: String,
           options: Map[String, String],
           onS3: Boolean)
          (implicit spark: SparkSession): DataFrame = {
    try {
      val (s3Options, configOptions) = IoCommon.splitMapOption(map = options, regex = IoCommon.s3OptionRegex)
      if (onS3) {
        if (IoCommon.hasMandatoryOptions(options = s3Options, mandatoryOptions = IoCommon.s3MandatoryOptions)) {
          s3Options foreach {
            case (key: String, value: String) => spark.sparkContext.hadoopConfiguration.set(key, value)
          }
        } else
          throw TechnicalException(s"Exception raised while Reading Excel File $inputPath on s3; " +
            s"${IoCommon.displayMapOfStrings(myMap = s3Options)} does not contain the mandatory options : " +
            s"${IoCommon.displayListOfStrings(myList = IoCommon.s3MandatoryOptions)}")
      }
      if (IoCommon.hasMandatoryOptions(options = configOptions, mandatoryOptions = IoCommon.excelMandatoryOptions)) {
        spark
          .read
          .format(excelDriverClassPath)
          .options(configOptions)
          .load(inputPath)
      } else {
        throw TechnicalException(s"Exception raised while Reading Excel File $inputPath; " +
          s"${IoCommon.displayMapOfStrings(myMap = configOptions)} does not contain the mandatory options : " +
          s"${IoCommon.displayListOfStrings(myList = IoCommon.excelMandatoryOptions)}")
      }
    } catch {
      case e: Exception =>
        throw TechnicalException(s"An error occurred while reading Excel File : $inputPath ; ERROR: $e")
    }
  }

  /**
   * This function will read a DataFrame from an Excel Sheet according to the configuration defined in the
   * InputConfiguration
   * object
   *
   * @param inputConfiguration InputConfiguration which specify the configuration to read the DataFrame from the defined
   *                           Excel Sheet
   * @param onS3               Boolean to specify in the resource is on S3 or not. Only concern files.
   * @param spark              Implicit Spark Session
   */
  def readFromInputConfig(inputConfiguration: InputConfiguration,
                          onS3: Boolean)
                         (implicit spark: SparkSession): DataFrame = {
    read(inputPath = inputConfiguration.source,
      onS3 = onS3,
      options = inputConfiguration.options.getOrElse(Map.empty[String, String]))
  }
  //endregion

  //region source

  /**
   * This function will return a string that will identify the source as clearly as possible. In this case for Excel,
   * it will return the concatenation of the path and the dataAddress separated by a '|'
   *
   * @param inputPath S3 or HDFS path of the excel file
   * @param options   Map of string which must contain the Excel configuration (dataAddress)
   * @param spark     Implicit Spark Session
   */
  def getSource(inputPath: String, options: Map[String, String])(implicit spark: SparkSession): String = {
    try {
      if (IoCommon.hasMandatoryOptions(options = options, mandatoryOptions = IoCommon.excelMandatoryOptions)) {
        s"$inputPath|${options(IoCommon.dataAddressOption)}"
      } else
        throw TechnicalException(s"A mandatory option is missing among the ${IoCommon.excelMandatoryOptions}. " +
          s"The options are ${IoCommon.displayMapOfStrings(myMap = options)}")
    } catch {
      case e: Exception =>
        throw TechnicalException(s"An error occurred while reading input source with the following configuration " +
          s"${IoCommon.dataAddressOption} : ${options(IoCommon.dataAddressOption)}; ERROR $e")
    }
  }
  //endregion
}