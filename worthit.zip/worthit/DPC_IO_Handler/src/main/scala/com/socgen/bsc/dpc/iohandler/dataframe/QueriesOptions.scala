package com.socgen.bsc.dpc.iohandler.dataframe

import com.socgen.bsc.dpc.iohandler.common.TypeHandler
import com.socgen.bsc.dpc.iohandler.formats.{HqlFile, HqlQuery}
import org.apache.hadoop.fs.FileSystem
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * This case class define the attributes of the registered queries
 *
 * @param query   String that will either be a String, a hdfs path, a S3 path
 * @param options Map of Strings that will contain the options for the S3 connection when needed
 */
case class QueriesOptions(
                           query: String,
                           options: Option[Map[String, String]]
                         )


object QueriesHandler {
  /**
   * This function will read a query either from a file on S3 or HDFS, or directly from a String
   *
   * @param queriesOptions Object of type QueriesOptions which contain the information needed to get the query
   * @param hdfs           HDFS FileSystem connection
   * @param spark          Implicit Spark Session
   * @return
   */
  def readQuery(queriesOptions: QueriesOptions,
                hdfs: FileSystem)
               (implicit spark: SparkSession): DataFrame = {
    val (inputType, onS3) = TypeHandler.getType(queriesOptions.query)
    if (inputType == TypeHandler.HQL_FILE) {
      HqlFile.read(inputPath = queriesOptions.query,
        onS3 = onS3,
        options = queriesOptions.options.getOrElse(Map.empty[String, String]),
        hdfs = hdfs)
    } else if (inputType == TypeHandler.HQL_QUERY) {
      HqlQuery.read(query = queriesOptions.query)
    } else
      throw new IllegalArgumentException(s"Illegal Query Option, query is of type $inputType. " +
        s"Valid type are ['${TypeHandler.HQL_QUERY}','${TypeHandler.HQL_FILE}]")
  }
}
