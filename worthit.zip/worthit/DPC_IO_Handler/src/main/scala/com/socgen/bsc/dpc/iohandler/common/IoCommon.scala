package com.socgen.bsc.dpc.iohandler.common

import com.socgen.bsc.dpc.common.exception.TechnicalException
import com.socgen.bsc.dpc.iohandler.input.InputConfiguration
import com.socgen.bsc.dpc.iohandler.output.OutputConfiguration
import org.apache.spark.sql.SaveMode

object IoCommon {
  /**
   * Save Modes
   */
  final val appendMode = "append"
  final val ignoreMode = "ignore"
  final val overwriteMode = "overwrite"
  final val defaultMode = "overwrite"

  //region attributes
  final val fileNamePathRegex = "[a-zA-Z0-9_-]+.json"

  /**
   * JDBC Mandatory Options
   */
  final val sslOption = "SSL"
  final val urlOption = "url"
  final val dbTableOption = "dbtable"
  final val userOption = "user"
  final val passwordOption = "password"
  final val driverOption = "driver"

  /**
   * CSV Mandatory Options
   */
  final val headerOption = "header"
  final val delimiterOption = "delimiter"

  /**
   * Excel Mandatory Options
   */
  final val dataAddressOption = "dataAddress"

  /**
   * Hive Mandatory Options
   */
  final val pathOption = "path"

  /**
   * S3 Mandatory Options
   */
  final val accessKeyOption = "fs.s3a.access.key"
  final val secretKeyOption = "fs.s3a.secret.key"
  final val endpointOption = "fs.s3a.endpoint"
  final val s3OptionRegex = "fs.s3a.*"

  /** *
   * Elastic Search Mandatory Options
   */
  final val es_resource = "es.resource"
  final val es_nodes = "es.nodes"
  final val es_port = "es.port"
  final val es_net_http_auth_user = "es.net.http.auth.user"
  final val es_net_http_auth_pass = "es.net.http.auth.pass"


  val availableModes = Seq(appendMode, ignoreMode, defaultMode)

  /**
   * Mandatory Options
   */
  val jdbcMandatoryOptions = Seq(urlOption, dbTableOption, userOption, passwordOption)
  val csvMandatoryOptions = Seq(delimiterOption)
  val hiveMandatoryOptions = Seq(pathOption)
  val s3MandatoryOptions = Seq(accessKeyOption, secretKeyOption, endpointOption)
  val eSMandatoryOptions = Seq(es_resource, es_nodes, es_port, es_net_http_auth_user, es_net_http_auth_pass)
  val excelMandatoryOptions = Seq(headerOption, dataAddressOption)
  //endregion

  /**
   * Return a SaveMode object fro
   *
   * @param mode SaveMode - either append or overwrite
   */
  def getSaveMode(mode: String): SaveMode = {
    if (IoCommon.hasValidMode(mode)) {
      if (mode.toLowerCase == IoCommon.appendMode) {
        SaveMode.Append
      } else if (mode.toLowerCase == IoCommon.ignoreMode) {
        SaveMode.Ignore
      } else {
        SaveMode.Overwrite
      }
    } else {
      throw TechnicalException(s"Invalid Mode $mode, mode must be one of the following ${IoCommon.displayListOfStrings(IoCommon.availableModes)}")
    }
  }

  /**
   * This function will check if the given mode belongs to the list of the available SaveModes
   *
   * @param mode SaveMode - either append or overwrite
   */
  def hasValidMode(mode: String): Boolean = {
    availableModes.map(_.toLowerCase).contains(mode.toLowerCase)
  }

  /**
   * This function return true if the sources are equal , it also detect when an external table is given as a parquet
   *
   * @param inputConfiguration  InputConfiguration which specify the configuration to read the DataFrame from the defined
   * @param outputConfiguration OutputConfiguration which specify the configuration to save the DataFrame in the defined 
   */
  def areSourcesEqual(inputConfiguration: InputConfiguration, outputConfiguration: OutputConfiguration): Boolean = {
    val (inputType, inputOnS3) = TypeHandler.getType(source = inputConfiguration.source)
    val (inputS3Options, inputConfigOptions) = splitMapOption(map = inputConfiguration.options.getOrElse(Map.empty[String, String]), regex = s3OptionRegex)

    val (outputType, outputOnS3) = TypeHandler.getType(source = outputConfiguration.destination)
    val (outputS3Options, outputConfigOptions) = splitMapOption(map = outputConfiguration.options.getOrElse(Map.empty[String, String]), regex = s3OptionRegex)

    val isSameSource = inputConfiguration.source == outputConfiguration.destination

    val isSameS3Bucket = if (inputOnS3 && outputOnS3) {
      if (hasMandatoryOptions(options = inputS3Options, mandatoryOptions = s3MandatoryOptions)) {
        if (hasMandatoryOptions(options = outputS3Options, mandatoryOptions = s3MandatoryOptions)) {
          inputS3Options == outputS3Options
        } else {
          throw TechnicalException(s"Output error ${outputConfiguration.destination} on s3; ${IoCommon.displayMapOfStrings(myMap = outputS3Options)} does not contain the mandatory options : ${IoCommon.displayListOfStrings(IoCommon.availableModes)}")
        }
      } else {
        throw TechnicalException(s"Intput error ${inputConfiguration.source} on s3; ${IoCommon.displayMapOfStrings(myMap = inputS3Options)} does not contain the mandatory options : ${IoCommon.displayListOfStrings(IoCommon.availableModes)}")
      }
    } else if (!inputOnS3 && !outputOnS3) true
    else false
    if (isSameSource && inputType == outputType) {
      if (inputType == TypeHandler.HIVE_TABLE) true
      else isSameSource && (inputConfigOptions == outputConfigOptions) && isSameS3Bucket
    } else if (inputType == TypeHandler.PARQUET_FILE && outputType == TypeHandler.HIVE_TABLE) {
      if (hasMandatoryOptions(options = outputConfigOptions, mandatoryOptions = hiveMandatoryOptions)) {
        val pathDatabase = outputConfigOptions(IoCommon.pathOption)
        val outputTablePath = getTablePath(databasePath = pathDatabase, table = outputConfiguration.destination)
        inputConfiguration.source == outputTablePath
      } else {
        throw TechnicalException(s"Output Error ${outputConfiguration.destination}; ${IoCommon.displayMapOfStrings(myMap = outputConfigOptions)} does not contain the mandatory options : ${IoCommon.displayListOfStrings(IoCommon.availableModes)}")
      }
    } else {
      false
    }

  }

  /**
   * This function converted a map of Strings to a String where each pair are separated by a comma.
   * Return an empty String if the map is empty
   *
   * @param myMap     Map of Strings
   * @param separator Default value is ';'
   * @example Given the following map [bob -> 20, ben -> 25] and the serpator ';' , the result will be 'bob -> 20; ben -> 25'
   */
  def displayMapOfStrings(myMap: Map[String, String], separator: String = ";"): String = {
    if (myMap.keys.toSeq.contains(userOption) && myMap.keys.toSeq.contains(passwordOption))
      s"[${
        (myMap + (userOption -> "********", passwordOption -> "************")).map {
          case (key, value) => s" $key -> $value "
        }.mkString(separator)
      }]"
    else if (myMap.keys.toSeq.contains(userOption))
      s"[${
        (myMap + (userOption -> "********")).map {
          case (key, value) => s" $key -> $value "
        }.mkString(separator)
      }]"
    else if (myMap.keys.toSeq.contains(passwordOption))
      s"[${
        (myMap + (passwordOption -> "********")).map {
          case (key, value) => s" $key -> $value "
        }.mkString(separator)
      }]"
    else
      s"[${
        myMap.map {
          case (key, value) => s" $key -> $value "
        }.mkString(separator)
      }]"
  }

  /**
   * This function converted a sequence of String to a String where each element are separated by a comma.
   * Return an empty String if the sequence is empty
   *
   * @param myList    Seq[String]
   * @param separator Default value is ';'
   * @example Given the following sequence [bob,ben] and the serpator ';' , the result will be 'bob;ben'
   */
  def displayListOfStrings(myList: Seq[String], separator: String = ";"): String = {
    s"[${myList.mkString(separator)}]"
  }

  /**
   * Check if the map has the given mandatory keys
   *
   * @param options          Map of strings
   * @param mandatoryOptions List of keys to filter in the map
   */
  def hasMandatoryOptions(options: Map[String, String], mandatoryOptions: Seq[String]): Boolean = {
    options.filterKeys(mandatoryOptions.contains).size == mandatoryOptions.size
  }

  /**
   * This function use a regex to divide a map in two part depending to if the key match the regex or not
   *
   * @param map   Map of Strings
   * @param regex regex applied on the keys
   */
  def splitMapOption(map: Map[String, String], regex: String): (Map[String, String], Map[String, String]) = {
    if (regex == s3OptionRegex)
      (map.filterKeys(_ matches regex) ++ Map("fs.s3a.impl" -> "org.apache.hadoop.fs.s3a.S3AFileSystem"), map.filterKeys { elt => !(elt matches regex) })
    else
      (map.filterKeys(_ matches regex), map.filterKeys { elt => !(elt matches regex) })
  }

  /**
   * This function build the table path where the external hive table will be stored
   *
   * @param databasePath hdfs path of the database
   * @param table        name of the table
   */
  def getTablePath(databasePath: String, table: String): String = s"$databasePath${table.split('.')(1)}"
}