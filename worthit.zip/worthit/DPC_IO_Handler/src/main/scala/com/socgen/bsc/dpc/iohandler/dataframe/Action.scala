package com.socgen.bsc.dpc.iohandler.dataframe

/**
 * This case class will define the attributes of Action that will be applied to a DataFrame
 * @param actionType       String that define the action to execute, availabe values : 'ADD', 'DELETE', 'RENAME', 'CAST',
 *                         'FILTER', 'FILTER_EXPR', 'TRIM', 'UPPER', 'LOWER'
 * @param column           Column on which the action will be applied
 * @param newColumn        New name of the column in case of rename, or name of the new added column
 * @param newColumnType    Type of the new column or new type of an existing column
 * @param value            Value that will either be the default value for a column to add , or the value used to filter
 * @param comparison       Comparison that will be used for filtering, available values : '==', 'equal', '>', 'gt', '>=',
 *                         'gte', '<', 'lt', '< =', 'lte', '!=', 'different', 'mandatory'
 * @param filterExpression Filter expression that will be applied on the DataFrame
 */
case class Action(
                   actionType: String,
                   column: Option[String],
                   newColumn: Option[String],
                   newColumnType: Option[String],
                   value: Option[String],
                   comparison: Option[String],
                   filterExpression: Option[String]
                 )


