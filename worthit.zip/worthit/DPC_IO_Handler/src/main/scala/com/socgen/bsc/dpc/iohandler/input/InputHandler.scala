package com.socgen.bsc.dpc.iohandler.input

import com.socgen.bsc.dpc.common.exception.TechnicalException
import com.socgen.bsc.dpc.iohandler.common.{IoCommon, TypeHandler}
import com.socgen.bsc.dpc.iohandler.dataframe.{Action, DFHandler, QueriesHandler, QueriesOptions}
import com.socgen.bsc.dpc.iohandler.formats._
import org.apache.hadoop.fs.FileSystem
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * Object which will read a DataFrame from different sources
 */
object InputHandler {

  /**
   * This function will return the content of a standard file in HDFS or S3
   *
   * @param basePath HDFS or S3 folder where the file is stored
   * @param fileName Name of the file to read
   * @param options  Map of string which must contain the
   * @param hdfs     Hdfs Configuration to read and write on hdfs
   * @param spark    Implicit Spark Session
   */
  def getStringFromFile(basePath: String,
                        fileName: String,
                        options: Option[Map[String, String]] = None,
                        hdfs: FileSystem)
                       (implicit spark: SparkSession): String = {
    val inputPath = if (fileName.matches(IoCommon.fileNamePathRegex)) {
      s"$basePath/$fileName"
    } else {
      throw new IllegalArgumentException(s"Illegal Argument Exception : " +
        s"fileName $fileName doesn't match the regex ${IoCommon.fileNamePathRegex}")
    }
    val (inputType, onS3) = TypeHandler.getType(inputPath)
    if (inputType == TypeHandler.JSON_FILE) {
      JsonFile.readConfiguration(inputPath = inputPath,
        onS3 = onS3,
        options = options.getOrElse(Map.empty[String, String]),
        hdfs = hdfs)
    } else {
      throw TechnicalException(s"Unsupported Type arguments for $inputPath. Impossible to read the configuration")
    }

  }

  /**
   * This function  will return a DataFrame read according the specified configuration
   *
   * @param input           Input which will be used to determine the type of the source
   * @param options         Map of string which must contain the mandatory option of the source according to its type
   * @param columnActions   Sequence of Action that will be used to transform the DataFrame
   * @param registerDF      Name of the registered table where the DataFrame (source + columnActions) will be saved
   * @param registerQueries Map of registered queries used to define intermediary DataFrame to get the final one
   * @param hdfs            Hdfs Configuration to read and write on hdfs
   * @param spark           Implicit Spark Session
   */
  def getDF(input: String,
            options: Map[String, String] = Map.empty[String, String],
            columnActions: Option[Seq[Action]],
            registerDF: Option[String],
            registerQueries: Option[Map[String, QueriesOptions]] = None,
            hdfs: FileSystem)
           (implicit spark: SparkSession): DataFrame = {
    val (inputType, onS3) = TypeHandler.getType(input)
    val df = if (inputType == TypeHandler.CSV_FILE) {
      CsvFile.read(inputPath = input,
        onS3 = onS3,
        options = options,
        hdfs = hdfs)
    } else if (inputType == TypeHandler.JSON_FILE) {
      JsonFile.read(inputPath = input,
        onS3 = onS3,
        options = options)
    } else if (inputType == TypeHandler.PARQUET_FILE) {
      ParquetFile.read(inputPath = input,
        onS3 = onS3,
        options = options)
    } else if (inputType == TypeHandler.HIVE_TABLE) {
      HiveTable.read(completeTableName = input)
    } else if (inputType == TypeHandler.HQL_FILE) {
      HqlFile.read(inputPath = input,
        onS3 = onS3,
        options = options,
        hdfs = hdfs)
    } else if (inputType == TypeHandler.HQL_QUERY) {
      HqlQuery.read(query = input)
    } else if (inputType == TypeHandler.JDBC_CONF) {
      JdbcConnection.read(options = options)
    } else if (inputType == TypeHandler.EXCEL_FILE) {
      ExcelFile.read(inputPath = input,
        onS3 = onS3,
        options = options)
    } else if (inputType == TypeHandler.ES_CONF) {
      ElasticSearch.read(options = options)
    } else {
      throw TechnicalException(s"Unrecognized input type argument : $input. " +
        s"Impossible to get the DataFrame. Input must be of type : " +
        s"${IoCommon.displayListOfStrings(myList = TypeHandler.availableInput)}")
    }
    val processedDF = columnActions match {
      case Some(actions) => DFHandler.processActions(actions = actions, myDataFrame = df)
      case _ => df
    }
    registerDF match {
      case Some(registerDFName) => processedDF.registerTempTable(registerDFName)
      case _ =>
    }
    registerQueries match {
      case Some(registerQueries) => registerQueries foreach {
        registerQuery =>
          QueriesHandler.readQuery(queriesOptions = registerQuery._2, hdfs = hdfs)
            .registerTempTable(registerQuery._1)
      }
        registerQueries.lastOption match {
          case Some(lastRegisteredQuery) => spark.table(lastRegisteredQuery._1)
          case _ => processedDF
        }
      case _ => processedDF
    }
  }

  /**
   * This function will return a DataFrame read according the object InputConfiguration
   *
   * @param inputConfiguration InputConfiguration which specify the configuration to read the DataFrame from
   * @param hdfs               Hdfs Configuration to read and write on hdfs
   * @param spark              Implicit Spark Session
   */
  def getDFFromInputConfig(inputConfiguration: InputConfiguration,
                           hdfs: FileSystem)
                          (implicit spark: SparkSession): DataFrame = {
    val (inputType, onS3) = TypeHandler.getType(inputConfiguration.source)
    val df = if (inputType == TypeHandler.CSV_FILE) {
      CsvFile.readFromInputConfig(inputConfiguration = inputConfiguration,
        onS3 = onS3, hdfs = hdfs)
    } else if (inputType == TypeHandler.JSON_FILE) {
      JsonFile.readFromInputConfig(inputConfiguration = inputConfiguration,
        onS3 = onS3)
    } else if (inputType == TypeHandler.PARQUET_FILE) {
      ParquetFile.readFromInputConfig(inputConfiguration = inputConfiguration,
        onS3 = onS3)
    } else if (inputType == TypeHandler.HIVE_TABLE) {
      HiveTable.read(completeTableName = inputConfiguration.source)
    } else if (inputType == TypeHandler.HQL_FILE) {
      HqlFile.readFromInputConfig(inputConfiguration = inputConfiguration,
        onS3 = onS3,
        hdfs = hdfs)
    } else if (inputType == TypeHandler.HQL_QUERY) {
      HqlQuery.readFromInputConfig(inputConfiguration = inputConfiguration)
    } else if (inputType == TypeHandler.JDBC_CONF) {
      JdbcConnection.readFromInputConfig(inputConfiguration = inputConfiguration)
    } else if (inputType == TypeHandler.EXCEL_FILE) {
      ExcelFile.readFromInputConfig(inputConfiguration = inputConfiguration,
        onS3 = onS3)
    } else if (inputType == TypeHandler.ES_CONF) {
      ElasticSearch.readFromInputConfig(inputConfiguration = inputConfiguration)
    } else {
      throw TechnicalException(s"Unrecognized input type argument : ${inputConfiguration.source}}. " +
        s"Impossible to get the DataFrame. Input must be of type : " +
        s"${IoCommon.displayListOfStrings(myList = TypeHandler.availableInput)}")
    }
    val processedDF = inputConfiguration.columnActions match {
      case Some(actions) => DFHandler.processActions(actions = actions, myDataFrame = df)
      case _ => df
    }
    inputConfiguration.registerDF match {
      case Some(registerDFName) => processedDF.registerTempTable(registerDFName)
      case _ =>
    }
    inputConfiguration.registerQueries match {
      case Some(registerQueries) => registerQueries foreach {
        registerQuery => QueriesHandler.readQuery(queriesOptions = registerQuery._2, hdfs = hdfs).registerTempTable(registerQuery._1)
      }
        registerQueries.lastOption match {
          case Some(lastRegisteredQuery) => spark.table(lastRegisteredQuery._1)
          case _ => processedDF
        }
      case _ => processedDF
    }
  }

  /**
   * Thi function will return the source description according to it's type
   *
   * @param inputConfiguration InputConfiguration which specify the configuration to read the DataFrame from
   * @param spark              Implicit Spark Session
   */
  def getSource(inputConfiguration: InputConfiguration)(implicit spark: SparkSession): String = {
    val (inputType, _) = TypeHandler.getType(inputConfiguration.source)
    if (inputType == TypeHandler.CSV_FILE) {
      inputConfiguration.source
    } else if (inputType == TypeHandler.JSON_FILE) {
      inputConfiguration.source
    } else if (inputType == TypeHandler.PARQUET_FILE) {
      inputConfiguration.source
    } else if (inputType == TypeHandler.HIVE_TABLE) {
      inputConfiguration.source
    } else if (inputType == TypeHandler.HQL_FILE) {
      inputConfiguration.source
    } else if (inputType == TypeHandler.HQL_QUERY) {
      inputConfiguration.source
    } else if (inputType == TypeHandler.EXCEL_FILE) {
      ExcelFile.getSource(inputPath = inputConfiguration.source,
        options = inputConfiguration.options.getOrElse(Map.empty[String, String]))
    } else if (inputType == TypeHandler.JDBC_CONF) {
      JdbcConnection.getSource(options = inputConfiguration.options.getOrElse(Map.empty[String, String]))
    } else if (inputType == TypeHandler.ES_CONF) {
      ElasticSearch.getSource(options = inputConfiguration.options.getOrElse(Map.empty[String, String]))
    } else {
      throw TechnicalException(s"Unrecognized input type argument : ${inputConfiguration.source}}. " +
        s"Impossible to get the DataFrame. Input must be of type : " +
        s"${IoCommon.displayListOfStrings(myList = TypeHandler.availableInput)}")
    }
  }
}