package com.socgen.bsc.dpc.iohandler.common

import com.socgen.bsc.dpc.common.exception.TechnicalException

/**
 * This object define the methods that allows you to identify the format
 */
object TypeHandler {

  /**
   * Source Types
   */
  final val HIVE_TABLE = "HIVE"
  final val CSV_FILE = "CSV"
  final val JSON_FILE = "JSON"
  final val PARQUET_FILE = "PARQUET"
  final val HQL_FILE = "SqlFile"
  final val HQL_QUERY = "SqlQuery"
  final val JDBC_CONF = "JdbcConf"
  final val EXCEL_FILE = "EXCEL"
  final val ES_CONF = "ElasticSearch"

  /**
   * Available types
   */
  val availableInput = Seq(HIVE_TABLE, CSV_FILE, PARQUET_FILE, HQL_FILE, HQL_QUERY, JDBC_CONF, EXCEL_FILE, ES_CONF)
  val availableOutput = Seq(HIVE_TABLE, CSV_FILE, PARQUET_FILE, JDBC_CONF, ES_CONF)
  private val availableType = (availableInput ++ availableOutput).distinct

  /**
   * Regex sources
   */
  private val parquetPathRegex = "^((s3a|hdfs)://|/){1}(.*/[a-zA-Z0-9-_]*)$"
  private val jsonPathRegex = "^((s3a|hdfs)://|/){1}.*.json$"
  private val csvPathRegex = "^((s3a|hdfs)://|/){1}.*.csv$"
  private val sqlPathRegex = "^((s3a|hdfs)://|/){1}.*.sql$"
  private val hiveTableRegex = "^[a-zA-Z0-9-_]+.[a-zA-Z0-9-_]+$"
  private val sqlQueryRegex = "^[select|SELECT].*$"
  private val jdbcConfRegex = "^jdbc.*$"
  private val xlsxPathRegex = "^((s3a|hdfs)://|/){1}.*.xlsx$"
  private val eSConfRegex = "^es$"

  /**
   * This function return true if the source start with s3a
   *
   * @param source String which will be used to determine the type of the source
   */
  def isOnS3(source: String): Boolean = source.startsWith("s3a")

  /**
   * This function return the type of the given source and says if it is on S3 or not
   *
   * @param source String which will be used to determine the type of the source
   */
  def getType(source: String): (String, Boolean) = {
    val onS3 = isOnS3(source = source)
    if (source.matches(csvPathRegex)) {
      (CSV_FILE, onS3)
    } else if (source.matches(parquetPathRegex)) {
      (PARQUET_FILE, onS3)
    } else if (source.matches(jsonPathRegex)) {
      (JSON_FILE, onS3)
    } else if (source.matches(jdbcConfRegex)) {
      (JDBC_CONF, onS3)
    } else if (source.matches(sqlPathRegex)) {
      (HQL_FILE, onS3)
    } else if (source.matches(xlsxPathRegex)) {
      (EXCEL_FILE, onS3)
    } else if (source.matches(hiveTableRegex)) {
      (HIVE_TABLE, onS3)
    } else if (source.matches(sqlQueryRegex)) {
      (HQL_QUERY, onS3)
    } else if (source.matches(eSConfRegex)) {
      (ES_CONF, onS3)
    } else {
      throw TechnicalException(s"Unrecognized source type argument : $source. source must be of type : " +
        s"[${IoCommon.displayListOfStrings(myList = availableType)}]")
    }
  }
}