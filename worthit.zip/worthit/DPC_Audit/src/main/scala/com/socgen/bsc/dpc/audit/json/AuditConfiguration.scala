package com.socgen.bsc.dpc.audit.json

import com.socgen.bsc.dpc.iohandler.input.InputConfiguration
import com.socgen.bsc.dpc.iohandler.output.OutputConfiguration

/**
 * This case class is the configuration to realize an audit between two sources
 *
 * @param leftInput    Left source of type com.socgen.bsc.dpc.iohandler.input.InputConfiguration
 * @param rightInput   Right source of type com.socgen.bsc.dpc.iohandler.input.InputConfiguration
 * @param diffOutput   Optional - Difference output of type com.socgen.bsc.dpc.iohandler.output.OutputConfiguration
 *                     It will contain the differences between the two DataFrames at row level.
 * @param reportOutput Report output of type com.socgen.bsc.dpc.iohandler.output.OutputConfiguration
 *                     It will contain the information like the schema differences and the number of rows in each DF
 * @param idList       Optional - Sequence of String where we specifiy the set of columns to identify a unique row
 * @param ignoreList   Optional - Sequence of String where we specifiy the set of columns to ignore during the comparison
 * @note Please check IoHandler documentation for more information about Object from package com.socgen.bsc.dpc.iohandler
 */
case class AuditConfiguration(
                               leftInput: InputConfiguration,
                               rightInput: InputConfiguration,
                               diffOutput: Option[OutputConfiguration],
                               reportOutput: OutputConfiguration,
                               idList: Option[Seq[String]],
                               ignoreList: Option[Seq[String]]
                             )