package com.socgen.bsc.dpc.audit.common

import com.socgen.bsc.dpc.audit.common.Common._
import com.socgen.bsc.dpc.audit.diff._
import com.socgen.bsc.dpc.common.Reporting
import com.socgen.bsc.dpc.iohandler.dataframe.DFHandler
import com.socgen.bsc.dpc.iohandler.output.{OutputConfiguration, OutputHandler}
import org.apache.hadoop.fs.FileSystem
import org.apache.spark.sql.functions.{col, concat_ws, lit}
import org.apache.spark.sql.types.{DataType, StringType}
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 *
 */
object AuditConfigurationProcess {
  /**
   * This function converted a sequence of String to a String where each element are separated by a comma.
   * Return 'NA' if the sequence is empty.
   *
   * @param mySeq Seq[String]
   * @example Given the following sequence [bob,ben] ; the result will be 'bob,ben'
   */
  private def flatSequence(mySeq: Seq[String]): String = if (mySeq.nonEmpty) {
    mySeq.mkString("|~|")
  } else {
    "NA"
  }

  def generateJoinFilter(df1Name: String, df2Name: String, cols: Seq[String], counter: Int = 0): String = cols.headOption match {
    case Some(head) => if (counter == 0) 
        s"$df1Name.$head == $df2Name.$head" + generateJoinFilter(df1Name = df1Name, df2Name = df2Name, cols = cols.tail, counter = counter + 1)
      else 
        s" AND $df1Name.$head == $df2Name.$head" + generateJoinFilter(df1Name = df1Name, df2Name = df2Name, cols = cols.tail, counter = counter + 1)
    case _ => ""
  }


  /**
   * This function return the differences between the schema of two DataFrame leftDF and rightDF and will save the report
   * if differences are found to the reporting output
   *
   * @param leftDF                    DataFrame read from leftInput source
   * @param rightDF                   DataFrame read from rightInput source
   * @param leftInput                 Left source of type com.socgen.bsc.dpc.iohandler.input.InputConfiguration
   * @param rightInput                Right source of type com.socgen.bsc.dpc.iohandler.input.InputConfiguration
   * @param idList                    List of columns used to identify a unique row , they must be present in both
   *                                  dataframes (Specified in the json configuration)
   * @param ignoreList                List of columns to withdraw from the comparison
   * @param reportOutputConfiguration Report output of type com.socgen.bsc.dpc.iohandler.output.OutputConfiguration
   *                                  It will contain the information like the schema differences and the number of rows
   *                                  in each DF
   * @param auditDate                 Date specified in the properties to historize the comparison
   * @param hdfs                      Hdfs configuration created in the Main.scala object
   * @param reporting                 Reporting configuration to log the information
   * @param spark                     Implicit Spark Session
   * @return object of type (Option[String], DataFrame, DataFrame)
   *         The first value correspond to the mode append if there are differences between the schema because
   *         the application has starter to write in the reportConfigurationOuput else it will be the mode defined in
   *         the reportOuputConfigurationObject
   *         The second value is the leftDF minus the ignored columns and the columns which are not in the right DF
   *         The third value is the leftDF minus the ignored columns and the columns which are not in the right DF
   *         This way, the two DataFrames have the same schema
   * @example Given the following DataFrames as input:
   *          ignoreList: [ingestion_date]
   *          leftDF:   |   name   | species | age | owner | ingestion_date |
   *          |  Sparky  |   dog   | 10  |  Ben  | 20220426_11:43 |
   *          rightDF:  |   name   | species | age | ingestion_date |
   *          |  Sparky  |   dog   | 11  | 20220427_11:43 |
   *          The resulted DataFrames will be as following :
   *          reportOutput: |      diff_type      |    column   |      left_value     |      right_value       |
   *          | RIGHT_ADDED_COLUMN  |    owner    |    Type String    |          NULL          |
   *          mode: append (mode will be changed to append as we started writing on the reportOutput table
   *          The column ingestion_date will be ignored on both DataFrames
   *          leftDF:   |   name   | species | age | The column owner will be ignored as well as it is not in the rightDF
   *          |  Sparky  |   dog   | 10  |
   *          rightDF:  |   name   | species | age |
   *          |  Sparky  |   dog   | 11  |
   * @note Please check IoHandler documentation for more information about Object from package com.socgen.bsc.dpc.iohandler
   */
  private def compareSchemaAndGetDFs(leftDF: DataFrame,
                                     rightDF: DataFrame,
                                     leftInput: String,
                                     rightInput: String,
                                     idList: Seq[String],
                                     ignoreList: Seq[String],
                                     reportOutputConfiguration: OutputConfiguration,
                                     auditDate: String,
                                     hdfs: FileSystem,
                                     reporting: Reporting)
                                    (implicit spark: SparkSession): (Option[String], DataFrame, DataFrame) = {

    val loweredLeftDF = DFHandler.lowerColumns(leftDF)
    val loweredRightDF = DFHandler.lowerColumns(rightDF)

    val (leftDFTemp, rightDFTemp) = if (ignoreList.nonEmpty)
      (loweredLeftDF.drop(ignoreList.map(_.toLowerCase): _*), loweredRightDF.drop(ignoreList.map(_.toLowerCase): _*))
    else (loweredLeftDF, loweredRightDF)

    val leftDFFilled = leftDFTemp.na.fill("", leftDFTemp.columns)
    val rightDFFilled = rightDFTemp.na.fill("", rightDFTemp.columns)

    val leftDfFields: Map[String, DataType] = leftDFFilled.schema.map(f => f.name.toLowerCase -> f.dataType).toMap
    val rightDfFields: Map[String, DataType] = rightDFFilled.schema.map(f => f.name.toLowerCase -> f.dataType).toMap

    if (!leftDfFields.equals(rightDfFields)) {
      val leftColumns = leftDfFields.keys.toSeq
      val rightColumns = rightDfFields.keys.toSeq
      val (schemaComparisonDF, columnsToDrop) = getTypeOfDistinctColumn((leftColumns ++ rightColumns).distinct,
        leftDfFields,
        rightDfFields)

      saveOutput(df = schemaComparisonDF,
        leftInput = leftInput,
        rightInput = rightInput,
        idList = idList,
        ignoreList = ignoreList,
        outputConfiguration = reportOutputConfiguration,
        auditDate = auditDate,
        hdfs = hdfs,
        reporting = reporting)

      (Some("Append"), leftDFFilled.drop(columnsToDrop: _*), rightDFFilled.drop(columnsToDrop: _*))
    } else {
      (Some(reportOutputConfiguration.mode), leftDFFilled, rightDFFilled)
    }
  }

  /**
   * This function will realize the comparison row by row between the two DataFrames leftDF and right DF.
   * As Id are not specified, the whole row will be considered as an id. Any changes on the row will be considered as
   * a deletion from one side and insertion from the other one.
   *
   * @param leftDF                    DataFrame read from leftInput source
   * @param rightDF                   DataFrame read from rightInput source
   * @param leftInput                 Left source of type com.socgen.bsc.dpc.iohandler.input.InputConfiguration
   * @param rightInput                Right source of type com.socgen.bsc.dpc.iohandler.input.InputConfiguration
   * @param idList                    List of columns used to identify a unique row , they must be present in both
   *                                  dataframes (Specified in the json configuration)
   * @param ignoreList                List of columns to withdraw from the comparison
   * @param reportOutputConfiguration Report output of type com.socgen.bsc.dpc.iohandler.output.OutputConfiguration
   *                                  It will contain the information like the schema differences and the number of rows
   *                                  in each DF
   * @param diffOutput                Difference output of type com.socgen.bsc.dpc.iohandler.output.OutputConfiguration
   *                                  It will contain the differences between the two DataFrames at row level.
   *                                  The output is completely different when idList is specified or not.
   *                                  Here the Id List is not specified so the diffOuput DataFrame will be like :
   * @param auditDate                 Date specified in the properties to historize the comparison
   * @param hdfs                      Hdfs configuration created in the Main.scala object
   * @param reporting                 Reporting configuration to log the information
   * @param spark                     Implicit Spark Session
   * @example Given the following DataFrames as input:
   *          leftDF:   |   name   | species | age |
   *          |  Sparky  |   dog   | 10  |
   *          rightDF:  |   name   | species | age |
   *          |  Sparky  |   dog   | 11  |
   *          The resulted DataFrames will be as following :
   *          reportOutput: | diff_type |    column   |      left_value     |      right_value       |
   *          | DR == IR  | REPORT_DIFF | LEFT_DELETED_ROW: 1 | RIGHT_INSERTED_ROW 1 |
   *          and
   *          diffOutput: | diff_type |   name   | species | age |
   *          |     D     |  Sparky  |   dog   | 10  |
   *          |     I     |  Sparky  |   dog   | 11  |
   *          First Row: This line is present in the left DataFrame but not in the right DataFrame.
   *          The program compare the whole row even if only age has changed.
   *          But name,dog are not specified as an idList
   *          It's why it is considered as removed by the program.
   *          Second Row: This line is present in the right DataFrame but not in the left DataFrame.
   *          The line is seen as added to right DataFrame
   * @note Please check IoHandler documentation for more information about Object from package com.socgen.bsc.dpc.iohandler
   */
  private def compareDFs(leftDF: DataFrame,
                         rightDF: DataFrame,
                         leftInput: String,
                         rightInput: String,
                         idList: Seq[String],
                         ignoreList: Seq[String],
                         reportOutputConfiguration: OutputConfiguration,
                         diffOutput: Option[OutputConfiguration],
                         auditDate: String,
                         hdfs: FileSystem,
                         reporting: Reporting)(implicit spark: SparkSession): Unit = {

    import spark.implicits._

    val diff = leftDF.diff(rightDF).filter(col("diff") =!= "N").cache

    val numberOfRowDeleted = diff.filter(col("diff") === "D").count
    val numberOfRowInserted = diff.filter(col("diff") === "I").count

    val typeDifference = if (numberOfRowDeleted == 0 && numberOfRowInserted == 0) NA
    else if (numberOfRowDeleted != 0 && numberOfRowInserted == 0) DR
    else if (numberOfRowDeleted == 0 && numberOfRowInserted != 0) IR
    else if (numberOfRowDeleted == numberOfRowInserted) s"$DR == $IR"
    else if (numberOfRowDeleted < numberOfRowInserted) s"$DR < $IR"
    else s"$DR > $IR"

    val finalDF = Seq((s"$typeDifference", "REPORT_DIFF", s"$DR: $numberOfRowDeleted", s"$IR: $numberOfRowInserted"))
      .toDF(diffTypeColumn, columnName, leftValueColumn, rightValueColumn)

    diff.unpersist
    saveOutput(df = finalDF,
      leftInput = leftInput,
      rightInput = rightInput,
      idList = idList,
      ignoreList = ignoreList,
      outputConfiguration = reportOutputConfiguration,
      mode = Some("append"),
      auditDate = auditDate,
      hdfs = hdfs,
      reporting = reporting)

    diffOutput match {
      case Some(diffOutputConf) =>
        val diffOutputDF = diff.filter((col("diff") === "D") || (col("diff") === "I"))
        if (diffOutputDF.count > 0) saveOutput(df = diffOutputDF,
          leftInput = leftInput,
          rightInput = rightInput,
          idList = idList,
          ignoreList = ignoreList,
          outputConfiguration = diffOutputConf,
          auditDate = auditDate,
          hdfs = hdfs,
          reporting = reporting)
      case _ =>
    }
  }

  /**
   * This function will realize the comparison row by row between the two DataFrames leftDF and right DF.
   * As idList si specified, the program will base itself on the specified columns to identify the unique keys and will
   * compare the rows and define the changes.
   *
   * @param leftDF     DataFrame read from leftInput source
   * @param rightDF    DataFrame read from rightInput source
   * @param leftInput  Left source of type com.socgen.bsc.dpc.iohandler.input.InputConfiguration
   * @param rightInput Right source of type com.socgen.bsc.dpc.iohandler.input.InputConfiguration
   * @param idList     List of columns used to identify a unique row , they must be present in both dataframes
   *                   (Specified in the json configuration)
   * @param ignoreList List of columns to withdraw from the comparison
   * @param reportOutputConfiguration Report output of type com.socgen.bsc.dpc.iohandler.output.OutputConfiguration
   *                                  It will contain the information like the schema differences and the number of rows
   *                                  in each DF
   * @param diffOutput Difference output of type com.socgen.bsc.dpc.iohandler.output.OutputConfiguration
   *                   It will contain the differences between the two DataFrames at row level.
   *                   The output is completely different when idList is specified or not.
   * @param auditDate  Date specified in the properties to historize the comparison
   * @param hdfs       Hdfs configuration created in the Main.scala object
   * @param reporting  Reporting configuration to log the information
   * @param spark      Implicit Spark Session
   * @example Given the following DataFrames as input:
   *          idList: [name,species]
   *          leftDF:   |   name   | species | age |
   *          |  Sparky  |   dog   | 10  |
   *          | Garfield |   cat   | 12  |
   *          rightDF:  |   name   | species | age |
   *          |  Sparky  |   dog   | 11  |
   *          |  Tommy   |   cat   | 13  |
   *          The resulted DataFrame will be as following :
   *          diffOutput: 
   *          |      ids       |        diff_type         | column | left_value | right_value | The program will the use the
   *          | Garfield|~|cat |     LEFT_INSERTED_ROW    |  age   |      12    |             | combination of name and specifies to
   *          |   Tommy|~|cat  |     RIGHT_INSERTED_ROW   |  age   |            |     13      | identify the ids and do the comparison.
   *          This function will only get the deleted and the inserted row , the intersection between the two DataFrame
   *          will be processed in the next step
   * @note Please check IoHandler documentation for more information about Object from package com.socgen.bsc.dpc.iohandler
   */
  private def compareDFsWithIdList(leftDF: DataFrame,
                                   rightDF: DataFrame,
                                   leftInput: String,
                                   rightInput: String,
                                   idList: Seq[String],
                                   ignoreList: Seq[String],
                                   reportOutputConfiguration: OutputConfiguration,
                                   diffOutput: Option[OutputConfiguration],
                                   auditDate: String,
                                   hdfs: FileSystem,
                                   reporting: Reporting)
                                  (implicit spark: SparkSession): Unit = {
    import spark.implicits._  

    val otherLeftColumns = leftDF.columns.filterNot(idList.toSet)
    val otherRightColumns = rightDF.columns.filterNot(idList.toSet)

    val leftIds = leftDF.select(idList.map(column => col(column)):_*)
    val rightIds = rightDF.select(idList.map(column => col(column)):_*)

    val onlyLeftIds = leftIds.except(rightIds)
    val onlyRightIds = rightIds.except(leftIds)

    val commonIds = leftIds.union(rightIds).except(onlyLeftIds).except(onlyRightIds).distinct()
    
    leftDF.createOrReplaceTempView("leftDF")
    rightDF.createOrReplaceTempView("rightDF")

    // DELETED ROWS

    onlyLeftIds.createOrReplaceTempView("onlyLeftIds")
    val deletedRowsQuery = "SELECT leftDF." + leftDF.columns.mkString(", leftDF.") + " FROM leftDF INNER JOIN onlyLeftIds WHERE " +  generateJoinFilter(df1Name = "leftDF", df2Name = "onlyLeftIds", cols = idList)
    val deletedRows = spark.sql(deletedRowsQuery)
      .withColumn(idsValueColumn, concat_ws("|~|", idList.map(column => col(column)): _*))
      .withColumn(diffTypeColumn, lit(DR))
      .withColumn(columnName, lit(flatSequence(mySeq = otherLeftColumns)))
      .withColumn(leftValueColumn, concat_ws("|~|", otherLeftColumns.map(column => col(column)): _*))
      .withColumn(rightValueColumn, lit(""))
      .select(idsValueColumn, diffTypeColumn, columnName, leftValueColumn, rightValueColumn)

    // INSERTED ROWS

    onlyRightIds.createOrReplaceTempView("onlyRightIds")
    val insertedRowsQuery = "SELECT rightDF." + rightDF.columns.mkString(", rightDF.") + " FROM rightDF INNER JOIN onlyRightIds WHERE " + generateJoinFilter(df1Name = "rightDF", df2Name = "onlyRightIds", cols = idList)
    val insertedRows = spark.sql(insertedRowsQuery)
      .withColumn(idsValueColumn, concat_ws("|~|", idList.map(column => col(column)): _*))
      .withColumn(diffTypeColumn, lit(IR))
      .withColumn(columnName, lit(flatSequence(mySeq = otherRightColumns)))
      .withColumn(leftValueColumn, lit(""))
      .withColumn(rightValueColumn, concat_ws("|~|", otherRightColumns.map(column => col(column)): _*))
      .select(idsValueColumn, diffTypeColumn, columnName, leftValueColumn, rightValueColumn)


    // COMMON IDS

    commonIds.createOrReplaceTempView("commonIds")
    val commonLeftRowsQuery = "SELECT leftDF." + leftDF.columns.mkString(", leftDF.") + " FROM leftDF INNER JOIN commonIds WHERE " + generateJoinFilter(df1Name = "leftDF", df2Name = "commonIds", cols = idList)
    val commonLeftRows = spark.sql(commonLeftRowsQuery)
    val commonRightRowsQuery = "SELECT rightDF."+ rightDF.columns.mkString(", rightDF.") + " FROM rightDF INNER JOIN commonIds WHERE " + generateJoinFilter(df1Name = "rightDF", df2Name = "commonIds", cols = idList)
    val commonRightRows = spark.sql(commonRightRowsQuery)


    val numberOfRowDeleted = deletedRows.count
    val numberOfRowInserted = insertedRows.count 

    val typeDifference = if (numberOfRowDeleted == 0 && numberOfRowInserted == 0) NA
    else if (numberOfRowDeleted != 0 && numberOfRowInserted == 0) DR
    else if (numberOfRowDeleted == 0 && numberOfRowInserted != 0) IR
    else if (numberOfRowDeleted == numberOfRowInserted) s"$DR == $IR"
    else if (numberOfRowDeleted < numberOfRowInserted) s"$DR < $IR"
    else s"$DR > $IR"

    val finalDF = Seq((s"$typeDifference", "REPORT_DIFF", s"$DR: $numberOfRowDeleted", s"$IR: $numberOfRowInserted"))
      .toDF(diffTypeColumn, columnName, leftValueColumn, rightValueColumn)

    saveOutput(df = finalDF,
      leftInput = leftInput,
      rightInput = rightInput,
      idList = idList,
      ignoreList = ignoreList,
      outputConfiguration = reportOutputConfiguration,
      mode = Some("append"),
      auditDate = auditDate,
      hdfs = hdfs,
      reporting = reporting)

    diffOutput match {
      case Some(diffOutputConf) =>  
        val mode = if(numberOfRowDeleted > 0 && numberOfRowInserted > 0) {
          saveOutput(df = deletedRows,
            leftInput = leftInput,
            rightInput = rightInput,
            idList = idList,
            ignoreList = ignoreList,
            outputConfiguration = diffOutputConf,
            auditDate = auditDate,
            hdfs = hdfs,
            reporting = reporting)
          saveOutput(df = insertedRows,
            leftInput = leftInput,
            rightInput = rightInput,
            idList = idList,
            ignoreList = ignoreList,
            outputConfiguration = diffOutputConf,
            mode = Some("append"),
            auditDate = auditDate,
            hdfs = hdfs,
            reporting = reporting)
          Some("append")
        } else if(numberOfRowDeleted > 0) {
          saveOutput(df = deletedRows,
            leftInput = leftInput,
            rightInput = rightInput,
            idList = idList,
            ignoreList = ignoreList,
            outputConfiguration = diffOutputConf,
            auditDate = auditDate,
            hdfs = hdfs,
            reporting = reporting)
          Some("append")
        } else if(numberOfRowInserted > 0) {
          saveOutput(df = deletedRows,
            leftInput = leftInput,
            rightInput = rightInput,
            idList = idList,
            ignoreList = ignoreList,
            outputConfiguration = diffOutputConf,
            auditDate = auditDate,
            hdfs = hdfs,
            reporting = reporting)
          Some("append")
        } else {
          None
        }

        compareDFsIntersection(leftDF = commonLeftRows,
          rightDF = commonRightRows,
          leftInput = leftInput,
          rightInput = rightInput,
          idList = idList,
          ignoreList = ignoreList,
          mode = mode,
          diffOutputConf = diffOutputConf,
          auditDate = auditDate,
          hdfs = hdfs,
          reporting = reporting)
      case _ => Unit
    }

    spark.catalog.dropTempView("leftDF")
    spark.catalog.dropTempView("rightDF")
    spark.catalog.dropTempView("onlyLeftIds")
    spark.catalog.dropTempView("onlyRightIds")
    spark.catalog.dropTempView("commonIds")
    
  }

  /**
   * This function will realize the comparison row by row between the two DataFrames leftDF and right DF.
   * As idList si specified, the program will base itself on the specified columns to identify the unique keys and will
   * compare the rows and define the changes. The dataframes have the same ids because it's the intersection between the two.
   *
   * @param leftDF     DataFrame read from leftInput source
   * @param rightDF    DataFrame read from rightInput source
   * @param leftInput  Left source of type com.socgen.bsc.dpc.iohandler.input.InputConfiguration
   * @param rightInput Right source of type com.socgen.bsc.dpc.iohandler.input.InputConfiguration
   * @param idList     List of columns used to identify a unique row , they must be present in both dataframes
   *                   (Specified in the json configuration)
   * @param ignoreList List of columns to withdraw from the comparison
   * @param diffOutputConf Difference output of type com.socgen.bsc.dpc.iohandler.output.OutputConfiguration
   *                   It will contain the differences between the two DataFrames at row level.
   *                   The output is completely different when idList is specified or not.
   * @param auditDate  Date specified in the properties to historize the comparison
   * @param hdfs       Hdfs configuration created in the Main.scala object
   * @param reporting  Reporting configuration to log the information
   * @param spark      Implicit Spark Session
   * @example Given the following DataFrames as input:
   *          idList: [name,species]
   *          leftDF:   |   name   | species | age |
   *          |  Sparky  |   dog   | 10  |
   *          rightDF:  |   name   | species | age |
   *          |  Sparky  |   dog   | 11  |
   *          The resulted DataFrame will be as following :
   *          diffOutput: 
   *          |     ids      | diff_type | column | left_value | right_value | 
   *          | Sparky|~|dog |     C     |  age   |     10     |     11      | 
   *          As the dataframe contain common ids, it will directly indentify the changes between the rows with the same ids
   * @note Please check IoHandler documentation for more information about Object from package com.socgen.bsc.dpc.iohandler
   */
  private def compareDFsIntersection(leftDF: DataFrame,
                                  rightDF: DataFrame,
                                  leftInput: String,
                                  rightInput: String,
                                  idList: Seq[String],
                                  ignoreList: Seq[String],
                                  mode: Option[String] = None,
                                  diffOutputConf: OutputConfiguration,
                                  auditDate: String,
                                  hdfs: FileSystem,
                                  reporting: Reporting)
                                 (implicit spark: SparkSession): Unit = {
    import spark.implicits._  
    val diff = leftDF.diff(rightDF, idList: _*).filter(col("diff") =!= "N").cache

    val diff_columns = diff.columns.flatMap {
      column => if (column.matches("left_.*")) Some(column.replace("left_", "")) else None
    }

    val dfSeq = diff_columns.flatMap {
      column =>
        val columns_list = idList ++ List("diff", s"left_$column", s"right_$column")
        val formattedDF = diff.filter((diff(s"left_$column") =!= diff(s"right_$column")) ||
          (diff(s"left_$column").isNull && diff(s"right_$column").isNotNull)
          || (diff(s"left_$column").isNotNull && diff(s"right_$column").isNull))
          .select(columns_list.map(column => col(s"$column")): _*)
          .withColumn(idsValueColumn, concat_ws("|~|", idList.map(column => col(column)): _*))
          .withColumnRenamed("diff", diffTypeColumn)
          .withColumn(columnName, lit(s"$column"))
          .withColumn(leftValueColumn, col(s"left_$column").cast(StringType))
          .withColumn(rightValueColumn, col(s"right_$column").cast(StringType))
          .select(idsValueColumn, diffTypeColumn, columnName, leftValueColumn, rightValueColumn)
        if (formattedDF.count > 0)
          Some(formattedDF)
        else None
    }

    dfSeq.headOption match {
      case Some(head) => saveOutput(df = head,
        leftInput = leftInput,
        rightInput = rightInput,
        idList = idList,
        ignoreList = ignoreList,
        outputConfiguration = diffOutputConf,
        mode = mode,
        auditDate = auditDate,
        hdfs = hdfs,
        reporting = reporting)
        dfSeq.tail.foreach {
          formattedDF =>
            saveOutput(df = formattedDF,
              leftInput = leftInput,
              rightInput = rightInput,
              idList = idList,
              ignoreList = ignoreList,
              outputConfiguration = diffOutputConf,
              mode = Some("append"),
              auditDate = auditDate,
              hdfs = hdfs,
              reporting = reporting)
        }
      case _ => saveOutput(df = Seq.empty[String].toDF,
        leftInput = leftInput,
        rightInput = rightInput,
        idList = idList,
        ignoreList = ignoreList,
        outputConfiguration = diffOutputConf,
        auditDate = auditDate,
        hdfs = hdfs,
        reporting = reporting)
    }
    
    diff.unpersist
  }

  /**
   * This function will save the DataFrame df to the specified output using the IoHandler library
   *
   * @param df                  DataFrame to save to destination specified in the outputConfiguration
   * @param leftInput           Left source of type com.socgen.bsc.dpc.iohandler.input.InputConfiguration
   * @param rightInput          Right source of type com.socgen.bsc.dpc.iohandler.input.InputConfiguration
   * @param idList              List of columns used to identify a unique row , they must be present in both dataframes
   *                            (Specified in the json configuration)
   * @param ignoreList          List of columns to withdraw from the comparison
   * @param outputConfiguration output of type com.socgen.bsc.dpc.iohandler.output.OutputConfiguration
   * @param auditDate           Date specified in the properties to historize the comparison
   * @param hdfs                Hdfs configuration created in the Main.scala object
   * @param reporting           Reporting configuration to log the information
   * @param spark               Implicit Spark Session
   * @example Given the following DataFrames as input:
   *          df: |    ids     | diff_type | column | left_value | right_value |
   *          | Sparky,dog |     C     |  age   |     10     |     11      |
   *          leftInput: leftDF
   *          rightInput: rightDF
   *          idList: [name,species]
   *          ignoreList: [ingestion_date]
   *          auditDate: 20220427
   *          The resulted DataFrame will be as following, the following columns auditDate, left_source, right_source, ids_columns
   *          and ignored_columns are added filled with the specified value :
   *          diffOutput:  | audit_date | left_source | right_source | ids_columns  | ignoreed_columns |    ids     | diff_type | column | left_value | right_value |
   *                       |  20220427  |   leftDF    |   rightDF    | name,species | ingestion_date   | Sparky,dog |     C     |  age   |     10     |     11      |
   * @note Please check IoHandler documentation for more information about Object from package com.socgen.bsc.dpc.iohandler
   */
  private def saveOutput(df: DataFrame,
                         leftInput: String,
                         rightInput: String,
                         idList: Seq[String],
                         ignoreList: Seq[String],
                         outputConfiguration: OutputConfiguration,
                         mode: Option[String] = None,
                         auditDate: String,
                         hdfs: FileSystem,
                         reporting: Reporting)
                        (implicit spark: SparkSession): Unit = {
    if (df.count != 0) {
      val toStoreDF = df.withColumn(Common.auditDateColName, lit(auditDate))
        .withColumn(Common.leftInputColumn, lit(s"$leftInput"))
        .withColumn(Common.rightInputColumn, lit(s"$rightInput"))
        .withColumn(Common.idsColumnNameColumn, lit(flatSequence(mySeq = idList)))
        .withColumn(Common.ignoredColumnNameColumn, lit(flatSequence(mySeq = ignoreList)))
        .select(Common.auditDateColName, Common.reportHeaderColumns ++ df.columns: _*)

      OutputHandler.saveDFToOutputConfig(unprocessedDF = toStoreDF,
        outputConfiguration = outputConfiguration,
        mode = Some("Append"),
        hdfs = hdfs)
    }
  }

  /**
   * This function will take a dfComparison object and realize the
   *
   * @param dfComparison              DataFrameComparison object with a left source and a right source to compare, with a
   *                                  mandatory report output to store the report information and an optional diff output where to
   *                                  store the differences found between the left and the right source
   * @param reportOutputConfiguration Report output of type com.socgen.bsc.dpc.iohandler.output.OutputConfiguration.
   *                                  It will contain the information like the schema differences and the number of rows in each DF
   * @param diffOutput                Difference output of type com.socgen.bsc.dpc.iohandler.output.OutputConfiguration.
   *                                  It will contain the differences between the two DataFrames at row level.
   *                                  The output is completely different when idList is specified or not.
   * @param auditDate                 Date specified in the properties to historize the comparison
   * @param hdfs                      Hdfs configuration created in the Main.scala object
   * @param reporting                 Reporting configuration to log the information
   * @param spark                     Implicit Spark Session
   * @example Given the following DataFrames as input:
   *          leftDF:   |   name   | species | age |
   *          |  Sparky  |   dog   | 10  |
   *          rightDF:  |   name   | species | age |
   *          |  Sparky  |   dog   | 11  |
   *          The result DataFrame will be as following :
   *          The mode is defined
   *          reportOutput: |      diff_type      | column |       left_value      |      right_value      |
   *          | TOTAL_DISTINCT_ROW  | REPORT | TOTAL_DISTINCT_ROW: 1 | TOTAL_DISTINCT_ROW: 1 |
   *          Plus we will compare the schema and the rows
   */
  def compareDFsAndSaveResults(dfComparison: DataFrameComparison,
                               reportOutputConfiguration: OutputConfiguration,
                               diffOutput: Option[OutputConfiguration],
                               auditDate: String,
                               hdfs: FileSystem,
                               reporting: Reporting)
                              (implicit spark: SparkSession): Unit = {
    import spark.implicits._
    val (fistSaveMode, leftDFToCompare, rightDFToCompare) = compareSchemaAndGetDFs(leftDF = dfComparison.leftDF,
      rightDF = dfComparison.rightDF,
      leftInput = dfComparison.leftColumnName,
      rightInput = dfComparison.rightColumnName,
      idList = dfComparison.idList,
      ignoreList = dfComparison.ignoreList,
      reportOutputConfiguration = reportOutputConfiguration,
      auditDate = auditDate,
      hdfs = hdfs,
      reporting = reporting)

    val leftDFTotalDistinctRow = leftDFToCompare.distinct.count
    val rightDFTotalDistinctRow = rightDFToCompare.distinct.count

    val reportDF = Seq((TDR, "REPORT", s"$TDR $leftDFTotalDistinctRow", s"$TDR $rightDFTotalDistinctRow"))
      .toDF(diffTypeColumn, columnName, leftValueColumn, rightValueColumn)

    saveOutput(df = reportDF,
      leftInput = dfComparison.leftColumnName,
      rightInput = dfComparison.rightColumnName,
      idList = dfComparison.idList,
      ignoreList = dfComparison.ignoreList,
      outputConfiguration = reportOutputConfiguration,
      mode = fistSaveMode,
      auditDate = auditDate,
      hdfs = hdfs,
      reporting = reporting)

    if (dfComparison.idList.isEmpty) {
      compareDFs(leftDF = leftDFToCompare,
        rightDF = rightDFToCompare,
        leftInput = dfComparison.leftColumnName,
        rightInput = dfComparison.rightColumnName,
        idList = dfComparison.idList,
        ignoreList = dfComparison.ignoreList,
        reportOutputConfiguration = reportOutputConfiguration,
        diffOutput = diffOutput,
        auditDate = auditDate,
        hdfs = hdfs,
        reporting = reporting)
    } else {
      compareDFsWithIdList(leftDF = leftDFToCompare,
        rightDF = rightDFToCompare,
        leftInput = dfComparison.leftColumnName,
        rightInput = dfComparison.rightColumnName,
        idList = dfComparison.idList,
        ignoreList = dfComparison.ignoreList,
        reportOutputConfiguration = reportOutputConfiguration,
        diffOutput = diffOutput,
        auditDate = auditDate,
        hdfs = hdfs,
        reporting = reporting)
    }
  }
}