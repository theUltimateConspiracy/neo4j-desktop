package com.socgen.bsc.dpc.audit.common

import com.socgen.bsc.dpc.common.exception.TechnicalException
import com.socgen.bsc.dpc.common.logger.ContentToJson._
import com.socgen.bsc.dpc.common.logger.Message
import com.socgen.bsc.dpc.iohandler.config.ConfigHandler
import com.socgen.sdt.logging.loggers.impl.DataLoggerFactory
import org.apache.spark.sql.types.DataType
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.annotation.tailrec

/**
 * This case class define the attributes of the DataFrame comparison which will be used to compare the left and the right
 *
 * @param leftDF          DataFrame that will be used as the original one during comparison
 * @param leftColumnName  Source of the leftDF
 * @param rightDF         DataFrame that will be used as the new one during comparison
 * @param rightColumnName Source of the rightDF
 * @param idList          Sequence of columns use to define the primary keys
 * @param ignoreList        Sequence of columns that will be ignored during the comparison
 */
case class DataFrameComparison(
                                leftDF: DataFrame,
                                leftColumnName: String,
                                rightDF: DataFrame,
                                rightColumnName: String,
                                idList: Seq[String],
                                ignoreList: Seq[String]
                              )

/**
 *
 */
object Common {
  /**
   * Constant
   */
  final val NA = "NO_CHANGES"
  final val TDR = "TOTAL_DISTINCT_ROW"
  final val DR = "LEFT_DELETED_ROW"
  final val IR = "RIGHT_INSERTED_ROW"
  final val TD = "TYPE_DIFFERENCE"
  final val LAC = "LEFT_ADDED_COLUMN"
  final val RAC = "RIGHT_ADDED_COLUMN"

  // Columns
  final val idsValueColumn = "ids"
  final val idsColumnNameColumn = "ids_columns"
  final val ignoredColumnNameColumn = "ignored_columns"
  final val columnName = "column"
  final val leftValueColumn = "left_value"
  final val rightValueColumn = "right_value"

  final val auditDateColName = "audit_date"
  final val diffTypeColumn = "diff_type"
  final val leftInputColumn = "left_source"
  final val rightInputColumn = "right_source"

  // Report DF Header
  final val reportHeaderColumns = Seq(leftInputColumn, rightInputColumn, idsColumnNameColumn, ignoredColumnNameColumn)

  final val auditDateArg = "auditDate"

  private lazy val log = DataLoggerFactory.getLogger("audit.common.Common")

  /**
   * This function will compare the two inputs and the report output and will raise and error if two of them are equals
   *
   * @param leftInput    Left source for the comparison
   * @param rightInput   Right source for comparison
   * @param reportOutput Report output where to save the report of the comparison
   */
  def checkParameters(leftInput: String, rightInput: String, reportOutput: String): Unit = {
    if (leftInput.replaceAll("hdfs://|/", "") == rightInput.replaceAll("hdfs://|/", "")
      && rightInput.replaceAll("hdfs://|/", "") == reportOutput.replaceAll("hdfs://|/", "")) {
      throw TechnicalException(s"ERROR(Illegal argument exception): " +
        s"All arguments (leftInput, rightInput, reportOutput) are equals to '$leftInput'")
    } else if (leftInput.replaceAll("hdfs://|/", "") == rightInput.replaceAll("hdfs://|/", "")) {
      throw TechnicalException(s"ERROR(Illegal argument exception): leftInput '$leftInput' is equal to rightInput '$rightInput'")
    } else if (leftInput.replaceAll("hdfs://|/", "") == reportOutput.replaceAll("hdfs://|/", "")) {
      throw TechnicalException(s"ERROR(Illegal argument exception): leftInput '$leftInput' is equal to reportOutput '$reportOutput'")
    } else if (rightInput.replaceAll("hdfs://|/", "") == reportOutput.replaceAll("hdfs://|/", "")) {
      throw TechnicalException(s"ERROR(Illegal argument exception): rightInput '$rightInput' is equal to reportOutput '$reportOutput'")
    }
  }

  /**
   * This function will compare the two inputs and the report output and will raise and error if two of them are equals
   *
   * @param leftInput    Left source for the comparison
   * @param rightInput   Right source for comparison
   * @param reportOutput Report output where to save the report of the comparison
   * @param diffOutput   Difference output where to save the differences revealed by the comparison
   */
  def checkParameters(leftInput: String, rightInput: String, reportOutput: String, diffOutput: String): Unit = {
    if (leftInput.replaceAll("hdfs://|/", "") == rightInput.replaceAll("hdfs://|/", "")
      && rightInput.replaceAll("hdfs://|/", "") == reportOutput.replaceAll("hdfs://|/", "")
      && reportOutput.replaceAll("hdfs://|/", "") == diffOutput.replaceAll("hdfs://|/", "")) {
      throw TechnicalException(s"ERROR(Illegal argument exception): " +
        s"All arguments (leftInput, rightInput, reportOutput, diffOutput) are equals to '$leftInput'")
    } else if (leftInput.replaceAll("hdfs://|/", "") == rightInput.replaceAll("hdfs://|/", "")) {
      throw TechnicalException(s"ERROR(Illegal argument exception): leftInput '$leftInput' is equal to rightInput '$rightInput'")
    } else if (leftInput.replaceAll("hdfs://|/", "") == reportOutput.replaceAll("hdfs://|/", "")) {
      throw TechnicalException(s"ERROR(Illegal argument exception): leftInput '$leftInput' is equal to reportOutput '$reportOutput'")
    } else if (rightInput.replaceAll("hdfs://|/", "") == reportOutput.replaceAll("hdfs://|/", "")) {
      throw TechnicalException(s"ERROR(Illegal argument exception): rightInput '$rightInput' is equal to reportOutput '$reportOutput'")
    } else if (rightInput.replaceAll("hdfs://|/", "") == diffOutput.replaceAll("hdfs://|/", "")) {
      throw TechnicalException(s"ERROR(Illegal argument exception): rightInput '$rightInput' is equal to diffOutput '$diffOutput'")
    } else if (diffOutput.replaceAll("hdfs://|/", "") == reportOutput.replaceAll("hdfs://|/", "")) {
      throw TechnicalException(s"ERROR(Illegal argument exception): diffOutput '$diffOutput' is equal to reportOutput '$reportOutput'")
    } else if (diffOutput.replaceAll("hdfs://|/", "") == leftInput.replaceAll("hdfs://|/", "")) {
      throw TechnicalException(s"ERROR(Illegal argument exception): diffOutput '$diffOutput' is equal to leftInput '$leftInput'")
    }
  }

  /**
   * Function recursive to get the arguments values from a map
   *
   * @param map  A empty map where to store the values of the Arguments
   * @param list A list of the arguments given to the main functions
   * @return A map of strings
   */
  @tailrec
  def parseArguments(map: Map[String, String], list: List[String]): Map[String, String] = {
    list match {
      case Nil => map
      case ("--config-path" | "-cp") :: path :: tail =>
        parseArguments(map ++ Map(ConfigHandler.configPathArg -> path), tail)
      case ("--audit-date" | "-ad") :: auditDate :: tail =>
        parseArguments(map ++ Map(auditDateArg -> auditDate), tail)
      case ("--filename" | "-f") :: filename :: tail =>
        parseArguments(map ++ Map(ConfigHandler.fileNamePathArg -> filename), tail)
      case ("--on-S3" | "-s3") :: isS3 :: tail =>
        parseArguments(map ++ Map(ConfigHandler.isS3 -> isS3), tail)
      case unknown :: tail =>
        log.info(Message(s"unknown arguments $unknown"))
        parseArguments(map, tail)
    }
  }

  /**
   * This function will analyse the schema of the left and the right DataFrames. and will return
   *
   * @param column        list of all the distinct columns contained in the left and the right DataFrames
   * @param leftDfFields  Map of String and DataType of the columns of the left DataFrame
   * @param rightDfFields Map of String and DataType of the columns of the right DataFrame
   * @param spark         Implicit Spark Session
   * @return a DataFrame which contains the result of the schema comparison and a Sequence of String of the columns
   *         that must be ignored for the comparison
   */
  def getTypeOfDistinctColumn(column: Seq[String],
                              leftDfFields: Map[String, DataType],
                              rightDfFields: Map[String, DataType])
                             (implicit spark: SparkSession): (DataFrame, Seq[String]) = {
    import spark.implicits._
    column.headOption match {
      case Some(head) =>
        if (leftDfFields.contains(head) && rightDfFields.contains(head)) {
          val headLeftType = leftDfFields(head).toString
          val headRightType = rightDfFields(head).toString
          if (headLeftType == headRightType) { // Type are equals
            getTypeOfDistinctColumn(column = column.tail,
              leftDfFields = leftDfFields,
              rightDfFields = rightDfFields)
          } else {
            val (childDF, childColumnDrop) = getTypeOfDistinctColumn(column = column.tail,
              leftDfFields = leftDfFields,
              rightDfFields = rightDfFields)
            (Seq((TD, head, s"Type : $headLeftType", s"Type : $headRightType"))
              .toDF(diffTypeColumn, columnName, leftValueColumn, rightValueColumn)
              .union(childDF), childColumnDrop)
          }
        } else if (leftDfFields.contains(head) && !rightDfFields.contains(head)) {
          val (childDF, childColumnDrop) = getTypeOfDistinctColumn(column = column.tail,
            leftDfFields = leftDfFields,
            rightDfFields = rightDfFields)
          (Seq((LAC, head, s"Type : ${leftDfFields(head).toString}", "NULL"))
            .toDF(diffTypeColumn, columnName, leftValueColumn, rightValueColumn)
            .union(childDF), childColumnDrop ++ Seq(head))
        } else if (rightDfFields.contains(head) && !leftDfFields.contains(head)) {
          val (childDF, childColumnDrop) = getTypeOfDistinctColumn(column = column.tail,
            leftDfFields = leftDfFields,
            rightDfFields = rightDfFields)
          (Seq((RAC, head, "NULL", s"Type : ${rightDfFields(head).toString}"))
            .toDF(diffTypeColumn, columnName, leftValueColumn, rightValueColumn)
            .union(childDF), childColumnDrop ++ Seq(head))
        } else {
          val leftDfFieldsToStr = leftDfFields.map {
            case (field, fieldType) => s"$field (type: ${fieldType.toString})"
          }.toSeq.mkString(",")
          val rightDfFieldsToStr = rightDfFields.map {
            case (field, fieldType) => s"$field (type: ${fieldType.toString})"
          }.toSeq.mkString(",")
          throw TechnicalException(s"Left DF Fields ($leftDfFieldsToStr) and Right DF Fields ($rightDfFieldsToStr) " +
            s"does not contain column : $head")
        }
      case _ => (Seq.empty[(String, String, String, String)]
        .toDF(diffTypeColumn, columnName, leftValueColumn, rightValueColumn), Seq.empty[String])
    }
  }
}