package com.socgen.bsc.dpc.jobmon.test

import com.socgen.bsc.dpc.jobmon.JobMon
import com.socgen.bsc.dpc.jobmon.consumers.collections._
import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkConf
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Dataset, Row, SparkSession}
import org.scalatest.GivenWhenThen
import org.scalatest.flatspec.AnyFlatSpec

class JobMonTest extends AnyFlatSpec with GivenWhenThen
{
    // Deactivating logger for spark as to not pollute test report.
    Logger.getLogger("org.apache.spark").setLevel(Level.WARN)
    Logger.getLogger("org.apache.parquet").setLevel(Level.WARN)
    Logger.getLogger("org.spark-project").setLevel(Level.WARN)

    // Real testsuite begins here

    "The JobMon object" should "be able to execute a complete workflow" in
        {
            //region Spark Conf setup

            Given("the SummaryPrinters and Summary Publishers collection enabled")

            assert(JobMon.enableCollection(SummaryPrinters))
            assert(JobMon.enableCollection(JsonPrinters))
            assert(JobMon.enableCollection(SummaryPublishers))

            JobMon.configureEsConnection(defaultIndex = "bscdpchprd-jobmontest",
                                         credentials = ("es_bsc_dpc", "IdGEXbbJaWlrCcjNLg=="))

            When("the Spark conf is given to JobMon")

            var conf = new SparkConf()
                .setAppName("RandomTestApp")
                .setMaster("local[*]")

            conf = JobMon.registerListeners(conf)

            Then("the Spark conf should have been modified")

            assert(conf.contains("spark.extraListeners"))
            assert(conf.get("spark.extraListeners").contains("ConsumerManager"))
            assert(conf.get("spark.extraListeners").contains("QueryManager"))

            //endregion

            //region Spark Session setup

            When("the Spark session is created")

            implicit val spark: SparkSession = SparkSession.builder
                                               .config(conf)
                                               .getOrCreate

            Then("JobMon should have read the application name")
            assert(JobMon.getAppEntry.appName == spark.sparkContext.appName)

            And("Spark application ID")
            assert(JobMon.getAppEntry.appId == spark.sparkContext.applicationId)

            And("application starting time")
            assert(JobMon.getAppEntry.appSparkStartTime == spark.sparkContext.startTime)
            assert(JobMon.getAppEntry.appMainStartTime < spark.sparkContext.startTime)

            //endregion

            //region README Count query

            Given("a cached dataframe created from README.md")

            val textFile = spark.read.textFile("README.md")

            import spark.implicits._
            val dfWordCount = textFile
                              .flatMap(line => line.toLowerCase.split("\\s+").filterNot(_ == ""))
                              .groupByKey(identity).count()
                              .withColumnRenamed("value", "word")
                              .withColumnRenamed("count(1)", "occurrence")
                              .orderBy(desc("occurrence"))
                              .cache()

            When("queries are processed")

            val dfEvenOcc = dfWordCount
                            .filter(dfWordCount("occurrence") % 2 === 0)
            dfEvenOcc.show()

            val dfOddOcc = dfWordCount
                           .filter(dfWordCount("occurrence") % 2 === 1)
            dfOddOcc.show()

            val dfMostUsed = dfWordCount
                             .select(col("word").as("most_used_word"))
                             .where(dfWordCount("occurrence") === dfWordCount.groupBy()
                                                                  .max("occurrence")
                                                                  .first().getLong(0))
            dfMostUsed.show()

            Then("Core collection consumers should have triggered")

            // Some Job Entries have been created
            assert(JobMon.getEntryFromJobId(0).isDefined)
            assert(JobMon.getEntryFromStageId(0).isDefined)

            // Some Query Entries have been created AND are linked to job entries
            val veryFirstQuery = JobMon.getQueryEntry(0)
            assert(veryFirstQuery.isDefined)
            assert(JobMon.getJobEntriesFromQuery(veryFirstQuery.get).nonEmpty)

            //endregion

            //region Writing output tables

            When("Spark dataframes are saved as text files")

            def saveTable(df: Dataset[Row], tableName: String): Unit = df.coalesce(1).write
                                                                       .mode("overwrite")
                                                                       .option("header", value = true)
                                                                       //.option("path", "./artifacts/")
                                                                       .parquet(s"./artifacts/$tableName.parquet")
            //.saveAsTable(tableName)

            saveTable(dfWordCount, "WC_full")
            saveTable(dfEvenOcc, "WC_evens")
            saveTable(dfOddOcc, "WC_odds")
            saveTable(dfMostUsed, "WC_most_used")

            Then("SaveTable entries should have been created")
            assert(JobMon.queryEntries.values.exists(_.querySavedTable.isDefined))

            //endregion
        }
}