package com.socgen.bsc.dpc.jobmon.consumers

import com.socgen.bsc.dpc.jobmon.JobMon
import com.socgen.bsc.dpc.jobmon.entries.{ExecutorEntry, JobEntry}
import org.apache.spark.scheduler.SparkListenerTaskEnd

//region Trait

trait TaskConsumer
{
    val name: String

    def triggerOn(jobEntry: JobEntry, executorEntry: ExecutorEntry, taskCompleted: SparkListenerTaskEnd): Unit
}

//endregion

//region Consumer definition

class MetricsRecorder extends TaskConsumer
{
    val name = "MetricsFiller"

    def triggerOn(jobEntry: JobEntry, executorEntry: ExecutorEntry, taskCompleted: SparkListenerTaskEnd): Unit =
    {
        // Fetching input/output metrics
        val taskId: Long = taskCompleted.taskInfo.taskId
        val executorId = taskCompleted.taskInfo.executorId
        val taskRead = taskCompleted.taskMetrics.inputMetrics.recordsRead
        val taskWritten = taskCompleted.taskMetrics.outputMetrics.recordsWritten
        val bytesRead = taskCompleted.taskMetrics.inputMetrics.bytesRead
        val bytesWritten = taskCompleted.taskMetrics.outputMetrics.bytesWritten
        val taskRunTime = taskCompleted.taskMetrics.executorRunTime
        val taskCpuTime = taskCompleted.taskMetrics.executorCpuTime / 1000000 // Nano to milliseconds
        val peakMemory = taskCompleted.taskMetrics.peakExecutionMemory

        // Saving information on linked job entry
        jobEntry.recordsRead += (taskId -> taskRead)
        jobEntry.recordsWritten += (taskId -> taskWritten)
        jobEntry.bytesRead += (taskId -> bytesRead)
        jobEntry.bytesWritten += (taskId -> bytesWritten)
        jobEntry.executorRunTime += (taskId -> taskRunTime)
        jobEntry.executorCpuTime += (taskId -> taskCpuTime)
        jobEntry.peakMemory += (taskId -> peakMemory)

        // Same for executor entry
        executorEntry.bytesRead += (taskId -> bytesRead)
        executorEntry.bytesWritten += (taskId -> bytesWritten)
        executorEntry.executorRunTime += (taskId -> taskRunTime)
        executorEntry.executorCpuTime += (taskId -> taskCpuTime)
        executorEntry.peakMemory += (taskId -> peakMemory)

        // Sending back to main object
        JobMon.addOrUpdateJobEntry(jobEntry)
    }
}

// TODO : Add more consumers as needed

//endregion



