package com.socgen.bsc.dpc.jobmon.consumers

import java.text.SimpleDateFormat

import com.socgen.bsc.dpc.jobmon.JobMon
import com.socgen.bsc.dpc.jobmon.entries.{AppEntry, ExecutorEntry, JobEntry, Jsonify}
import io.circe.syntax._
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FSDataOutputStream, FileSystem, Path}
import org.apache.spark.scheduler.SparkListenerApplicationEnd

import scala.collection.mutable.{Map => MMap}


//region Trait

trait AppConsumer
{
    val name: String

    def triggerOn(appEntry: AppEntry, jobEntries: MMap[Int, JobEntry], executorEntries: MMap[String, ExecutorEntry],
                  appEnd: SparkListenerApplicationEnd): Unit
}

//endregion

//region Consumer definition

class AppEntryFiller extends AppConsumer
{
    val name = "AppEntryFiller"

    def triggerOn(appEntry: AppEntry, jobEntries: MMap[Int, JobEntry], executorEntries: MMap[String, ExecutorEntry],
                  appEnd: SparkListenerApplicationEnd): Unit =
    {
        // Filling app entry
        appEntry.appEndTime = appEnd.time
        appEntry.appRecordsRead = jobEntries.values.map(_.jobRecordsRead).sum
        appEntry.appRecordsWritten = jobEntries.values.map(_.jobRecordsWritten).sum
        appEntry.appBytesRead = jobEntries.values.map(_.jobBytesRead).sum
        appEntry.appBytesWritten = jobEntries.values.map(_.jobBytesWritten).sum
        appEntry.appExecutorRunTime = executorEntries.values.map(_.totalExecutorRunTime).toSeq
        appEntry.appExecutorCpuTime = executorEntries.values.map(_.totalExecutorCpuTime).toSeq
        appEntry.appPeakMemory = executorEntries.values.map(_.executorPeakMemory).toSeq
        appEntry.appAverageMemory = executorEntries.values.map(_.executorAverageMemory).toSeq
        appEntry.appFailedStage = jobEntries.values.map(_.jobFailedStage).sum

        // Sending back to main object
        JobMon.updateAppEntry(appEntry)
    }
}

class TinyAppPrinter extends AppConsumer
{
    val name = "TinyAppPrinter"

    def formatLongTime(time: Long): String =
        new SimpleDateFormat("HH:mm:ss").format(time)

    def triggerOn(appEntry: AppEntry, jobEntries: MMap[Int, JobEntry], executorEntries: MMap[String, ExecutorEntry],
                  appEnd: SparkListenerApplicationEnd): Unit =
    {
        println(s"[JOBMON][APP] Application ${appEntry.appName} ended at ${formatLongTime(appEntry.appEndTime)}.\n"
                    + s" ~ Records read/written : ${appEntry.appRecordsRead} / ${appEntry.appRecordsWritten}.\n"
                    + s" ~ Absolute time taken : (Code) ${appEntry.appEndTime - appEntry.appMainStartTime} ms; (Spark) ${appEntry.appEndTime - appEntry.appSparkStartTime} ms.\n"
                    + s" ~ Executor run time : ${appEntry.appExecutorRunTime} ms; Executor cpu time : ${appEntry.appExecutorCpuTime} ms.")
    }
}


class JsonAppPrinter extends AppConsumer
{
    val name = "JsonAppPrinter"

    def triggerOn(appEntry: AppEntry, jobEntries: MMap[Int, JobEntry], executorEntries: MMap[String, ExecutorEntry],
                  appEnd: SparkListenerApplicationEnd): Unit =
    {
        import Jsonify.appEntryEncoder
        println(s"[JOBMON][APP] Writing app json :\n${appEntry.asJson}")
    }
}


class JsonAppLogger extends AppConsumer
{
    val name = "AppSummaryLogger"


    def triggerOn(appEntry: AppEntry, jobEntries: MMap[Int, JobEntry], executorEntries: MMap[String, ExecutorEntry],
                  appEnd: SparkListenerApplicationEnd): Unit =
    {
        import Jsonify.{appEntryEncoder, jobEntryEncoder}

        // Path creation
        val logPrefixPath = JobMon.getArtifactPrefixPath
        println(s"[JOBMON][APP] Trying to write jsons to $logPrefixPath.")

        val fs = FileSystem.get(new Configuration())

        // Writing app to json file
        val appOs: FSDataOutputStream = fs.create(new Path(s"$logPrefixPath/summary.json"))
        appOs.write(appEntry.asJson.toString.getBytes)
        appOs.close()

        // Writing jobs to json file
        val jobsOs: FSDataOutputStream = fs.create(new Path(s"$logPrefixPath/jobs.json"))
        jobsOs.write(jobEntries.toMap.asJson.toString.getBytes)
        jobsOs.close()
    }
}

class AppSummaryPublisher extends AppConsumer
{
    val name = "AppSummaryPublisher"

    def triggerOn(appEntry: AppEntry, jobEntries: MMap[Int, JobEntry], executorEntries: MMap[String, ExecutorEntry],
                  appEnd: SparkListenerApplicationEnd): Unit =
        JobMon.sendJsonToEs(appEntry, "apps")
}

// TODO : Add more consumers as needed

//endregion