package com.socgen.bsc.dpc.jobmon.entries


/** Register useful information about a Spark application. */
case class AppEntry(var appName: String,
                    var appId: String,
                    var appMainStartTime: Long,
                    var appSparkStartTime: Long = -1,
                    var appEndTime: Long = -1,
                    var appRecordsRead: Long = 0,
                    var appRecordsWritten: Long = 0,
                    var appBytesRead: Long = 0,
                    var appBytesWritten: Long = 0,
                    var appExecutorRunTime: Seq[Long] = Seq[Long](),
                    var appExecutorCpuTime: Seq[Long] = Seq[Long](),
                    var appPeakMemory: Seq[Long] = Seq[Long](),
                    var appAverageMemory: Seq[Long] = Seq[Long](),
                    var appFailedStage: Int = 0)

