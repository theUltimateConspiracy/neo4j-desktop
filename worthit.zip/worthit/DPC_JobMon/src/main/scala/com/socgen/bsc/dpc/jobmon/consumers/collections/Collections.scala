package com.socgen.bsc.dpc.jobmon.consumers.collections

import com.socgen.bsc.dpc.jobmon.consumers._

//region base abstract class

abstract case class Collection(
    appConsumers: Seq[AppConsumer],
    executorConsumers: Seq[ExecutorConsumer],
    queryConsumers: Seq[QueryConsumer],
    jobConsumers: Seq[JobConsumer],
    stageConsumers: Seq[StageConsumer],
    taskConsumers: Seq[TaskConsumer]
)

//endregion

//region Pre-made collections

/** This collection is HARDCODED inside JobMon and ESSENTIAL to its behavior
  * It shouldn't be added back to the JobMon object
  */
object CoreCollection extends Collection(
    Seq(new ExecutorEntryFiller, new AppEntryFiller),
    Seq(new ExecutorEntryFiller),
    Seq(new QueryEntryFiller, new SavedTableFiller),
    Seq(new JobEntryFiller),
    Seq(new FailureRecorder),
    Seq(new MetricsRecorder)
    )


object SummaryPrinters extends Collection(
    Seq(new TinyAppPrinter),
    Seq(new TinyExecutorPrinter),
    Seq(new TinyQueryPrinter, new SavedTablePrinter),
    Seq.empty,
    Seq.empty,
    Seq.empty
    )


object JsonPrinters extends Collection(
    Seq(new JsonAppPrinter),
    Seq(new JsonExecutorPrinter),
    Seq(new JsonQueryPrinter),
    Seq(new JsonJobPrinter),
    Seq.empty,
    Seq.empty
    )

object SummaryPublishers extends Collection(
    Seq(new AppSummaryPublisher, new ExecutorUpdatePublisher),
    Seq(new ExecutorUpdatePublisher),
    Seq(new QuerySummaryPublisher),
    Seq(new JobSummaryPublisher),
    Seq.empty,
    Seq.empty
    )


// TODO: Add more collections as needed

//endregion