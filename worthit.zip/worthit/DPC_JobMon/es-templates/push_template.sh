#!/bin/bash

push_template () {
    printf "ACTION : DELETE ; INDEX : $1-apps\n"
    curl -XDELETE https://dhadlx140.dns21.socgen:9200/_index_template/$1-apps -k -u "es_bsc_dpc:IdGEXbbJaWlrCcjNLg==";
    printf "\nACTION : PUT ; INDEX : $1-apps\n"
    curl -XPUT https://dhadlx140.dns21.socgen:9200/_index_template/$1-apps -k -u "es_bsc_dpc:IdGEXbbJaWlrCcjNLg==" -H "Content-Type:application/json" -d "@$1-apps.json";
    printf "\nACTION : DELETE ; INDEX : $1-queries\n"
    curl -XDELETE https://dhadlx140.dns21.socgen:9200/_index_template/$1-queries -k -u "es_bsc_dpc:IdGEXbbJaWlrCcjNLg==";
    printf "\nACTION : PUT ; INDEX : $1-queries\n"
    curl -XPUT https://dhadlx140.dns21.socgen:9200/_index_template/$1-queries -k -u "es_bsc_dpc:IdGEXbbJaWlrCcjNLg==" -H "Content-Type:application/json" -d "@$1-queries.json";
    printf "\nACTION : DELETE ; INDEX : $1-jobs\n"
    curl -XDELETE https://dhadlx140.dns21.socgen:9200/_index_template/$1-jobs -k -u "es_bsc_dpc:IdGEXbbJaWlrCcjNLg==";
    printf "\nACTION : PUT ; INDEX : $1-jobs\n"
    curl -XPUT https://dhadlx140.dns21.socgen:9200/_index_template/$1-jobs -k -u "es_bsc_dpc:IdGEXbbJaWlrCcjNLg==" -H "Content-Type:application/json" -d "@$1-jobs.json";
    printf "\nACTION : DELETE ; INDEX : $1-executors\n"
    curl -XDELETE https://dhadlx140.dns21.socgen:9200/_index_template/$1-executors -k -u "es_bsc_dpc:IdGEXbbJaWlrCcjNLg==";
    printf "\nACTION : PUT ; INDEX : $1-executors\n"
    curl -XPUT https://dhadlx140.dns21.socgen:9200/_index_template/$1-executors -k -u "es_bsc_dpc:IdGEXbbJaWlrCcjNLg==" -H "Content-Type:application/json" -d "@$1-executors.json";
}

push_template $1

#./push_template.sh bscdpchprd-jobmontest