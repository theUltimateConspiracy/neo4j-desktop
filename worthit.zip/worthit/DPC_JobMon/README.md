# JobMon

Short for Spark Job Monitor

## Quickstart

Add maven dependency to any project's pom.xml

```xml
<dependency>
    <groupId>com.socgen.dpc</groupId>
    <artifactId>jobmon</artifactId>
    <version>0.1-SNAPSHOT</version>
    <scope>provided</scope>
</dependency>
```

Since the jar is given as *provided*, we need to reference it to oozie workflow.xml in *spark-opts* (be sure to set path as needed).

```xml
<action name="dpc-spark-XXX" cred="credhive">
    <spark xmlns="uri:oozie:spark-action:U.V">
        <master>yarn</master>
        <mode>cluster</mode>
        <name>dpc-XXXX</name>
        <class>com.socgen.ZZZ.YYY.XXX.Main</class>
        <spark-opts>--jars ${libsPath}/jobmon.jar ...</spark-opts> // HERE
    </spark>
</action>
```

## Code Example

The JobMon monitoring is then available in code. Quick example below :

```scala
// Standard Spark imports
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession

// Import JobMon static object and its consumer collections
import com.socgen.bsc.dpc.jobmon.JobMon
import com.socgen.bsc.dpc.jobmon.consumers.collections._

object Main
{
    def main(args: Array[String]): Unit =
    {
        // Enable collections as needed
        JobMon.enableCollection(SummaryPrinters)
        JobMon.enableCollection(JsonPrinters)
        // Some collections write files, tell them where
        JobMon.setArtifactPrefixPath("path/to/log/folder/")
        
        // Set your spark config as needed
        var conf = new SparkConf()
            .setAppName("RandomSparkApp")
            .setMaster("local[*]")
        // But let JobMon register its listeners
        conf = JobMon.registerListeners(conf)
        
        // BEFORE starting the SparkSession
        implicit val spark: SparkSession = SparkSession
            .builder
            .config(conf)
            .getOrCreate
          
         // Do Spark Stuff !
         // ...
    }
}
```

## Available Collections

TODO

## Make your own consumers

TODO

## Contributions

Repository handled in a git-flow like manner.
Feel free to create PR for collections that would be useful to multiple applications.
Please follow basic git etiquette. 