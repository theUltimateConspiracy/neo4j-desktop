#! /bin/bash

################################################################################################################################################
############################################################## START ###########################################################################
################################################################################################################################################

SECONDS=0
startTime=$(date -R)
echo "Start at $startTime";

################################################################################################################################################
################################################################### FUNCTION ###################################################################
################################################################################################################################################

sed_replace () {
mkdir -p "report/$2-log"
echo > "report/$2-log/$3.txt"

cat $1 |
sed -e "s/\${bo_country}/\${bov_grd_a8479_country}/g" |
sed -e "s/\${bo_currency}/\${bov_grd_a8479_currency}/g" |
sed -e "s/\${bo_legal_and_regulatory_entity_database}/\${bov_sgd_a8520_legal_and_regulatory_entity}/g" |
sed -e "s/\${bo_organizational_unit}/\${bov_grd_a8479_organizational_unit}/g" |
sed -e "s/\${bov_action}/\${bov_dpc_a8420_action}/g" |
sed -e "s/\${bov_businessactivity}/\${bov_raq_a8510_businessactivity}/g" |
sed -e "s/\${bov_businessprocess}/\${bov_raq_a8510_businessprocess}/g" |
sed -e "s/\${bov_controlform}/\${bov_dpc_a8420_controlform_level_two_control}/g" |
sed -e "s/\${boh_controlform}/\${bov_dpc_a8420_controlform_level_two_control}/g" |
sed -e "s/\${bov_controlplan}/\${bov_dpc_a8420_controlplan_level_two_control}/g" |
sed -e "s/\${bov_country}/\${bov_grd_a8479_country}/g" |
sed -e "s/\${bov_internal_control_control_anomaly}/\${bov_dpc_a8420_control_anomaly}/g" |
sed -e "s/\${bov_internal_control_control_result}/\${bov_dpc_a8420_control_result}/g" |
sed -e "s/\${bov_internal_control_control}/\${bov_dpc_a8420_control}/g" |
sed -e "s/\${bov_internal_control_gbis}/\${bov_dpc_a8420_control_result}/g" |
sed -e "s/\${bov_internal_control_remediation_action}/\${bov_dpc_a8420_remediation_action}/g" |
sed -e "s/\${bov_myaprc}/\${bov_dpc_a8420_aprc_referential}/g" |
sed -e "s/\${bov_need_for_action}/\${bov_dpc_a8420_need_for_action}/g" |
sed -e "s/\${bov_operational_risk_risk_event}/\${bov_rol_a8518_risk_event}/g" |
sed -e "s/\${bov_outsourced_services}/\${bov_rol_a8518_outsourced_services}/g" |
sed -e "s/\${bov_remediation_plan}/\${bov_dpc_a8420_remediation_plan}/g" |
sed -e "s/\${bov_review}/\${bov_dpc_a8420_review_level_two_control}/g" |
sed -e "s/\${boh_review}/\${bov_dpc_a8420_review_level_two_control}/g" |
sed -e "s/\${bov_risks_self_controls_assessments}/\${bov_rol_a8518_risks_controls_self_assessments}/g" |
sed -e "s/\${bov_sgriskeventcategory}/\${bov_grd_a8479_sgriskeventcategory}/g" |
sed -e "s/\${lake_aer}/\${lake_aer_a8447}/g" |
sed -e "s/\${lake_cni}/\${lake_cni_134053}/g" |
sed -e "s/\${lake_ctl}/\${lake_ctl_a8441}/g" |
sed -e "s/\${lake_extraction}/\${lake_extraction}/g" |
sed -e "s/\${lake_fpc}/\${lake_fpc_a8460}/g" |
sed -e "s/\${lake_kro}/\${lake_ccp_a2431}/g" |
sed -e "s/\${lake_mok}/\${lake_mok_a2614}/g" |
sed -e "s/\${lake_mse}/\${lake_mse_764}/g" |
sed -e "s/\${lake_psr}/\${lake_psr_a2538}/g" |
sed -e "s/\${lake_rmo}/\${lake_oes_a2997}/g" |
sed -e "s/\${lake_ttr}/\${lake_ttr_6979}/g" |
sed -e "s/\${srv_aer}/\${srv_aer_a8447}/g" |
sed -e "s/\${srv_cni}/\${srv_cni_134053}/g" |
sed -e "s/\${srv_ctl}/\${srv_ctl_a8441}/g" |
sed -e "s/\${srv_dpc}/\${srv_dpc_a8420}/g" |
sed -e "s/\${srv_fpc}/\${srv_fpc_a8460}/g" |
sed -e "s/\${srv_kro}/\${srv_ccp_a2431}/g" |
sed -e "s/\${srv_mok}/\${srv_mok_a2614}/g" |
sed -e "s/\${srv_mse}/\${srv_mse_764}/g" |
sed -e "s/\${srv_mya}/\${srv_mya_a8573}/g" |
sed -e "s/\${srv_psr}/\${srv_psr_a2538}/g" |
sed -e "s/\${srv_rmo}/\${srv_oes_a2997}/g" |
sed -e "s/\${srv_trm}/\${srv_ttr_6979}/g" |
sed -e "s/\${suv_archer_ramos}/\${suv_rol_a8518_outsourced_services_reports}/g" |
sed -e "s/\${suv_blueprint_framework}/\${suv_dpc_a8420_blueprint_framework}/g" |
sed -e "s/\${suv_control_quality_l1c}/\${suv_dpc_a8420_control_quality_lvl_one_ctrl}/g" |
sed -e "s/\${suv_econtrol}/\${suv_dpc_a8420_econtrol}/g" |
sed -e "s/\${suv_full_outsource_service}/\${suv_rol_a8518_full_outsource_service}/g" |
sed -e "s/\${suv_ic_rop_referential}/\${suv_dpc_a8420_ic_rop_referential}/g" |
sed -e "s/\${suv_internal_control_gbis}/\${uv_dpc_a8420_internal_control_gbis}/g" |
sed -e "s/\${suv_level_one_control_amer}/\${uv_dpc_a8420_level_one_control_amer}/g" |
sed -e "s/\${suv_level_one_control_asia}/\${uv_dpc_a8420_level_one_control_asia}/g" |
sed -e "s/\${suv_level_two_control}/\${suv_dpc_a8420_level_two_control}/g" |
sed -e "s/\${suv_my_action}/\${suv_rol_a8518_risk_event_all_perimeters}/g" |
sed -e "s/\${suv_organizational_unit}/\${suv_grd_a8479_organizational_unit}/g" |
sed -e "s/\${suv_pyramid_businessactivity_businessprocess}/\${suv_raq_a8510_pyramidbusinessactivitybusinessprocess}/g" |
sed -e "s/\${suv_risk_event_all_perimeters}/\${suv_rol_a8518_risk_event_all_perimeters}/g" |
sed -e "s/\${suv_risks_self_controls_assessments_dashboard}/\${suv_rol_a8518_risks_controls_self_assessments_dsb}/g" |
sed -e "s/\${suv_workforce_unit}/\${suv_grd_a8479_workforce_unit}/g" |
sed -e "s/\${hdfs_srv_mse}/\${hdfs_srv_mse_764}/g" |
sed -e "s/\${hdfs_srv_psr}/\${hdfs_srv_psr_a2538}/g" |
sed -e "s/\${hdfs_srv_fpc}/\${hdfs_srv_fpc_a8460}/g" |
sed -e "s/\${hdfs_srv_ctl}/\${hdfs_srv_ctl_a8441}/g" |
sed -e "s/\${hdfs_srv_mok}/\${hdfs_srv_mok_a2614}/g" |
sed -e "s/\${hdfs_srv_kro}/\${hdfs_srv_ccp_a2431}/g" |
sed -e "s/\${hdfs_srv_dpc}/\${hdfs_srv_dpc_a8420}/g" |
sed -e "s/\${hdfs_bov_internal_control_control_result}/\${hdfs_bov_dpc_a8420_control_result}/g" |
sed -e "s/\${hdfs_bov_internal_control_control}/\${hdfs_bov_dpc_a8420_control}/g" |
sed -e "s/\${hdfs_bov_internal_control_control_anomaly}/\${hdfs_bov_dpc_a8420_control_anomaly}/g" |
sed -e "s/\${hdfs_bov_internal_control_remediation_action}/\${hdfs_bov_dpc_a8420_remediation_action}/g" |
sed -e "s/\${hdfs_bov_remediation_plan}/\${hdfs_bov_dpc_a8420_remediation_plan}/g" |
sed -e "s/\${hdfs_bov_controlplan}/\${hdfs_bov_dpc_a8420_controlplan_level_two_control}/g" |
sed -e "s/\${hdfs_bov_review}/\${hdfs_bov_dpc_a8420_review_level_two_control}/g" |
sed -e "s/\${hdfs_bov_myaprc}/\${hdfs_bov_dpc_a8420_aprc_referential}/g" |
sed -e "s/\${hdfs_bov_controlform}/\${hdfs_bov_dpc_a8420_controlform_level_two_control}/g" |
sed -e "s/\${hdfs_bov_need_for_action}/\${hdfs_bov_dpc_a8420_need_for_action}/g" |
sed -e "s/\${hdfs_bov_action}/\${hdfs_bov_dpc_a8420_action}/g" |
sed -e "s/\${hdfs_suv_econtrol}/\${hdfs_suv_dpc_a8420_econtrol}/g" |
sed -e "s/\${hdfs_suv_level_two_control}/\${hdfs_suv_dpc_a8420_level_two_control}/g" |
sed -e "s/\${hdfs_suv_blueprint_framework}/\${hdfs_suv_dpc_a8420_blueprint_framework}/g" |
sed -e "s/\${hdfs_suv_control_quality_l1c}/\${hdfs_suv_dpc_a8420_control_quality_lvl_one_ctrl}/g" |
sed -e "s/\${hdfs_suv_my_action}/\${hdfs_suv_dpc_a8420_action_need}/g" |
sed -e "s/\${hdfs_uv_internal_control_gbis}/\${hdfs_uv_dpc_a8420_internal_control_gbis}/g" |
sed -e "s/\${hdfs_uv_level_one_control_amer}/\${hdfs_uv_dpc_a8420_level_one_control_amer}/g" |
sed -e "s/\${hdfs_uv_level_one_control_asia}/\${hdfs_uv_dpc_a8420_level_one_control_asia}/g" |
sed -e "s/\/config\//\//g" |
sed -e "s/libsPath=noeval{deployPath}\/libs/libsPath=noeval{basePath}\/libs/g" |
sed -e "s/applicationLogFilePath=noeval{deployPath}\/log\/noeval{applicationLogFile}/applicationLogFilePath=noeval{basePath}\/log\/noeval{applicationLogFile}/g" |
sed -e "s/jaasConfFilePath=noeval{deployPath}\/kafka\/noeval{jaasConfigFile}/jaasConfFilePath=noeval{basePath}\/kafka\/noeval{jaasConfigFile}/g" |
sed -e "s/\/uv\/internal_control\//\/uv\/internal_control_gbis\//g" |
sed -e "s/\/export\/myaprc\//\/export\/suv\/blueprint_framework\//g" |
sed -e "s/\/versioning\/econtrol_cn2\//\/versioning\/suv\/level_two_control\//g" |
sed -e "s/\/versioning\/blueprint_framework\//\/versioning\/suv\/blueprint_framework\//g" |
sed -e "s/\/versioning\/load_archives\/blueprint_framework\//\/versioning\/load_archives\/suv\/blueprint_framework\//g" |
sed -e "s/\/versioning\/bov_control\//\/versioning\/bov\/control\//g" |
sed -e "s/\/versioning\/bov_controlanomaly\//\/versioning\/bov\/control_anomaly\//g" |
sed -e "s/\/versioning\/bov_controlform\//\/versioning\/bov\/controlform_level_two_control\//g" |
sed -e "s/\/versioning\/bov_controlplan\//\/versioning\/bov\/controlplan_level_two_control\//g" |
sed -e "s/\/versioning\/bov_controlresult\//\/versioning\/bov\/control_result\//g" |
sed -e "s/\/versioning\/bov_review\//\/versioning\/bov\/review_level_two_control\//g" |
sed -e "s/\/full_ingestion\/myaprc\//\/full_ingestion\/aprc_referential\//g" |
sed -e "s/\/bov\/review\//\/bov\/review_level_two_control\//g" |
sed -e "s/\/bov\/remediationplan\//\/bov\/remediation_plan\//g" |
sed -e "s/\/bov\/remediationaction\//\/bov\/remediation_action\//g" |
sed -e "s/\/bov\/needforaction\//\/bov\/need_for_action\//g" |
sed -e "s/\/bov\/controlplan\//\/bov\/controlplan_level_two_control\//g" |
sed -e "s/\/bov\/controlform\//\/bov\/controlform_level_two_control\//g" |
sed -e "s/\/bov\/controlresult\//\/bov\/control_result\//g" |
sed -e "s/\/bov\/controlanomaly\//\/bov\/control_anomaly\//g" |
sed -e "s/\/bov\/myaprc\//\/bov\/aprc_referential\//g" |
sed -e "s/\/bov\/myrcsa\//\/bov\/risks_controls_self_assessments\//g" |
sed -e "s/\/bov\/riskevent\//\/bov\/risk_event\//g" |
sed -e "s/\/bov\/outsourced_service\//\/bov\/outsourced_services\//g" |
sed -e "s/\/dataflow\/uv\/econtrol_cn2\//\/dataflow\/suv\/level_two_control\//g" |
sed -e "s/\/uv\/econtrol_cn2\//\/suv\/level_two_control\//g" |
sed -e "s/\/uv\/econtrol_cn2\//\/suv\/level_two_control\//g" |
sed -e "s/\/dataflow\/uv\/econtrol\//\/dataflow\/suv\/econtrol\//g" |
sed -e "s/\/uv\/econtrol\//\/suv\/econtrol\//g" |
sed -e "s/\/uv\/econtrol\//\/suv\/econtrol\//g" |
sed -e "s/\/uv\/control_quality_l1c\//\/suv\/control_quality_lvl_one_ctrl\//g" |
sed -e "s/\/uv\/blueprint_framework\//\/suv\/blueprint_framework\//g" |
sed -e "s/\/uv\/my_action\//\/suv\/action_need\//g" |
sed -e "s/\/uv\/econtrol_cn2\//\/suv\/level_two_control\//g" |
sed -e "s/\/uv\/econtrol\//\/suv\/econtrol\//g" |
sed -e "s/\/uv\/control_quality_l1c\//\/suv\/control_quality_lvl_one_ctrl\//g" |
sed -e "s/\/uv\/dataquality\//\/suv\/dataquality\//g" |
sed -e "s/\/uv\/full_outsource_service\//\/suv\/full_outsource_service\//g" |
sed -e "s/\/uv\/myrcsa\//\/suv\/risks_controls_self_assessments_dsb\//g" |
sed -e "s/\/uv\/outsourced_service\//\/suv\/outsourced_services_reports\//g" |
sed -e "s/\/uv\/referential\//\/suv\/ic_rop_referential\//g" |
sed -e "s/\/uv\/risk_event_all_perimeters\//\/suv\/risk_event_all_perimeters\//g" |
sed -e "s/\/uv\/myrcsa\//\/suv\/risks_controls_self_assessments_dsb\//g" |
sed -e "s/\/uv\/full_outsource_service\//\/suv\/full_outsource_service\//g" |
sed -e "s/\/a7777\/mrs\//\/764\/mse\//g" |
sed -e "s/\/a2431\/action\//\/a2431\/ccp\//g" |
sed -e "s/\/a2538\/gps\//\/a2538\/psr\//g" |
sed -e "s/\/a2614\/moka\//\/a2614\/mok\//g" |
sed -e "s/\/a2431\/loss\//\/a2431\/ccp\//g" |
sed -e "s/\/dataquality\/a2431\/loss\//\/dataquality\/6979\/ccp\//g" |
sed -e "s/\/a2927\/rmo\//\/a2997\/oes\//g" |
sed -e "s/\/a6979\/trm\//\/6979\/ttr\//g" |
sed -e "s/\/dataquality\/a6979\/trm\//\/dataquality\/6979\/ttr\//g" > $1-sed
rm $1
mv $1-sed $1

unix2dos $1;

# Redirect stdout/stderr to a file
exec >"report/$2-log/$3.txt" 2>&1

# VARIABLES
echo "THREAD: $2 ; FILE : $1; ACTION : \${bo_country}/\${bov_grd_a8479_country}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${bo_currency}/\${bov_grd_a8479_currency}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${bo_legal_and_regulatory_entity_database}/\${bov_sgd_a8520_legal_and_regulatory_entity}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${bo_organizational_unit}/\${bov_grd_a8479_organizational_unit}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${bov_action}/\${bov_dpc_a8420_action}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${bov_businessactivity}/\${bov_raq_a8510_businessactivity}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${bov_businessprocess}/\${bov_raq_a8510_businessprocess}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${bov_controlform}/\${bov_dpc_a8420_controlform_level_two_control}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${bov_controlplan}/\${bov_dpc_a8420_controlplan_level_two_control}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${bov_country}/\${bov_grd_a8479_country}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${bov_internal_control_control_anomaly}/\${bov_dpc_a8420_control_anomaly}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${bov_internal_control_control_result}/\${bov_dpc_a8420_control_result}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${bov_internal_control_control}/\${bov_dpc_a8420_control}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${bov_internal_control_gbis}/\${bov_dpc_a8420_control_result}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${bov_internal_control_remediation_action}/\${bov_dpc_a8420_remediation_action}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${bov_myaprc}/\${bov_dpc_a8420_aprc_referential}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${bov_need_for_action}/\${bov_dpc_a8420_need_for_action}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${bov_operational_risk_risk_event}/\${bov_rol_a8518_risk_event}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${bov_outsourced_services}/\${bov_rol_a8518_outsourced_services}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${bov_remediation_plan}/\${bov_dpc_a8420_remediation_plan}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${bov_review}/\${bov_dpc_a8420_review_level_two_control}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${bov_risks_self_controls_assessments}/\${bov_rol_a8518_risks_controls_self_assessments}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${bov_sgriskeventcategory}/\${bov_grd_a8479_sgriskeventcategory}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${lake_aer}/\${lake_aer_a8447}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${lake_cni}/\${lake_cni_134053}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${lake_ctl}/\${lake_ctl_a8441}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${lake_extraction}/\${lake_extraction}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${lake_fpc}/\${lake_fpc_a8460}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${lake_kro}/\${lake_ccp_a2431}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${lake_mok}/\${lake_mok_a2614}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${lake_mse}/\${lake_mse_764}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${lake_psr}/\${lake_psr_a2538}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${lake_rmo}/\${lake_oes_a2997}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${lake_ttr}/\${lake_ttr_6979}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${srv_aer}/\${srv_aer_a8447}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${srv_cni}/\${srv_cni_134053}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${srv_ctl}/\${srv_ctl_a8441}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${srv_dpc}/\${srv_dpc_a8420}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${srv_fpc}/\${srv_fpc_a8460}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${srv_kro}/\${srv_ccp_a2431}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${srv_mok}/\${srv_mok_a2614}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${srv_mse}/\${srv_mse_764}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${srv_mya}/\${srv_mya_a8573}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${srv_psr}/\${srv_psr_a2538}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${srv_rmo}/\${srv_oes_a2997}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${srv_trm}/\${srv_ttr_6979}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${suv_archer_ramos}/\${suv_rol_a8518_outsourced_services_reports}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${suv_blueprint_framework}/\${suv_dpc_a8420_blueprint_framework}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${suv_control_quality_l1c}/\${suv_dpc_a8420_control_quality_lvl_one_ctrl}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${suv_econtrol}/\${suv_dpc_a8420_econtrol}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${suv_full_outsource_service}/\${suv_rol_a8518_full_outsource_service}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${suv_ic_rop_referential}/\${suv_dpc_a8420_ic_rop_referential}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${suv_internal_control_gbis}/\${uv_dpc_a8420_internal_control_gbis}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${suv_level_one_control_amer}/\${uv_dpc_a8420_level_one_control_amer}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${suv_level_one_control_asia}/\${uv_dpc_a8420_level_one_control_asia}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${suv_level_two_control}/\${suv_dpc_a8420_level_two_control}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${suv_my_action}/\${suv_rol_a8518_risk_event_all_perimeters}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${suv_organizational_unit}/\${suv_grd_a8479_organizational_unit}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${suv_pyramid_businessactivity_businessprocess}/\${suv_raq_a8510_pyramidbusinessactivitybusinessprocess}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${suv_risk_event_all_perimeters}/\${suv_rol_a8518_risk_event_all_perimeters}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${suv_risks_self_controls_assessments_dashboard}/\${suv_rol_a8518_risks_controls_self_assessments_dsb}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${suv_workforce_unit}/\${suv_grd_a8479_workforce_unit}";
echo "THREAD: $2 ; FILE : $1; ACTION : \${hdfs_srv_mse}/\${hdfs_srv_mse_764}/g" ;
echo "THREAD: $2 ; FILE : $1; ACTION : \${hdfs_srv_psr}/\${hdfs_srv_psr_a2538}/g" ;
echo "THREAD: $2 ; FILE : $1; ACTION : \${hdfs_srv_fpc}/\${hdfs_srv_fpc_a8460}/g" ;
echo "THREAD: $2 ; FILE : $1; ACTION : \${hdfs_srv_ctl}/\${hdfs_srv_ctl_a8441}/g" ;
echo "THREAD: $2 ; FILE : $1; ACTION : \${hdfs_srv_mok}/\${hdfs_srv_mok_a2614}/g" ;
echo "THREAD: $2 ; FILE : $1; ACTION : \${hdfs_srv_kro}/\${hdfs_srv_ccp_a2431}/g" ;
echo "THREAD: $2 ; FILE : $1; ACTION : \${hdfs_srv_dpc}/\${hdfs_srv_dpc_a8420}/g" ;
echo "THREAD: $2 ; FILE : $1; ACTION : \${hdfs_bov_internal_control_control_result}/\${hdfs_bov_dpc_a8420_control_result}/g" ;
echo "THREAD: $2 ; FILE : $1; ACTION : \${hdfs_bov_internal_control_control}/\${hdfs_bov_dpc_a8420_control}/g" ;
echo "THREAD: $2 ; FILE : $1; ACTION : \${hdfs_bov_internal_control_control_anomaly}/\${hdfs_bov_dpc_a8420_control_anomaly}/g" ;
echo "THREAD: $2 ; FILE : $1; ACTION : \${hdfs_bov_internal_control_remediation_action}/\${hdfs_bov_dpc_a8420_remediation_action}/g" ;
echo "THREAD: $2 ; FILE : $1; ACTION : \${hdfs_bov_remediation_plan}/\${hdfs_bov_dpc_a8420_remediation_plan}/g" ;
echo "THREAD: $2 ; FILE : $1; ACTION : \${hdfs_bov_controlplan}/\${hdfs_bov_dpc_a8420_controlplan_level_two_control}/g" ;
echo "THREAD: $2 ; FILE : $1; ACTION : \${hdfs_bov_review}/\${hdfs_bov_dpc_a8420_review_level_two_control}/g" ;
echo "THREAD: $2 ; FILE : $1; ACTION : \${hdfs_bov_myaprc}/\${hdfs_bov_dpc_a8420_aprc_referential}/g" ;
echo "THREAD: $2 ; FILE : $1; ACTION : \${hdfs_bov_controlform}/\${hdfs_bov_dpc_a8420_controlform_level_two_control}/g" ;
echo "THREAD: $2 ; FILE : $1; ACTION : \${hdfs_bov_need_for_action}/\${hdfs_bov_dpc_a8420_need_for_action}/g" ;
echo "THREAD: $2 ; FILE : $1; ACTION : \${hdfs_bov_action}/\${hdfs_bov_dpc_a8420_action}/g" ;
echo "THREAD: $2 ; FILE : $1; ACTION : \${hdfs_suv_econtrol}/\${hdfs_suv_dpc_a8420_econtrol}/g" ;
echo "THREAD: $2 ; FILE : $1; ACTION : \${hdfs_suv_level_two_control}/\${hdfs_suv_dpc_a8420_level_two_control}/g" ;
echo "THREAD: $2 ; FILE : $1; ACTION : \${hdfs_suv_blueprint_framework}/\${hdfs_suv_dpc_a8420_blueprint_framework}/g" ;
echo "THREAD: $2 ; FILE : $1; ACTION : \${hdfs_suv_control_quality_l1c}/\${hdfs_suv_dpc_a8420_control_quality_lvl_one_ctrl}/g" ;
echo "THREAD: $2 ; FILE : $1; ACTION : \${hdfs_suv_my_action}/\${hdfs_suv_dpc_a8420_action_need}/g" ;
echo "THREAD: $2 ; FILE : $1; ACTION : \${hdfs_uv_internal_control_gbis}/\${hdfs_uv_dpc_a8420_internal_control_gbis}/g" ;
echo "THREAD: $2 ; FILE : $1; ACTION : \${hdfs_uv_level_one_control_amer}/\${hdfs_uv_dpc_a8420_level_one_control_amer}/g" ;
echo "THREAD: $2 ; FILE : $1; ACTION : \${hdfs_uv_level_one_control_asia}/\${hdfs_uv_dpc_a8420_level_one_control_asia}/g" ;

#COMMON PATHS

echo "THREAD: $2 ; FILE : $1; ACTION : \/config\//\//g" ;
echo "THREAD: $2 ; FILE : $1; ACTION : s/libsPath=noeval{deployPath}\/libs/libsPath=noeval{basePath}\/libs";
echo "THREAD: $2 ; FILE : $1; ACTION : s/applicationLogFilePath=noeval{deployPath}\/log\/noeval{applicationLogFile}/applicationLogFilePath=noeval{basePath}\/log\/noeval{applicationLogFile}";
echo "THREAD: $2 ; FILE : $1; ACTION : s/jaasConfFilePath=noeval{deployPath}\/kafka\/noeval{jaasConfigFile}/jaasConfFilePath=noeval{basePath}\/kafka\/noeval{jaasConfigFile}";

# UV
echo "THREAD: $2 ; FILE : $1; ACTION : \/uv\/internal_control\//\/uv\/internal_control_gbis\/";

#EXPORT
echo "THREAD: $2 ; FILE : $1; ACTION : \/export\/myaprc\//\/export\/suv\/blueprint_framework\/";

# VERSIONING
echo "THREAD: $2 ; FILE : $1; ACTION : \/versioning\/econtrol_cn2\//\/versioning\/suv\/level_two_control\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/versioning\/blueprint_framework\//\/versioning\/suv\/blueprint_framework\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/versioning\/load_archives\/blueprint_framework\//\/versioning\/load_archives\/suv\/blueprint_framework\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/versioning\/bov_control\//\/versioning\/bov\/control\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/versioning\/bov_controlanomaly\//\/versioning\/bov\/control_anomaly\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/versioning\/bov_controlform\//\/versioning\/bov\/controlform_level_two_control\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/versioning\/bov_controlplan\//\/versioning\/bov\/controlplan_level_two_control\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/versioning\/bov_controlresult\//\/versioning\/bov\/control_result\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/versioning\/bov_review\//\/versioning\/bov\/review_level_two_control\/";

# FULL
echo "THREAD: $2 ; FILE : $1; ACTION : \/full_ingestion\/myaprc\//\/full_ingestion\/aprc_referential\/";

#BOV
echo "THREAD: $2 ; FILE : $1; ACTION : \/bov\/review\//\/bov\/review_level_two_control\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/bov\/remediationplan\//\/bov\/remediation_plan\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/bov\/remediationaction\//\/bov\/remediation_action\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/bov\/needforaction\//\/bov\/need_for_action\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/bov\/controlplan\//\/bov\/controlplan_level_two_control\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/bov\/controlform\//\/bov\/controlform_level_two_control\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/bov\/controlresult\//\/bov\/control_result\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/bov\/controlanomaly\//\/bov\/control_anomaly\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/bov\/myaprc\//\/bov\/aprc_referential\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/bov\/myrcsa\//\/bov\/risks_controls_self_assessments\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/bov\/riskevent\//\/bov\/risk_event\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/bov\/outsourced_service\//\/bov\/outsourced_services\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/dataflow\/uv\/econtrol_cn2\//\/dataflow\/suv\/level_two_control\/";
# UV
echo "THREAD: $2 ; FILE : $1; ACTION : \/uv\/econtrol_cn2\//\/suv\/level_two_control\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/uv\/econtrol_cn2\//\/suv\/level_two_control\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/dataflow\/uv\/econtrol\//\/dataflow\/suv\/econtrol\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/uv\/econtrol\//\/suv\/econtrol\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/uv\/econtrol\//\/suv\/econtrol\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/uv\/control_quality_l1c\//\/suv\/control_quality_lvl_one_ctrl\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/uv\/blueprint_framework\//\/suv\/blueprint_framework\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/uv\/my_action\//\/suv\/action_need\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/uv\/econtrol_cn2\//\/suv\/level_two_control\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/uv\/econtrol\//\/suv\/econtrol\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/uv\/control_quality_l1c\//\/suv\/control_quality_lvl_one_ctrl\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/uv\/dataquality\//\/suv\/dataquality\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/uv\/full_outsource_service\//\/suv\/full_outsource_service\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/uv\/myrcsa\//\/suv\/risks_controls_self_assessments_dsb\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/uv\/outsourced_service\//\/suv\/outsourced_services_reports\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/uv\/referential\//\/suv\/ic_rop_referential\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/uv\/risk_event_all_perimeters\//\/suv\/risk_event_all_perimeters\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/uv\/myrcsa\//\/suv\/risks_controls_self_assessments_dsb\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/uv\/full_outsource_service\//\/suv\/full_outsource_service\/";
#SRV
echo "THREAD: $2 ; FILE : $1; ACTION : \/a7777\/mrs\//\/764\/mse\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/a2431\/action\//\/a2431\/ccp\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/a2538\/gps\//\/a2538\/psr\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/a2614\/moka\//\/a2614\/mok\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/a2431\/loss\//\/a2431\/ccp\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/dataquality\/a2431\/loss\//\/dataquality\/6979\/ccp\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/a2927\/rmo\//\/a2997\/oes\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/a6979\/trm\//\/6979\/ttr\/";
echo "THREAD: $2 ; FILE : $1; ACTION : \/dataquality\/a6979\/trm\//\/dataquality\/6979\/ttr\/";

}

################################################################################################################################################
#################################################### REMOVE UNWANTED FILES #####################################################################
################################################################################################################################################

#./bdh_to_lucid.sh master

cd DPC/config; git stash; git checkout $1; git pull;
cd ../..;
rm -rf ./TEMP 2> /dev/null;
rm -rf ./LUCID 2> /dev/null;
rm -rf ./report 2> /dev/null;
mkdir -p ./TEMP/DPC/;
cp -r DPC/config ./TEMP/DPC/;

rm -rf ./TEMP/DPC/config/shell 2> /dev/null
rm -rf ./TEMP/DPC/config/kafka 2> /dev/null
rm -rf ./TEMP/DPC/config/log 2> /dev/null
find ./TEMP/DPC/config/* -regex './TEMP/DPC/config/dataflow/.*/config.properties' -delete
find ./TEMP/DPC/config/* -regex './TEMP/DPC/config/.*/sed.*$' -delete

################################################################################################################################################
########################################################    MOVE REPO   ########################################################################
################################################################################################################################################

#CREATE NEEDED DIRECTORIES

mkdir -p TEMP/DPC/config/dataflow/srv/764/;
mkdir -p TEMP/DPC/config/bov/;
mkdir -p TEMP/DPC/config/dataflow/bov/;
mkdir -p TEMP/DPC/config/dataflow/srv/6979/;
mkdir -p TEMP/DPC/config/dataflow/srv/a2431/;
mkdir -p TEMP/DPC/config/dataflow/srv/a2538/;
mkdir -p TEMP/DPC/config/dataflow/srv/a2614/;
mkdir -p TEMP/DPC/config/dataflow/srv/a2997/;
mkdir -p TEMP/DPC/config/dataflow/srv/dataquality/;
mkdir -p TEMP/DPC/config/dataflow/suv/;
mkdir -p TEMP/DPC/config/dataflow/uv/;
mkdir -p TEMP/DPC/config/dataflow/versioning/bov/;
mkdir -p TEMP/DPC/config/dataflow/versioning/suv/;
mkdir -p TEMP/DPC/config/export/suv/;
mkdir -p TEMP/DPC/config/export/versioning/suv/;
mkdir -p TEMP/DPC/config/srv/6979/;
mkdir -p TEMP/DPC/config/srv/764/;
mkdir -p TEMP/DPC/config/srv/a2431/;
mkdir -p TEMP/DPC/config/srv/a2538/;
mkdir -p TEMP/DPC/config/srv/a2614/;
mkdir -p TEMP/DPC/config/srv/a2997/;
mkdir -p TEMP/DPC/config/srv/dataquality/;
mkdir -p TEMP/DPC/config/suv/;
mkdir -p TEMP/DPC/config/uv/;
mkdir -p TEMP/DPC/config/versioning/bov/;
mkdir -p TEMP/DPC/config/versioning/suv/;

#printf "MOVE TEMP/DPC/config/dataflow/srv/a7777/mrs TEMP/DPC/config/dataflow/srv/764/mse\r";
mv -v TEMP/DPC/config/dataflow/srv/a7777/mrs TEMP/DPC/config/dataflow/srv/764/mse;
#printf "MOVE TEMP/DPC/config/srv/a7777/mrs TEMP/DPC/config/srv/764/mse\r";
mv -v TEMP/DPC/config/srv/a7777/mrs TEMP/DPC/config/srv/764/mse;
#printf "MOVE TEMP/DPC/config/dataflow/srv/a2431/action TEMP/DPC/config/dataflow/srv/a2431/ccp\r";
mv -v TEMP/DPC/config/dataflow/srv/a2431/action TEMP/DPC/config/dataflow/srv/a2431/ccp;
#printf "MOVE TEMP/DPC/config/srv/a2431/action TEMP/DPC/config/srv/a2431/ccp\r";
mv -v TEMP/DPC/config/srv/a2431/action TEMP/DPC/config/srv/a2431/ccp;
#printf "MOVE TEMP/DPC/config/dataflow/srv/a2538/gps TEMP/DPC/config/dataflow/srv/a2538/psr\r";
mv -v TEMP/DPC/config/dataflow/srv/a2538/gps TEMP/DPC/config/dataflow/srv/a2538/psr;
#printf "MOVE TEMP/DPC/config/srv/a2538/gps TEMP/DPC/config/srv/a2538/psr\r";
mv -v TEMP/DPC/config/srv/a2538/gps TEMP/DPC/config/srv/a2538/psr;
#printf "MOVE TEMP/DPC/config/dataflow/srv/a2614/moka TEMP/DPC/config/dataflow/srv/a2614/mok\r";
mv -v TEMP/DPC/config/dataflow/srv/a2614/moka TEMP/DPC/config/dataflow/srv/a2614/mok;
#printf "MOVE TEMP/DPC/config/srv/a2614/moka TEMP/DPC/config/srv/a2614/mok\r";
mv -v TEMP/DPC/config/srv/a2614/moka TEMP/DPC/config/srv/a2614/mok;
#printf "MOVE TEMP/DPC/config/dataflow/uv/econtrol_cn2 TEMP/DPC/config/dataflow/suv/level_two_control\r";
mv -v TEMP/DPC/config/dataflow/uv/econtrol_cn2 TEMP/DPC/config/dataflow/suv/level_two_control;
#printf "MOVE TEMP/DPC/config/uv/econtrol_cn2 TEMP/DPC/config/suv/level_two_control\r";
mv -v TEMP/DPC/config/uv/econtrol_cn2 TEMP/DPC/config/suv/level_two_control;
#printf "MOVE TEMP/DPC/config/dataflow/uv/econtrol TEMP/DPC/config/dataflow/suv/econtrol\r";
mv -v TEMP/DPC/config/dataflow/uv/econtrol TEMP/DPC/config/dataflow/suv/econtrol;
#printf "MOVE TEMP/DPC/config/uv/econtrol TEMP/DPC/config/suv/econtrol\r";
mv -v TEMP/DPC/config/uv/econtrol TEMP/DPC/config/suv/econtrol;
#printf "MOVE TEMP/DPC/config/dataflow/uv/control_quality_l1c TEMP/DPC/config/dataflow/suv/control_quality_lvl_one_ctrl\r";
mv -v TEMP/DPC/config/dataflow/uv/control_quality_l1c TEMP/DPC/config/dataflow/suv/control_quality_lvl_one_ctrl;
#printf "MOVE TEMP/DPC/config/uv/control_quality_l1c TEMP/DPC/config/suv/control_quality_lvl_one_ctrl\r";
mv -v TEMP/DPC/config/uv/control_quality_l1c TEMP/DPC/config/suv/control_quality_lvl_one_ctrl;
#printf "MOVE TEMP/DPC/config/dataflow/uv/blueprint_framework TEMP/DPC/config/dataflow/suv/blueprint_framework\r";
mv -v TEMP/DPC/config/dataflow/uv/blueprint_framework TEMP/DPC/config/dataflow/suv/blueprint_framework;
#printf "MOVE TEMP/DPC/config/uv/blueprint_framework TEMP/DPC/config/suv/blueprint_framework\r";
mv -v TEMP/DPC/config/uv/blueprint_framework TEMP/DPC/config/suv/blueprint_framework;
#printf "MOVE TEMP/DPC/config/dataflow/uv/my_action TEMP/DPC/config/dataflow/suv/action_need\r";
mv -v TEMP/DPC/config/dataflow/uv/my_action TEMP/DPC/config/dataflow/suv/action_need;
#printf "MOVE TEMP/DPC/config/uv/my_action TEMP/DPC/config/suv/action_need\r";
mv -v TEMP/DPC/config/uv/my_action TEMP/DPC/config/suv/action_need;
#printf "MOVE TEMP/DPC/config/dataflow/bov/review TEMP/DPC/config/dataflow/bov/review_level_two_control\r";
mv -v TEMP/DPC/config/dataflow/bov/review TEMP/DPC/config/dataflow/bov/review_level_two_control;
#printf "MOVE TEMP/DPC/config/bov/review TEMP/DPC/config/bov/review_level_two_control\r";
mv -v TEMP/DPC/config/bov/review TEMP/DPC/config/bov/review_level_two_control;
#printf "MOVE TEMP/DPC/config/dataflow/bov/remediationplan TEMP/DPC/config/dataflow/bov/remediation_plan\r";
mv -v TEMP/DPC/config/dataflow/bov/remediationplan TEMP/DPC/config/dataflow/bov/remediation_plan;
#printf "MOVE TEMP/DPC/config/bov/remediationplan TEMP/DPC/config/bov/remediation_plan\r";
mv -v TEMP/DPC/config/bov/remediationplan TEMP/DPC/config/bov/remediation_plan;
#printf "MOVE TEMP/DPC/config/dataflow/bov/remediationaction TEMP/DPC/config/dataflow/bov/remediation_action\r";
mv -v TEMP/DPC/config/dataflow/bov/remediationaction TEMP/DPC/config/dataflow/bov/remediation_action;
#printf "MOVE TEMP/DPC/config/bov/remediationaction TEMP/DPC/config/bov/remediation_action\r";
mv -v TEMP/DPC/config/bov/remediationaction TEMP/DPC/config/bov/remediation_action;
#printf "MOVE TEMP/DPC/config/dataflow/bov/needforaction TEMP/DPC/config/dataflow/bov/need_for_action\r";
mv -v TEMP/DPC/config/dataflow/bov/needforaction TEMP/DPC/config/dataflow/bov/need_for_action;
#printf "MOVE TEMP/DPC/config/bov/needforaction TEMP/DPC/config/bov/need_for_action\r";
mv -v TEMP/DPC/config/bov/needforaction TEMP/DPC/config/bov/need_for_action;
#printf "MOVE TEMP/DPC/config/dataflow/bov/controlplan TEMP/DPC/config/dataflow/bov/controlplan_level_two_control\r";
mv -v TEMP/DPC/config/dataflow/bov/controlplan TEMP/DPC/config/dataflow/bov/controlplan_level_two_control;
#printf "MOVE TEMP/DPC/config/bov/controlplan TEMP/DPC/config/bov/controlplan_level_two_control\r";
mv -v TEMP/DPC/config/bov/controlplan TEMP/DPC/config/bov/controlplan_level_two_control;
#printf "MOVE TEMP/DPC/config/dataflow/bov/controlform TEMP/DPC/config/dataflow/bov/controlform_level_two_control\r";
mv -v TEMP/DPC/config/dataflow/bov/controlform TEMP/DPC/config/dataflow/bov/controlform_level_two_control;
#printf "MOVE TEMP/DPC/config/bov/controlform TEMP/DPC/config/bov/controlform_level_two_control\r";
mv -v TEMP/DPC/config/bov/controlform TEMP/DPC/config/bov/controlform_level_two_control;
#printf "MOVE TEMP/DPC/config/dataflow/bov/controlresult TEMP/DPC/config/dataflow/bov/control_result\r";
mv -v TEMP/DPC/config/dataflow/bov/controlresult TEMP/DPC/config/dataflow/bov/control_result;
#printf "MOVE TEMP/DPC/config/bov/controlresult TEMP/DPC/config/bov/control_result\r";
mv -v TEMP/DPC/config/bov/controlresult TEMP/DPC/config/bov/control_result;
#printf "MOVE TEMP/DPC/config/dataflow/bov/controlanomaly TEMP/DPC/config/dataflow/bov/control_anomaly\r";
mv -v TEMP/DPC/config/dataflow/bov/controlanomaly TEMP/DPC/config/dataflow/bov/control_anomaly;
#printf "MOVE TEMP/DPC/config/bov/controlanomaly TEMP/DPC/config/bov/control_anomaly\r";
mv -v TEMP/DPC/config/bov/controlanomaly TEMP/DPC/config/bov/control_anomaly;
#printf "MOVE TEMP/DPC/config/dataflow/bov/myaprc TEMP/DPC/config/dataflow/bov/aprc_referential\r";
mv -v TEMP/DPC/config/dataflow/bov/myaprc TEMP/DPC/config/dataflow/bov/aprc_referential;
#printf "MOVE TEMP/DPC/config/bov/myaprc TEMP/DPC/config/bov/aprc_referential\r";
mv -v TEMP/DPC/config/bov/myaprc TEMP/DPC/config/bov/aprc_referential;
#printf "MOVE TEMP/DPC/config/dataflow/uv/internal_control TEMP/DPC/config/dataflow/uv/internal_control_gbis\r";
mv -v TEMP/DPC/config/dataflow/uv/internal_control TEMP/DPC/config/dataflow/uv/internal_control_gbis;
#printf "MOVE TEMP/DPC/config/uv/internal_control TEMP/DPC/config/uv/internal_control_gbis\r";
mv -v TEMP/DPC/config/uv/internal_control TEMP/DPC/config/uv/internal_control_gbis;
#printf "MOVE TEMP/DPC/config/export/uv/econtrol_cn2 TEMP/DPC/config/export/suv/level_two_control\r";
mv -v TEMP/DPC/config/export/uv/econtrol_cn2 TEMP/DPC/config/export/suv/level_two_control;
#printf "MOVE TEMP/DPC/config/export/versioning/econtrol_cn2 TEMP/DPC/config/export/versioning/suv/level_two_control\r";
mv -v TEMP/DPC/config/export/versioning/econtrol_cn2 TEMP/DPC/config/export/versioning/suv/level_two_control;
#printf "MOVE TEMP/DPC/config/versioning/econtrol_cn2 TEMP/DPC/config/versioning/suv/level_two_control\r";
mv -v TEMP/DPC/config/versioning/econtrol_cn2 TEMP/DPC/config/versioning/suv/level_two_control;
#printf "MOVE TEMP/DPC/config/dataflow/versioning/econtrol_cn2 TEMP/DPC/config/dataflow/versioning/suv/level_two_control\r";
mv -v TEMP/DPC/config/dataflow/versioning/econtrol_cn2 TEMP/DPC/config/dataflow/versioning/suv/level_two_control;
#printf "MOVE TEMP/DPC/config/export/myaprc TEMP/DPC/config/export/suv/blueprint_framework\r";
mv -v TEMP/DPC/config/export/myaprc TEMP/DPC/config/export/suv/blueprint_framework;
#printf "MOVE TEMP/DPC/config/export/versioning/blueprint_framework TEMP/DPC/config/export/versioning/suv/blueprint_framework\r";
mv -v TEMP/DPC/config/export/versioning/blueprint_framework TEMP/DPC/config/export/versioning/suv/blueprint_framework;
#printf "MOVE TEMP/DPC/config/versioning/blueprint_framework TEMP/DPC/config/versioning/suv/blueprint_framework\r";
mv -v TEMP/DPC/config/versioning/blueprint_framework TEMP/DPC/config/versioning/suv/blueprint_framework;
#printf "MOVE TEMP/DPC/config/dataflow/versioning/blueprint_framework TEMP/DPC/config/dataflow/versioning/suv/blueprint_framework\r";
mv -v TEMP/DPC/config/dataflow/versioning/blueprint_framework TEMP/DPC/config/dataflow/versioning/suv/blueprint_framework;
#printf "MOVE TEMP/DPC/config/export/uv/econtrol TEMP/DPC/config/export/suv/econtrol\r";
mv -v TEMP/DPC/config/export/uv/econtrol TEMP/DPC/config/export/suv/econtrol;
#printf "MOVE TEMP/DPC/config/versioning/econtrol TEMP/DPC/config/versioning/suv/econtrol\r";
mv -v TEMP/DPC/config/versioning/econtrol TEMP/DPC/config/versioning/suv/econtrol;
#printf "MOVE TEMP/DPC/config/dataflow/versioning/econtrol TEMP/DPC/config/dataflow/versioning/suv/econtrol\r";
mv -v TEMP/DPC/config/dataflow/versioning/econtrol TEMP/DPC/config/dataflow/versioning/suv/econtrol;
#printf "MOVE TEMP/DPC/config/dataflow/versioning/bov_control TEMP/DPC/config/dataflow/versioning/bov/control\r";
mv -v TEMP/DPC/config/dataflow/versioning/bov_control TEMP/DPC/config/dataflow/versioning/bov/control;
#printf "MOVE TEMP/DPC/config/versioning/bov_control TEMP/DPC/config/versioning/bov/control\r";
mv -v TEMP/DPC/config/versioning/bov_control TEMP/DPC/config/versioning/bov/control;
#printf "MOVE TEMP/DPC/config/dataflow/versioning/bov_controlanomaly TEMP/DPC/config/dataflow/versioning/bov/control_anomaly\r";
mv -v TEMP/DPC/config/dataflow/versioning/bov_controlanomaly TEMP/DPC/config/dataflow/versioning/bov/control_anomaly;
#printf "MOVE TEMP/DPC/config/versioning/bov_controlanomaly TEMP/DPC/config/versioning/bov/control_anomaly\r";
mv -v TEMP/DPC/config/versioning/bov_controlanomaly TEMP/DPC/config/versioning/bov/control_anomaly;
#printf "MOVE TEMP/DPC/config/dataflow/versioning/bov_controlform TEMP/DPC/config/dataflow/versioning/bov/controlform_level_two_control\r";
mv -v TEMP/DPC/config/dataflow/versioning/bov_controlform TEMP/DPC/config/dataflow/versioning/bov/controlform_level_two_control;
#printf "MOVE TEMP/DPC/config/versioning/bov_controlform TEMP/DPC/config/versioning/bov/controlform_level_two_control\r";
mv -v TEMP/DPC/config/versioning/bov_controlform TEMP/DPC/config/versioning/bov/controlform_level_two_control;
#printf "MOVE TEMP/DPC/config/dataflow/versioning/bov_controlplan TEMP/DPC/config/dataflow/versioning/bov/controlplan_level_two_control\r";
mv -v TEMP/DPC/config/dataflow/versioning/bov_controlplan TEMP/DPC/config/dataflow/versioning/bov/controlplan_level_two_control;
#printf "MOVE TEMP/DPC/config/versioning/bov_controlplan TEMP/DPC/config/versioning/bov/controlplan_level_two_control\r";
mv -v TEMP/DPC/config/versioning/bov_controlplan TEMP/DPC/config/versioning/bov/controlplan_level_two_control;
#printf "MOVE TEMP/DPC/config/dataflow/versioning/bov_controlresult TEMP/DPC/config/dataflow/versioning/bov/control_result\r";
mv -v TEMP/DPC/config/dataflow/versioning/bov_controlresult TEMP/DPC/config/dataflow/versioning/bov/control_result;
#printf "MOVE TEMP/DPC/config/versioning/bov_controlresult TEMP/DPC/config/versioning/bov/control_result\r";
mv -v TEMP/DPC/config/versioning/bov_controlresult TEMP/DPC/config/versioning/bov/control_result;
#printf "MOVE TEMP/DPC/config/dataflow/versioning/bov_review TEMP/DPC/config/dataflow/versioning/bov/review_level_two_control\r";
mv -v TEMP/DPC/config/dataflow/versioning/bov_review TEMP/DPC/config/dataflow/versioning/bov/review_level_two_control;
#printf "MOVE TEMP/DPC/config/versioning/bov_review TEMP/DPC/config/versioning/bov/review_level_two_control\r";
mv -v TEMP/DPC/config/versioning/bov_review TEMP/DPC/config/versioning/bov/review_level_two_control;
#printf "MOVE TEMP/DPC/config/export/uv/control_quality_l1c TEMP/DPC/config/export/suv/control_quality_lvl_one_ctrl\r";
mv -v TEMP/DPC/config/export/uv/control_quality_l1c TEMP/DPC/config/export/suv/control_quality_lvl_one_ctrl;
#printf "MOVE TEMP/DPC/config/dataflow/bov/myrcsa TEMP/DPC/config/dataflow/bov/risks_controls_self_assessments\r";
mv -v TEMP/DPC/config/dataflow/bov/myrcsa TEMP/DPC/config/dataflow/bov/risks_controls_self_assessments;
#printf "MOVE TEMP/DPC/config/bov/myrcsa TEMP/DPC/config/bov/risks_controls_self_assessments\r";
mv -v TEMP/DPC/config/bov/myrcsa TEMP/DPC/config/bov/risks_controls_self_assessments;
#printf "MOVE TEMP/DPC/config/dataflow/bov/riskevent TEMP/DPC/config/dataflow/bov/risk_event\r";
mv -v TEMP/DPC/config/dataflow/bov/riskevent TEMP/DPC/config/dataflow/bov/risk_event;
#printf "MOVE TEMP/DPC/config/bov/riskevent TEMP/DPC/config/bov/risk_event\r";
mv -v TEMP/DPC/config/bov/riskevent TEMP/DPC/config/bov/risk_event;
#printf "MOVE TEMP/DPC/config/dataflow/bov/outsourced_service TEMP/DPC/config/dataflow/bov/outsourced_services\r";
mv -v TEMP/DPC/config/dataflow/bov/outsourced_service TEMP/DPC/config/dataflow/bov/outsourced_services;
#printf "MOVE TEMP/DPC/config/bov/outsourced_service TEMP/DPC/config/bov/outsourced_services\r";
mv -v TEMP/DPC/config/bov/outsourced_service TEMP/DPC/config/bov/outsourced_services;
#printf "MOVE TEMP/DPC/config/dataflow/srv/a2927/rmo TEMP/DPC/config/dataflow/srv/a2997/oes\r";
mv -v TEMP/DPC/config/dataflow/srv/a2927/rmo TEMP/DPC/config/dataflow/srv/a2997/oes;
#printf "MOVE TEMP/DPC/config/srv/a2927/rmo TEMP/DPC/config/srv/a2997/oes\r";
mv -v TEMP/DPC/config/srv/a2927/rmo TEMP/DPC/config/srv/a2997/oes;
#printf "MOVE TEMP/DPC/config/dataflow/srv/a6979/trm TEMP/DPC/config/dataflow/srv/6979/ttr\r";
mv -v TEMP/DPC/config/dataflow/srv/a6979/trm TEMP/DPC/config/dataflow/srv/6979/ttr;
#printf "MOVE TEMP/DPC/config/srv/a6979/trm TEMP/DPC/config/srv/6979/ttr\r";
mv -v TEMP/DPC/config/srv/a6979/trm TEMP/DPC/config/srv/6979/ttr;
#printf "MOVE TEMP/DPC/config/dataflow/srv/dataquality/a6979 TEMP/DPC/config/dataflow/srv/dataquality/6979\r";
mv -v TEMP/DPC/config/dataflow/srv/dataquality/a6979 TEMP/DPC/config/dataflow/srv/dataquality/6979;
#printf "MOVE TEMP/DPC/config/srv/dataquality/a6979 TEMP/DPC/config/srv/dataquality/6979\r";
mv -v TEMP/DPC/config/srv/dataquality/a6979 TEMP/DPC/config/srv/dataquality/6979;
#printf "MOVE TEMP/DPC/config/dataflow/uv/dataquality TEMP/DPC/config/dataflow/suv/dataquality\r";
mv -v TEMP/DPC/config/dataflow/uv/dataquality TEMP/DPC/config/dataflow/suv/dataquality;
#printf "MOVE TEMP/DPC/config/uv/dataquality TEMP/DPC/config/suv/dataquality\r";
mv -v TEMP/DPC/config/uv/dataquality TEMP/DPC/config/suv/dataquality;
#printf "MOVE TEMP/DPC/config/dataflow/uv/full_outsource_service TEMP/DPC/config/dataflow/suv/full_outsource_service\r";
mv -v TEMP/DPC/config/dataflow/uv/full_outsource_service TEMP/DPC/config/dataflow/suv/full_outsource_service;
#printf "MOVE TEMP/DPC/config/uv/full_outsource_service TEMP/DPC/config/suv/full_outsource_service\r";
mv -v TEMP/DPC/config/uv/full_outsource_service TEMP/DPC/config/suv/full_outsource_service;
#printf "MOVE TEMP/DPC/config/dataflow/uv/myrcsa TEMP/DPC/config/dataflow/suv/risks_controls_self_assessments_dsb\r";
mv -v TEMP/DPC/config/dataflow/uv/myrcsa TEMP/DPC/config/dataflow/suv/risks_controls_self_assessments_dsb;
#printf "MOVE TEMP/DPC/config/uv/myrcsa TEMP/DPC/config/suv/risks_controls_self_assessments_dsb\r";
mv -v TEMP/DPC/config/uv/myrcsa TEMP/DPC/config/suv/risks_controls_self_assessments_dsb;
#printf "MOVE TEMP/DPC/config/dataflow/uv/outsourced_service TEMP/DPC/config/dataflow/suv/outsourced_services_reports\r";
mv -v TEMP/DPC/config/dataflow/uv/outsourced_service TEMP/DPC/config/dataflow/suv/outsourced_services_reports;
#printf "MOVE TEMP/DPC/config/uv/outsourced_service TEMP/DPC/config/suv/outsourced_services_reports\r";
mv -v TEMP/DPC/config/uv/outsourced_service TEMP/DPC/config/suv/outsourced_services_reports;
#printf "MOVE TEMP/DPC/config/dataflow/uv/referential TEMP/DPC/config/dataflow/suv/ic_rop_referential\r";
mv -v TEMP/DPC/config/dataflow/uv/referential TEMP/DPC/config/dataflow/suv/ic_rop_referential;
#printf "MOVE TEMP/DPC/config/uv/referential TEMP/DPC/config/suv/ic_rop_referential\r";
mv -v TEMP/DPC/config/uv/referential TEMP/DPC/config/suv/ic_rop_referential;
#printf "MOVE TEMP/DPC/config/dataflow/uv/risk_event_all_perimeters TEMP/DPC/config/dataflow/suv/risk_event_all_perimeters\r";
mv -v TEMP/DPC/config/dataflow/uv/risk_event_all_perimeters TEMP/DPC/config/dataflow/suv/risk_event_all_perimeters;
#printf "MOVE TEMP/DPC/config/uv/risk_event_all_perimeters TEMP/DPC/config/suv/risk_event_all_perimeters\r";
mv -v TEMP/DPC/config/uv/risk_event_all_perimeters TEMP/DPC/config/suv/risk_event_all_perimeters;
#printf "MOVE TEMP/DPC/config/export/uv/risk_event_all_perimeters TEMP/DPC/config/export/suv/risk_event_all_perimeters\r";
mv -v TEMP/DPC/config/export/uv/risk_event_all_perimeters TEMP/DPC/config/export/suv/risk_event_all_perimeters;
#printf "MOVE TEMP/DPC/config/export/uv/myrcsa TEMP/DPC/config/export/suv/risks_controls_self_assessments_dsb\r";
mv -v TEMP/DPC/config/export/uv/myrcsa TEMP/DPC/config/export/suv/risks_controls_self_assessments_dsb;
#printf "MOVE TEMP/DPC/config/export/uv/full_outsource_service TEMP/DPC/config/export/suv/full_outsource_service\r";
mv -v TEMP/DPC/config/export/uv/full_outsource_service TEMP/DPC/config/export/suv/full_outsource_service;

################################################################################################################################################
########################################################       DPC      ########################################################################
################################################################################################################################################

declare -a dpc=("srv/764/mse" "srv/a2431/ccp" "srv/a2538/psr" "srv/a2614/mok" "srv/a8441/ctl" "srv/a8460/fpc" "suv/level_two_control" "suv/econtrol" "suv/control_quality_lvl_one_ctrl" "suv/blueprint_framework" "suv/action_need" "bov/review_level_two_control" "bov/remediation_plan" "bov/remediation_action" "bov/portfolio" "bov/need_for_action" "bov/controlplan_level_two_control" "bov/controlform_level_two_control" "bov/control_result" "bov/control_anomaly" "bov/control" "bov/bridges" "bov/basicreview" "bov/aprc_referential" "bov/action" "uv/internal_control_gbis" "uv/level_one_control_amer" "uv/level_one_control_asia")

for elt in "${dpc[@]}"; do (
    dir="TEMP/DPC_$(echo "$elt" | sed -e 's/\//_/g')"
    dest="$(echo "$elt" | sed -r 's/\/[_a-zA-Z0-9.-]+$//g')"
    printf "Splitting for DPC Projects .  \r"
    mkdir -p $dir/dataflow/$dest;
    mkdir -p $dir/$dest/;
    printf "Splitting for DPC Projects .. \r"
    cp -r TEMP/DPC/config/dataflow/$elt $dir/dataflow/$dest;
    cp -r TEMP/DPC/config/$elt  $dir/$dest;
    printf "Splitting for DPC Projects ...\r"
); done

# DPC_uv_internal_control_gbis:
cp -r TEMP/DPC/config/extraction TEMP/DPC_uv_internal_control_gbis/;
cp -r TEMP/DPC/config/dataflow/extraction TEMP/DPC_uv_internal_control_gbis/dataflow/;

# DPC_suv_level_two_control :
mkdir -p TEMP/DPC_suv_level_two_control/backup/suv/;
cp -r TEMP/DPC/config/backup/suv/level_two_control/  TEMP/DPC_suv_level_two_control/backup/suv/;
#mkdir -p TEMP/DPC_suv_level_two_control/export/backup/suv/;
#cp -r TEMP/DPC/config/export/backup/suv/level_two_control/  TEMP/DPC_suv_level_two_control/export/backup/suv/;
mkdir -p TEMP/DPC_suv_level_two_control/export/suv/;
cp -r TEMP/DPC/config/export/suv/level_two_control/ TEMP/DPC_suv_level_two_control/export/suv/;
mkdir -p TEMP/DPC_suv_level_two_control/export/versioning/suv/;
cp -r TEMP/DPC/config/export/versioning/suv/level_two_control/ TEMP/DPC_suv_level_two_control/export/versioning/suv/;
mkdir -p TEMP/DPC_suv_level_two_control/versioning/suv/;
cp -r TEMP/DPC/config/versioning/suv/level_two_control/ TEMP/DPC_suv_level_two_control/versioning/suv/;
mkdir -p TEMP/DPC_suv_level_two_control/dataflow/versioning/suv/;
cp -r TEMP/DPC/config/dataflow/versioning/suv/level_two_control/ TEMP/DPC_suv_level_two_control/dataflow/versioning/suv/;

# DPC_suv_blueprint_framework:
mkdir -p TEMP/DPC_suv_blueprint_framework/backup/;
cp -r TEMP/DPC/config/backup/suv/blueprint_framework/  TEMP/DPC_suv_blueprint_framework/backup/;
#mkdir -p TEMP/DPC_suv_blueprint_framework/export/backup/;
#cp -r TEMP/DPC/config/export/backup/suv/blueprint_framework/  TEMP/DPC_suv_blueprint_framework/export/backup/;
mkdir -p TEMP/DPC_suv_blueprint_framework/export/suv/;
cp -r TEMP/DPC/config/export/suv/blueprint_framework/  TEMP/DPC_suv_blueprint_framework/export/suv/;
mkdir -p TEMP/DPC_suv_blueprint_framework/export/versioning/suv/;
cp -r TEMP/DPC/config/export/versioning/suv/blueprint_framework/  TEMP/DPC_suv_blueprint_framework/export/versioning/suv/;
mkdir -p TEMP/DPC_suv_blueprint_framework/versioning/suv/;
cp -r TEMP/DPC/config/versioning/suv/blueprint_framework/  TEMP/DPC_suv_blueprint_framework/versioning/suv/;
mkdir -p TEMP/DPC_suv_blueprint_framework/dataflow/versioning/suv/;
cp -r TEMP/DPC/config/dataflow/versioning/suv/blueprint_framework/  TEMP/DPC_suv_blueprint_framework/dataflow/versioning/suv/;

# DPC_bov_control_result:
#mkdir -p TEMP/DPC_bov_control_result/export/;
#cp -r TEMP/DPC/config/export/bov/ TEMP/DPC_bov_control_result/export/;

# DPC_bov_control:
#mkdir -p TEMP/DPC_bov_control/export/;
#cp -r TEMP/DPC/config/export/bov/ TEMP/DPC_bov_control/export/;

# DPC_bov_control_anomaly:
#mkdir -p TEMP/DPC_bov_control_anomaly/export/;
#cp -r TEMP/DPC/config/export/bov/ TEMP/DPC_bov_control_anomaly/export/;

# DPC_bov_remediation_action:
#mkdir -p TEMP/DPC_bov_remediation_action/export/;
#cp -r TEMP/DPC/config/export/bov/ TEMP/DPC_bov_remediation_action/export/;

# DPC_suv_econtrol:
mkdir -p TEMP/DPC_suv_econtrol/export/suv/;
cp -r TEMP/DPC/config/export/suv/econtrol/ TEMP/DPC_suv_econtrol/export/suv/;
mkdir -p TEMP/DPC_suv_econtrol/versioning/;
cp -r TEMP/DPC/config/versioning/suv/econtrol/ TEMP/DPC_suv_econtrol/versioning/;
mkdir -p TEMP/DPC_suv_econtrol/dataflow/versioning/;
cp -r TEMP/DPC/config/dataflow/versioning/suv/econtrol/ TEMP/DPC_suv_econtrol/dataflow/versioning/;
mkdir -p TEMP/DPC_suv_econtrol/backup/;
cp -r TEMP/DPC/config/backup/suv/econtrol/ TEMP/DPC_suv_econtrol/backup/;
#mkdir -p TEMP/DPC_suv_econtrol/export/backup/;
#cp -r TEMP/DPC/config/export/backup/suv/econtrol/ TEMP/DPC_suv_econtrol/export/backup/;

# DPC_bov_basicreview/basicreview
mkdir -p TEMP/DPC_bov_basicreview/basicreview;
cp -r TEMP/DPC/config/basicreview/dataquality/ TEMP/DPC_bov_basicreview/basicreview;

# DPC_uv_level_one_control_amer:
mkdir -p TEMP/DPC_uv_level_one_control_amer/export/uv/;
cp -r TEMP/DPC/config/export/uv/level_one_control_amer/ TEMP/DPC_uv_level_one_control_amer/export/uv/;
mkdir -p TEMP/DPC_uv_level_one_control_amer/backup/uv/;
cp -r TEMP/DPC/config/backup/uv/level_one_control_amer/ TEMP/DPC_uv_level_one_control_amer/backup/uv/;
#mkdir -p TEMP/DPC_uv_level_one_control_amer/export/backup/uv/;
#cp -r TEMP/DPC/config/export/backup/uv/level_one_control_amer/ TEMP/DPC_uv_level_one_control_amer/export/backup/uv/;

# DPC_uv_level_one_control_asia:
mkdir -p TEMP/DPC_uv_level_one_control_asia/export/uv/;
cp -r TEMP/DPC/config/export/uv/level_one_control_asia/ TEMP/DPC_uv_level_one_control_asia/export/uv/;

# DPC_bov_control:
mkdir -p TEMP/DPC_bov_control/dataflow/versioning/bov/;
cp -r TEMP/DPC/config/dataflow/versioning/bov/control/ TEMP/DPC_bov_control/dataflow/versioning/bov/;
mkdir -p TEMP/DPC_bov_control/versioning/bov/;
cp -r TEMP/DPC/config/versioning/bov/control/ TEMP/DPC_bov_control/versioning/bov/;

# DPC_bov_control_anomaly:
mkdir -p TEMP/DPC_bov_control_anomaly/dataflow/versioning/bov/;
cp -r TEMP/DPC/config/dataflow/versioning/bov/control_anomaly/ TEMP/DPC_bov_control_anomaly/dataflow/versioning/bov/;
mkdir -p TEMP/DPC_bov_control_anomaly/versioning/bov/;
cp -r TEMP/DPC/config/versioning/bov/control_anomaly/ TEMP/DPC_bov_control_anomaly/versioning/bov/;

# DPC_bov_controlform_level_two_control:
mkdir -p TEMP/DPC_bov_controlform_level_two_control/dataflow/versioning/bov/;
cp -r TEMP/DPC/config/dataflow/versioning/bov/controlform_level_two_control/ TEMP/DPC_bov_controlform_level_two_control/dataflow/versioning/bov/;
mkdir -p TEMP/DPC_bov_controlform_level_two_control/versioning/bov/;
cp -r TEMP/DPC/config/versioning/bov/controlform_level_two_control/ TEMP/DPC_bov_controlform_level_two_control/versioning/bov/;

# DPC_bov_controlplan_level_two_control:
mkdir -p TEMP/DPC_bov_controlplan_level_two_control/dataflow/versioning/bov/;
cp -r TEMP/DPC/config/dataflow/versioning/bov/controlplan_level_two_control/ TEMP/DPC_bov_controlplan_level_two_control/dataflow/versioning/bov/;
mkdir -p TEMP/DPC_bov_controlplan_level_two_control/versioning/bov/;
cp -r TEMP/DPC/config/versioning/bov/controlplan_level_two_control/ TEMP/DPC_bov_controlplan_level_two_control/versioning/bov/;

# DPC_bov_control_result:
mkdir -p TEMP/DPC_bov_control_result/dataflow/versioning/bov/;
cp -r TEMP/DPC/config/dataflow/versioning/bov/control_result/ TEMP/DPC_bov_control_result/dataflow/versioning/bov/;
mkdir -p TEMP/DPC_bov_control_result/versioning/bov/;
cp -r TEMP/DPC/config/versioning/bov/control_result/ TEMP/DPC_bov_control_result/versioning/bov/;

# DPC_bov_review_level_two_control:
mkdir -p TEMP/DPC_bov_review_level_two_control/dataflow/versioning/bov/;
cp -r TEMP/DPC/config/dataflow/versioning/bov/review_level_two_control/ TEMP/DPC_bov_review_level_two_control/dataflow/versioning/bov/;
mkdir -p TEMP/DPC_bov_review_level_two_control/versioning/bov/;
cp -r TEMP/DPC/config/versioning/bov/review_level_two_control/ TEMP/DPC_bov_review_level_two_control/versioning/bov/;

# DPC_CTL_Full:
mkdir -p TEMP/DPC_CTL_Full/;
cp -r TEMP/DPC_bov_controlform_level_two_control/* TEMP/DPC_CTL_Full/;
cp -r TEMP/DPC_bov_controlplan_level_two_control/* TEMP/DPC_CTL_Full/;
cp -r TEMP/DPC_bov_review_level_two_control/* TEMP/DPC_CTL_Full/;
cp -r TEMP/DPC_srv_a8441_ctl/* TEMP/DPC_CTL_Full/;
cp -r TEMP/DPC_suv_level_two_control/* TEMP/DPC_CTL_Full/;
rm -rf TEMP/DPC_bov_controlform_level_two_control TEMP/DPC_bov_controlplan_level_two_control TEMP/DPC_bov_review_level_two_control TEMP/DPC_srv_a8441_ctl TEMP/DPC_suv_level_two_control

# DPC_FPC_Full:
mkdir -p TEMP/DPC_FPC_Full/;
cp -r TEMP/DPC_bov_aprc_referential/* TEMP/DPC_FPC_Full/;
cp -r TEMP/DPC_srv_a8460_fpc/* TEMP/DPC_FPC_Full/;
cp -r TEMP/DPC_suv_blueprint_framework/* TEMP/DPC_FPC_Full/;
rm -rf TEMP/DPC_bov_aprc_referential TEMP/DPC_srv_a8460_fpc TEMP/DPC_suv_blueprint_framework

# DPC_BASICREVIEW_Full:
mkdir -p TEMP/DPC_suv_control_quality_lvl_one_ctrl/export/suv/;
cp -r TEMP/DPC/config/export/suv/control_quality_lvl_one_ctrl/ TEMP/DPC_suv_control_quality_lvl_one_ctrl/export/suv/;
mkdir -p TEMP/DPC_suv_control_quality_lvl_one_ctrl/basicreview/;
cp -r TEMP/DPC/config/basicreview/econtrol TEMP/DPC_suv_control_quality_lvl_one_ctrl/basicreview/;
mv -v TEMP/DPC_suv_control_quality_lvl_one_ctrl TEMP/DPC_BASICREVIEW_Full;

# DPC_DQ_Full :
mkdir -p TEMP/DPC_bov_basicreview/basicreview/;
cp -r TEMP/DPC/config/basicreview/dataquality TEMP/DPC_bov_basicreview/basicreview/;
mv -v TEMP/DPC_bov_basicreview TEMP/DPC_DQ_Full;

######### CREATE REPO #####################
mv -v TEMP/DPC_CTL_Full TEMP/full_dpc_a8420_ctl;
mv -v TEMP/DPC_FPC_Full TEMP/full_dpc_a8420_fpc;
mv -v TEMP/DPC_BASICREVIEW_Full/ TEMP/full_dpc_a8420_basicreview/;
cp -r TEMP/DPC_bov_bridges/* TEMP/full_dpc_a8420_fpc/;
rm -rf TEMP/DPC_bov_bridges
mv -v TEMP/DPC_bov_control_anomaly TEMP/bov_dpc_a8420_control_anomaly;
mv -v TEMP/DPC_bov_need_for_action TEMP/bov_dpc_a8420_need_for_action;
mv -v TEMP/DPC_bov_remediation_action TEMP/bov_dpc_a8420_remediation_action;
mv -v TEMP/DPC_srv_a2431_ccp TEMP/srv_ccp_a2431_action;
mv -v TEMP/DPC_srv_a2614_mok TEMP/srv_mok_a2614_moka;
mv -v TEMP/DPC_suv_econtrol TEMP/suv_dpc_a8420_econtrol;
mv -v TEMP/DPC_uv_level_one_control_amer TEMP/uv_dpc_a8420_level_one_control_amer;
mv -v TEMP/DPC_bov_action TEMP/bov_dpc_a8420_action;
mv -v TEMP/DPC_bov_control TEMP/bov_dpc_a8420_control;
mv -v TEMP/DPC_bov_control_result TEMP/bov_dpc_a8420_control_result;
cp -r TEMP/DPC_bov_portfolio/* TEMP/bov_dpc_a8420_control_result/;
rm -rf TEMP/DPC_bov_portfolio;
mv -v TEMP/DPC_bov_remediation_plan TEMP/bov_dpc_a8420_remediation_plan;
mv -v TEMP/DPC_DQ_Full TEMP/full_dpc_a8420_dq;
mv -v TEMP/DPC_srv_764_mse TEMP/srv_mse_764_morse;
mv -v TEMP/DPC_srv_a2538_psr TEMP/srv_psr_a2538_gps;
mv -v TEMP/DPC_suv_action_need TEMP/suv_dpc_a8420_action_need;
mv -v TEMP/DPC_uv_internal_control_gbis TEMP/uv_dpc_a8420_internal_control_gbis;
mv -v TEMP/DPC_uv_level_one_control_asia TEMP/uv_dpc_a8420_level_one_control_asia;

################################################################################################################################################
########################################################       ROL      ########################################################################
################################################################################################################################################
rm -rf TEMP/DPC/config/dataflow/srv/a2431/ccp;
rm -rf TEMP/DPC/config/srv/a2431/ccp;

#printf "MOVE TEMP/DPC/config/dataflow/srv/a2431/loss/* TEMP/DPC/config/dataflow/srv/a2431/ccp\r"
mkdir -p TEMP/DPC/config/dataflow/srv/a2431/ccp;
mv -v TEMP/DPC/config/dataflow/srv/a2431/loss TEMP/DPC/config/dataflow/srv/a2431/ccp;
#printf "MOVE TEMP/DPC/config/srv/a2431/loss/* TEMP/DPC/config/srv/a2431/ccp\r"
mkdir -p TEMP/DPC/config/srv/a2431/ccp;
mv -v TEMP/DPC/config/srv/a2431/loss TEMP/DPC/config/srv/a2431/ccp;

declare -a rol=("bov/risks_controls_self_assessments" "bov/risk_event" "srv/134053/cni" "bov/outsourced_services" "srv/a2431/ccp" "srv/a2997/oes" "srv/6979/ttr" "srv/a8447/aer" "srv/dataquality/6979" "srv/dataquality/a2431" "suv/dataquality" "suv/full_outsource_service" "suv/risks_controls_self_assessments_dsb" "suv/outsourced_services_reports" "suv/ic_rop_referential" "suv/risk_event_all_perimeters")

for elt in "${rol[@]}"; do (
    dir="TEMP/ROL_$(echo "$elt" | sed -e 's/\//_/g')"
    dest="$(echo "$elt" | sed -r 's/\/[_a-zA-Z0-9-]+$//')"
    printf "Splitting for ROL Projects .  \r"
    mkdir -p $dir/dataflow/$dest;
    mkdir -p $dir/$dest/;
    printf "Splitting for ROL Projects .. \r"
    cp -r TEMP/DPC/config/dataflow/$elt $dir/dataflow/$dest;
    cp -r TEMP/DPC/config/$elt  $dir/$dest;
    printf "Splitting for ROL Projects ...\r"
); done

# ROL_suv_risk_event_all_perimeters:
mkdir -p TEMP/ROL_suv_risk_event_all_perimeters/export/suv/;
cp -r TEMP/DPC/config/export/suv/risk_event_all_perimeters/ TEMP/ROL_suv_risk_event_all_perimeters/export/suv/;

# ROL_suv_risks_controls_self_assessments_dsb:
mkdir -p TEMP/ROL_suv_risks_controls_self_assessments_dsb/export/suv/;
cp -r TEMP/DPC/config/export/suv/risks_controls_self_assessments_dsb/ TEMP/ROL_suv_risks_controls_self_assessments_dsb/export/suv/;

# ROL_suv_full_outsource_service:
mkdir -p TEMP/ROL_suv_full_outsource_service/export/suv/;
cp -r TEMP/DPC/config/export/suv/full_outsource_service/ TEMP/ROL_suv_full_outsource_service/export/suv/;
mkdir -p TEMP/ROL_suv_full_outsource_service/export/versioning/;
cp -r TEMP/DPC/config/export/versioning/full_outsource_service/ TEMP/ROL_suv_full_outsource_service/export/versioning/;
mkdir -p TEMP/ROL_suv_full_outsource_service/versioning/;
cp -r TEMP/DPC/config/versioning/full_outsource_service/ TEMP/ROL_suv_full_outsource_service/versioning/;
mkdir -p TEMP/ROL_suv_full_outsource_service/dataflow/versioning/;
cp -r TEMP/DPC/config/dataflow/versioning/full_outsource_service/ TEMP/ROL_suv_full_outsource_service/dataflow/versioning/;

mv -v TEMP/ROL_suv_dataquality TEMP/suv_rol_a8518_risk_event_all_perimeters;
cp -r TEMP/ROL_suv_risk_event_all_perimeters/* TEMP/suv_rol_a8518_risk_event_all_perimeters/;
rm -rf TEMP/ROL_suv_risk_event_all_perimeters

mv -v TEMP/ROL_suv_ic_rop_referential TEMP/suv_dpc_a8420_ic_rop_referential;

mv -v TEMP/ROL_suv_risks_controls_self_assessments_dsb TEMP/suv_rol_a8518_risks_controls_self_assessments_dsb;

mv -v TEMP/ROL_suv_full_outsource_service TEMP/suv_rol_a8518_full_outsource_service;

mv -v TEMP/ROL_srv_a8447_aer TEMP/srv_aer_a8447_myrcsa;

mv -v TEMP/ROL_srv_6979_ttr TEMP/srv_ttr_6979_t2eoreme;
cp -r TEMP/ROL_srv_dataquality_6979/* TEMP/srv_ttr_6979_t2eoreme/;
rm -rf TEMP/ROL_srv_dataquality_6979

cp -r TEMP/DPC/config/dataformatter TEMP/ROL_srv_a2997_oes/;
mv -v TEMP/ROL_srv_a2997_oes TEMP/srv_oes_a2997_ramos;

mv -v TEMP/ROL_srv_a2431_ccp TEMP/srv_ccp_a2431_risk_event;
cp -r TEMP/ROL_srv_dataquality_a2431/* TEMP/srv_ccp_a2431_risk_event/;
rm -rf TEMP/ROL_srv_dataquality_a2431


mv -v TEMP/ROL_srv_134053_cni TEMP/srv_cni_134053_archer;

mv -v TEMP/ROL_bov_risk_event TEMP/bov_rol_a8518_risk_event;

mv -v TEMP/ROL_bov_outsourced_services TEMP/bov_rol_a8518_outsourced_services;

mv -v TEMP/ROL_bov_risks_controls_self_assessments TEMP/bov_rol_a8518_risks_controls_self_assessments;

mv -v TEMP/ROL_suv_outsourced_services_reports TEMP/suv_rol_a8518_outsourced_services_reports;


#mkdir -p TEMP/ROL_MyRCSA;
#cp -r TEMP/ROL_srv_a8447_aer/* TEMP/ROL_MyRCSA/;
#cp -r TEMP/ROL_bov_myrcsa/* TEMP/ROL_MyRCSA/;
#cp -r TEMP/ROL_suv_myrcsa/* TEMP/ROL_MyRCSA/;
#rm -rf TEMP/ROL_srv_a8447_aer TEMP/ROL_bov_myrcsa TEMP/ROL_suv_myrcsa
#
#mkdir -p TEMP/ROL_Losses;
#cp -r TEMP/ROL_srv_6979_ttr/* TEMP/ROL_Losses;
#cp -r TEMP/ROL_srv_a2431_loss/* TEMP/ROL_Losses;
#cp -r TEMP/ROL_srv_dataquality/* TEMP/ROL_Losses;
#cp -r TEMP/ROL_bov_risk_event/* TEMP/ROL_Losses;
#cp -r TEMP/ROL_suv_risk_event_all_perimeters/* TEMP/ROL_Losses;
#cp -r TEMP/ROL_suv_dataquality/* TEMP/ROL_Losses;
#rm -rf TEMP/ROL_srv_6979_ttr TEMP/ROL_srv_a2431_loss TEMP/ROL_srv_dataquality TEMP/ROL_bov_risk_event TEMP/ROL_suv_risk_event_all_perimeters TEMP/ROL_suv_dataquality

################################################################################################################################################
########################################################   SED REPLACE  ########################################################################
################################################################################################################################################

echo "started at $startTime ; Split ended at $(date -R) ; $(($SECONDS / 60)) minutes and $(($SECONDS % 60)) seconds elapsed";

repos=()
repos+=("full_dpc_a8420_ctl") # Comment with '#' if you want to disable genreration in LUCID directory
#repos+=("bov_dpc_a8420_action") # Comment with '#' if you want to disable genreration in LUCID directory
#repos+=("bov_dpc_a8420_control") # Comment with '#' if you want to disable genreration in LUCID directory
#repos+=("bov_dpc_a8420_control_anomaly") # Comment with '#' if you want to disable genreration in LUCID directory
#repos+=("bov_dpc_a8420_control_result") # Comment with '#' if you want to disable genreration in LUCID directory
#repos+=("bov_dpc_a8420_need_for_action") # Comment with '#' if you want to disable genreration in LUCID directory
#repos+=("bov_dpc_a8420_remediation_action") # Comment with '#' if you want to disable genreration in LUCID directory
#repos+=("bov_dpc_a8420_remediation_plan") # Comment with '#' if you want to disable genreration in LUCID directory
#repos+=("bov_rol_a8518_outsourced_services") # Comment with '#' if you want to disable genreration in LUCID directory
#repos+=("bov_rol_a8518_risk_event") # Comment with '#' if you want to disable genreration in LUCID directory
#repos+=("bov_rol_a8518_risks_controls_self_assessments") # Comment with '#' if you want to disable genreration in LUCID directory
#repos+=("full_dpc_a8420_basicreview") # Comment with '#' if you want to disable genreration in LUCID directory
#repos+=("full_dpc_a8420_dq") # Comment with '#' if you want to disable genreration in LUCID directory
#repos+=("full_dpc_a8420_fpc") # Comment with '#' if you want to disable genreration in LUCID directory
#repos+=("srv_aer_a8447_myrcsa") # Comment with '#' if you want to disable genreration in LUCID directory
#repos+=("srv_ccp_a2431_action") # Comment with '#' if you want to disable genreration in LUCID directory
#repos+=("srv_ccp_a2431_risk_event") # Comment with '#' if you want to disable genreration in LUCID directory
#repos+=("srv_cni_134053_archer") # Comment with '#' if you want to disable genreration in LUCID directory
#repos+=("srv_mok_a2614_moka") # Comment with '#' if you want to disable genreration in LUCID directory
#repos+=("srv_mse_764_morse") # Comment with '#' if you want to disable genreration in LUCID directory
#repos+=("srv_oes_a2997_ramos") # Comment with '#' if you want to disable genreration in LUCID directory
#repos+=("srv_psr_a2538_gps") # Comment with '#' if you want to disable genreration in LUCID directory
#repos+=("srv_ttr_6979_t2eoreme") # Comment with '#' if you want to disable genreration in LUCID directory
#repos+=("suv_dpc_a8420_action_need") # Comment with '#' if you want to disable genreration in LUCID directory
#repos+=("suv_dpc_a8420_econtrol") # Comment with '#' if you want to disable genreration in LUCID directory
#repos+=("suv_dpc_a8420_ic_rop_referential") # Comment with '#' if you want to disable genreration in LUCID directory
#repos+=("suv_rol_a8518_full_outsource_service") # Comment with '#' if you want to disable genreration in LUCID directory
#repos+=("suv_rol_a8518_outsourced_services_reports") # Comment with '#' if you want to disable genreration in LUCID directory
#repos+=("suv_rol_a8518_risk_event_all_perimeters") # Comment with '#' if you want to disable genreration in LUCID directory
#repos+=("suv_rol_a8518_risks_controls_self_assessments_dsb") # Comment with '#' if you want to disable genreration in LUCID directory
#repos+=("uv_dpc_a8420_internal_control_gbis") # Comment with '#' if you want to disable genreration in LUCID directory
#repos+=("uv_dpc_a8420_level_one_control_amer") # Comment with '#' if you want to disable genreration in LUCID directory
#repos+=("uv_dpc_a8420_level_one_control_asia") # Comment with '#' if you want to disable genreration in LUCID directory

mkdir -p LUCID;
for repo in "${repos[@]}"; do (
  mv -v TEMP/$repo LUCID/$repo;
); done

#rm -rf TEMP;
rm -rf ./report 2> /dev/null;
mkdir -p ./report;

find LUCID/ -type f -print > ./report/file_list.txt;

#my_sed_script="$(cat ./sed.sh)"

split -l 4 ./report/file_list.txt ./report/;

rm ./report/file_list.txt

cd ./report/;
splitted_list=$(ls -p * | grep -v /);
cd ..;

round=0
for splitted_file in $splitted_list ; do
  counter=0
  pids=()
  while read line; do
    sed_replace $line $splitted_file $counter &
    pid=$!
    pids+=($pid)
    echo "Thread $splitted_file-$counter : $line with pid $pid"
    let counter++
  done < ./report/$splitted_file
  echo "Waiting for $round-$counter childs process to finish for file $splitted_file; $(($SECONDS / 60)) minutes and $(($SECONDS % 60)) seconds elapsed";
  wait ${pids[@]}
  echo "$round-$counter Childs process finished for dile $splitted_file; $(($SECONDS / 60)) minutes and $(($SECONDS % 60)) seconds elapsed";
  let round++
done

echo "Started at $startTime ; Ended at $(date -R) ; Total time : $(($SECONDS / 60)) minutes and $(($SECONDS % 60)) seconds elapsed";